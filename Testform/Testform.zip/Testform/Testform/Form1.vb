﻿Imports System.IO

Public Class testform
    Dim s() As String
    Dim lw_c As New ArrayList
    Dim keimeno As String
    Dim s_keimeno As String
    Dim file As String
    Dim lekseis As Int32
    Dim sln As Single
    Dim apax, dis As Int32
    Dim listaleksewn As String
    Dim uw As New ArrayList

    Dim types As Int32

    Dim typearray As String()




    Dim n As Int32
    Dim sortedtype() As String
    Dim sortedfreq() As Int32
    Dim freq() As Int32
    Dim freq2() As Int32
    Dim sixnot() As Single

    Private Sub exit_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitbtn.Click
        Me.Close()
    End Sub

    Private Sub open_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles openbtn.Click
        ReDim sortedtype(20000)
        ReDim sortedfreq(20000)
        ReDim typearray(5000)
        ReDim typesum(5000)
        ReDim freq(5000)
        ReDim sixnot(5000)
        ReDim freq2(5000)

        Dim openfiledialog As New OpenFileDialog
        If openfiledialog.ShowDialog = DialogResult.OK Then
            file = openfiledialog.FileName
            texttovar(file, keimeno)
            'Αρχικοποίηση

            origtext.Text = keimeno

            wText.Text = ""
            awltext.Text = ""
            stext.Text = ""
            sl_sd.Text = ""
            ad.Text = ""
            lwch.Text = ""

            apaxlbl.Text = "Perc_Hapl : "
            dislbl.Text = "Perc_Dis : "
            apax_dis.Text = "Dis_Hapl : "
            type.Text = "Types : "
            ttrlbl.Text = "TTR : "
            awllbl.Text = "Awl : "
            wlcsd.Text = "WL_Csd : "
            slsdlbl.Text = "SLsd : "
            wclbl.Text = "Wordcount : "
            apaxlbl.text = "apax : "
            dislbl.Text = "dis : "
            LDtxt.Text = " LD : "
        End If


    End Sub

    Private Sub execute_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles executebtn.Click




        proetoimasia_keimenou(keimeno)

        'ksexwrizoume to keimeno gia sentence length
        s_keimeno = keimeno

        'efarmozoume tin apokopi simeiwn stiksis tou keimenou gia tis lekseis
        simeia_stiksis(keimeno)

        ' kataxwrisi apotelesmatwn
        'sinolo leksewn ----------------- --------> lekseis
        'Mesos oros leksewn se xaraktires --------->  m
        'meso mikos protasis se lekseis ----------> sln


        lekseis = words(keimeno)
        wclbl.Text &= lekseis
        ttrlbl.Text &= TTR(keimeno, typearray, freq, types)


        Dim m As String
        m = awl(keimeno)
        awllbl.Text &= m
        wlcsd.Text &= wl_csd(keimeno, m)
        sln = Sentence_Length(s_keimeno)
        sl.Text &= sln
        slsdlbl.Text &= slsd(s_keimeno)

        'apax dis legomena
        apaxdis(keimeno, apax, dis)
        apaxlbl.Text &= apax
        dislbl.Text &= dis
        apax_dis.Text &= dis / apax

        lw_c1(keimeno, lw_c)
        LDtxt.Text &= LD(keimeno)

        

        For i = 0 To types
            freq2(i) = freq(i)
        Next

        n = 10
        w_sort(n, freq2, typearray, sortedtype, sortedfreq, types)

       

        euresisixnotitwn(typearray, freq, sortedtype, n, sixnot)

        'Dim openfiledialog As New OpenFileDialog
        'If openfiledialog.ShowDialog = DialogResult.OK Then
        '    file = openfiledialog.FileName
        '    Dim lista As String = ""

        '    uw1(file, keimeno, uw)
        'End If

    End Sub

    Private Sub texttovar(ByVal textname As String, ByRef varname As String)
        Dim fs As FileStream
        Dim sr As StreamReader

        fs = New FileStream(textname, FileMode.Open)
        sr = New StreamReader(fs, System.Text.Encoding.Default)

        varname = sr.ReadToEnd
        fs.Close()





    End Sub

    Private Sub proetoimasia_keimenou(ByRef rep2 As String)





        'ΚΑΘΑΡΙΣΜΟΣ ΚΕΙΜΕΝΟΥ

        'νέα γραμμή και tab
        rep2 = rep2.Replace(vbNewLine, " "c)
        rep2 = rep2.Replace(vbTab, " "c)


        ' κύριος, κυρία
        rep2 = rep2.Replace("κ.", " "c)
        rep2 = rep2.Replace("κα.", " "c)

        ' τα μικρά ονόματα με τελεία
        rep2 = rep2.Replace("Α.", " "c)
        rep2 = rep2.Replace("Β.", " "c)
        rep2 = rep2.Replace("Γ.", " "c)
        rep2 = rep2.Replace("Δ.", " "c)
        rep2 = rep2.Replace("Ε.", " "c)
        rep2 = rep2.Replace("Ζ.", " "c)
        rep2 = rep2.Replace("Η.", " "c)
        rep2 = rep2.Replace("Θ.", " "c)
        rep2 = rep2.Replace("Ι.", " "c)
        rep2 = rep2.Replace("Κ.", " "c)
        rep2 = rep2.Replace("Λ.", " "c)
        rep2 = rep2.Replace("Μ.", " "c)
        rep2 = rep2.Replace("Ν.", " "c)
        rep2 = rep2.Replace("Ξ.", " "c)
        rep2 = rep2.Replace("Ο.", " "c)
        rep2 = rep2.Replace("Π.", " "c)
        rep2 = rep2.Replace("Ρ.", " "c)
        rep2 = rep2.Replace("Σ.", " "c)
        rep2 = rep2.Replace("Τ.", " "c)
        rep2 = rep2.Replace("Υ.", " "c)
        rep2 = rep2.Replace("Φ.", " "c)
        rep2 = rep2.Replace("Χ.", " "c)
        rep2 = rep2.Replace("Ψ.", " "c)
        rep2 = rep2.Replace("Ω.", " "c)

        'αριθμοί
        rep2 = rep2.Replace("1", "")
        rep2 = rep2.Replace("2", "")
        rep2 = rep2.Replace("3", "")
        rep2 = rep2.Replace("4", "")
        rep2 = rep2.Replace("5", "")
        rep2 = rep2.Replace("6", "")
        rep2 = rep2.Replace("7", "")
        rep2 = rep2.Replace("8", "")
        rep2 = rep2.Replace("9", "")
        rep2 = rep2.Replace("0", "")

        'ειδικοί χαρακτήρες
        'rep2 = rep2.Replace("'"c, " "c)
        rep2 = rep2.Replace("("c, " "c)
        rep2 = rep2.Replace(")"c, " "c)
        rep2 = rep2.Replace("-"c, " "c)
        rep2 = rep2.Replace("%"c, " "c)
        rep2 = rep2.Replace(", ", " "c)
        rep2 = rep2.Replace(":", " "c)


        'kena
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("  ", " "c)

    End Sub

    Private Sub simeia_stiksis(ByRef rep2 As String)
        'σημεία στίξης
        rep2 = rep2.Replace(";"c, " "c)
        rep2 = rep2.Replace("!"c, " "c)
        rep2 = rep2.Replace("?", " "c)
        rep2 = rep2.Replace("...", " "c)
        rep2 = rep2.Replace("..", " "c)
        rep2 = rep2.Replace(". ", " "c)
        rep2 = rep2.Replace(" .", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("  ", " "c)
    End Sub

    Private Function words(ByRef datas As String)

        Dim rep() As Char = {" "c}
        s = datas.Split(rep)

        ' set column size for the s array
        Dim wds As Int32 = UBound(s)
        Dim test As String = ""

        Do Until test <> ""
            test = s(wds)
            test = test.Replace("   ", "")
            test = test.Replace("   ", "")
            test = test.Replace("   ", "")
            test = test.Replace("  ", "")
            test = test.Replace(" ", "")
            If test = "" Then
                wds -= 1
            End If
        Loop

        Dim minus As Int32 = 0
        'Dim excludelist() As String = {"ο", "Ο", "Η", "η", "ή"}
        'Dim item_in_list As Boolean
        datas = ""
        For i = 0 To wds
            'item_in_list = excludelist.Contains(s(i))
            If s(i).Length < 1 Then
                If i <> 0 Then
                    datas &= s(i) & vbNewLine
                Else
                    minus += 1
                End If
            Else
                datas &= s(i) & vbNewLine
            End If


        Next
        words = wds + 1 - minus


        '-----erase-------------------------------------------------
        Dim output As String = ""
        For i = 0 To wds
            output &= i + 1 & ". " & s(i) & vbNewLine
        Next

        wText.Text = output

        '-----------------------------------------------------------

    End Function

    Private Function TTR(ByVal datas As String, ByRef typearray() As String, ByRef w() As Int32, ByRef types As Int32) As Double
        Dim s() As String

        s = datas.Split(vbNewLine)
        Dim ind As Int32

        Dim tokens As Int32 = UBound(s)

        'Dim tokenlist As New ArrayList
        'Dim vrethike As Boolean

        Dim test As String

        typearray(0) = s(0)

        w(0) = 1


        For i = 1 To UBound(s) - 1

            test = s(i)

            If Not typearray.Contains(s(i)) Then 'an den periexei ti leksi, tin prosthetoume
                types += 1
                typearray(types) = s(i)
                w(types) = 1
            Else
                ind = Array.IndexOf(typearray, s(i))  'vriskoume se pio index einai i leksi sto typearray

                w(ind) += 1        ''''''  metraw mia akoma leksi sto sigekrimeno index
            End If

        Next

        If tokens = 1 Then
            types = 1
        Else
            types -= 1
        End If

        TTR = types / tokens

        type.Text &= types


    End Function

    Private Function awl(ByVal datas As String) As Single
        Dim s() As String
        s = datas.Split(vbNewLine)

        Dim l As Int32
        Dim m As Single = s(0).Length
        Dim words As Int32 = UBound(s)
        For i = 1 To words - 1

            l = s(i).Length

            m += l - 1
        Next
        awl = m / words


        '-------------erase------------------
        Dim output As String = "1. " & s(0) & vbTab & vbTab & s(0).Length & vbNewLine
        For i = 1 To words - 1
            output &= i + 1 & ". " & s(i) & vbTab & vbTab & s(i).Length - 1 & vbNewLine
        Next

        awltext.Text = output
        '------------------------------------

    End Function

    Private Function wl_csd(ByVal datas As String, ByVal m As Single) As Single
        Dim wordlist() As String
        wordlist = datas.Split(vbNewLine)

        Dim wlc As Single
        Dim max As Int32
        Dim x_m As Single
        x_m = 0
        max = UBound(wordlist) - 1
        For i = 0 To max
            wlc = wordlist(i).Length - 1
            x_m += (wlc - m) ^ 2
        Next


        wl_csd = Math.Sqrt(x_m) / m

    End Function

    Private Function Sentence_Length(ByRef datas As String) As Single
        Dim chararray() As Char = {".", ";", "!", "?"}
        Dim rep2 As String
        rep2 = datas
        rep2 = rep2.Replace("...", "."c)
        rep2 = rep2.Replace("..", "."c)
        s = rep2.Split(chararray)
        Dim max As Int32 = UBound(s)
        Dim sum As Int32 = 0
        Dim counter As Int32 = 1
        Dim minus As Int32 = 0

        Dim w() As String
        Dim l As Int32
        w = s(0).Split(" "c)

        sum += UBound(w) + 1
        Dim test As String
        Dim sentences As Int32 = 1
        '----------erase------------------
        Dim output As String = "1.  " & s(0) & "  " & sum & vbNewLine
        '---------------------------------
        datas = s(0) & vbNewLine

        For i = 1 To max
            w = s(i).Split(" "c)
            l = UBound(w)
            test = ""

            Do Until test <> "" Or l = -1
                test = w(l)
                If test = "" Then
                    l -= 1
                End If
            Loop

            If l > -1 Then
                sum += l
                sentences += 1
                '---------erase--------------------------------------
                output &= sentences & ".  " & s(i) & "  " & l & vbNewLine
                '----------------------------------------------------
                datas &= s(i) & vbNewLine

            End If

        Next
        max = sentences
        Sentence_Length = lekseis / max


        '---erase---------------------------
        output &= vbNewLine & "sum = " & sum & vbNewLine
        stext.Text &= output & " Λέξεις : " & lekseis & "  Προτάσεις : " & max
        '-----------------------------------

    End Function

    Private Function slsd(ByVal datas As String) As Single

        s = datas.Split(vbNewLine)


        Dim max As Int32 = UBound(s)
        Dim sum As Int32 = 0
        Dim counter As Int32 = 1
        Dim minus As Int32 = 0

        Dim w() As String
        Dim l As Int32
        w = s(0).Split(" "c)
        l = UBound(w) + 1
        Dim test As String
        Dim sentences As Int32 = 1

        '----------erase------------------
        Dim output As String = "1." & s(0) & " words : " & l & " words-average = " & l - sln & vbNewLine
        '---------------------------------

        datas = s(0) & vbNewLine
        sum = (l - sln) ^ 2

        For i = 1 To max - 1
            w = s(i).Split(" "c)
            l = UBound(w)
            test = ""

            Do Until test <> "" Or l = -1
                test = w(l)
                If test = "" Then
                    l -= 1
                End If
            Loop

            If l > -1 Then
                sum += (l - sln) ^ 2
                sentences += 1
                '---------erase--------------------------------------
                output &= i + 1 & "." & s(i) & " words : " & l & " words-average = " & l - sln & vbNewLine
                '----------------------------------------------------
                datas &= s(i) & vbNewLine

            End If

        Next
        max = sentences

        slsd = Math.Sqrt(sum / max)

        '---erase---------------------------
        output &= vbNewLine & "sum = " & sum & vbNewLine

        sl_sd.Text &= output & " Λέξεις : " & lekseis & "  Προτάσεις : " & max

        '-------------------------------------------------------------
    End Function

    Private Sub apaxdis(ByVal datas As String, ByRef ap As Int32, ByRef di As Int32)

        s = datas.Split(vbNewLine)
        Dim temp As String
        Dim apaxlist As New ArrayList
        Dim dislist As New ArrayList
        Dim multilist As New ArrayList
        Dim checklist As New ArrayList(s)
        apaxlist.Add("")
        dislist.Add("")
        multilist.Add("")


        For i = 1 To lekseis - 1
            temp = checklist.Item(i)
            If Not multilist.Contains(temp) Then
                If Not dislist.Contains(temp) Then
                    If Not apaxlist.Contains(temp) Then
                        apaxlist.Add(temp)
                    Else
                        apaxlist.Remove(temp)
                        dislist.Add(temp)
                    End If
                Else
                    dislist.Remove(temp)
                    multilist.Add(temp)
                End If
            End If
        Next
        Dim trimmed As String
        temp = s(0)
        Dim upper As Int32
        trimmed = datas.TrimStart(temp)
        Dim splitted() As String
        Dim add1 As Int32 = 0
        Dim add2 As Int32 = 0

        If Not trimmed.Contains(temp) Then
            apaxlist.Add(temp)
        Else
            splitted = trimmed.Split(temp)
            upper = UBound(splitted)

            If upper = 1 Then

                MsgBox(" need to remove from apaxlist")
                add1 = -1

                dislist.Add(temp)
            ElseIf upper = 2 Then
                MsgBox("need to remove from dislist")

                add2 = -1
            End If
        End If

        ap = apaxlist.Count - 1 + add1
        di = dislist.Count - 1 + add2


        '----remove--------------------------------
        Dim output As String = "-----------apaxlist--------------" & vbNewLine
        For i = 1 To ap
            output &= apaxlist.Item(i) & vbNewLine
        Next

        output &= "-------------------dislist-------------------" & vbNewLine

        For i = 1 To di
            output &= dislist.Item(i) & vbNewLine
        Next

        ad.Text = output

        '------------------------------------------



    End Sub

    Private Function periexei(ByVal mialista As ArrayList, ByVal price As String) As Boolean
        Dim exei As Boolean
        exei = False
        For i = 0 To mialista.Count - 1
            If mialista.Item(0) = price Then
                exei = True
            End If
        Next
        periexei = exei
    End Function

    Private Function LD(ByVal datas As String) As Single
        Dim f() As String
        Dim fdata As String = ""
        Dim filename As String = System.Environment.CurrentDirectory & "\fw.txt"
        texttovar(filename, fdata)
        fdata.Replace("   ", "")
        fdata.Replace("   ", "")
        fdata.Replace("   ", "")
        fdata.Replace("  ", "")
        fdata.Replace(" "c, "")

        f = fdata.Split(vbNewLine)
        Dim fw As New ArrayList(f)
        s = datas.Split(vbNewLine)
        Dim checkword As String
        Dim countl As Int32 = 0
        Dim output As String = "periexomenou : "
        For i = 0 To lekseis - 1
            checkword = s(i)
            If fw.Contains(checkword) Then
                countl += 1
            Else
                output &= checkword & " "
            End If
        Next
        Dim leitourgikes = countl
        Dim periexomenou = lekseis - countl

        LD = leitourgikes / periexomenou

        '----------------------erase----------------------
        output &= vbNewLine

        output &= "leitourgikes : " & leitourgikes & vbNewLine

        output &= "periexomenou : " & periexomenou & vbNewLine

        lwch.Text &= output



        '-------------------------------------------------


    End Function

    Private Sub lw_c1(ByVal datas As String, ByRef lw As ArrayList)
        Dim temp As String
        Dim l As Int32
        s = datas.Split(vbNewLine)

        '---- arxikopoiisi timwn

        For i = 1 To 20
            lw.Item(i) = 0
        Next


        ' dimiourgw ti lista

        For i = 0 To lekseis - 1
            temp = s(i)
            If i = 0 Then
                l = temp.Length
            Else
                l = temp.Length - 1
            End If

            Select Case l
                Case 1
                    lw.Item(1) += 1
                Case 2
                    lw.Item(2) += 1
                Case 3
                    lw.Item(3) += 1
                Case 4
                    lw.Item(4) += 1
                Case 5
                    lw.Item(5) += 1
                Case 6
                    lw.Item(6) += 1
                Case 7
                    lw.Item(7) += 1
                Case 8
                    lw.Item(8) += 1
                Case 9
                    lw.Item(9) += 1
                Case 10
                    lw.Item(10) += 1
                Case 11
                    lw.Item(11) += 1
                Case 12
                    lw.Item(12) += 1
                Case 13
                    lw.Item(13) += 1
                Case 14
                    lw.Item(14) += 1
                Case 15
                    lw.Item(15) += 1
                Case 16
                    lw.Item(16) += 1
                Case 17
                    lw.Item(17) += 1
                Case 18
                    lw.Item(18) += 1
                Case 19
                    lw.Item(19) += 1
                Case 20
                    lw.Item(20) += 1
            End Select
        Next

        '----------erase------------------------------------
        Dim output As String = ""

        For i = 1 To 20

            output &= "lekseis me " & i & " chars : " & lw.Item(i) & vbNewLine
        Next

        '---------------------------------------------------

        lwch.Text = output

    End Sub

    Private Sub uw1(ByVal listaleksewn As String, ByVal datas As String, ByRef uw As ArrayList)
        Dim ll As String = ""
        Dim w() As String
        Dim a(800) As String

        texttovar(listaleksewn, ll)
        ll.Replace(" "c, "")

        s = datas.Split(vbNewLine)
        w = ll.Split(vbNewLine)
        For i = 0 To UBound(w)
            a(i) = w(i)
        Next

        uw.Clear()
        a(w.Length) = a(0)

        For i = 0 To w.Length

            uw.Add(0)

        Next


        Dim j As Int32




        For i = 0 To lekseis - 1

            For j = 1 To w.Length
                If s(i).Contains(a(j)) Then
                    uw.Item(j) += 1
                End If
            Next


            'If w.Contains(s(i)) Then
            '    j = Array.IndexOf(w, s(i))
            '    uw.Item(j) += 1
            'End If

        Next



        ''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''
        For i = 1 To w.Length

            uw.Item(i) = (uw.Item(i) / lekseis) * 100


        Next
        ''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''


        '''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''

        Dim output As String = ""

        For i = 1 To w.Length
            output &= a(i) & " :   " & uw.Item(i) & vbNewLine
        Next

        wordfr.Text = output

        '''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''



    End Sub

    
    Private Sub w_sort(ByVal n As Int32, ByVal w() As Int32, ByVal typearray() As String, ByRef sortedtype() As String, ByRef sortedfreq() As Int32, ByVal typecount As Int32)
        Dim max As Int32
        Dim fr() As Int32
        Dim ind As Int32
        Dim output As String = ""

        fr = w

        For i = 0 To n - 1
            max = fr(0)
            For j = 1 To typecount
                If max < fr(j) Then
                    max = fr(j)
                    ind = j

                End If
            Next
            sortedfreq(i) = max
            sortedtype(i) = typearray(ind)
            fr(ind) = 0

            output &= i & ". " & sortedtype(i) & " : " & sortedfreq(i) & vbNewLine

        Next

        ''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''
        nsix.Text &= output
        ''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''



    End Sub


    Private Sub euresisixnotitwn(ByVal typearray() As String, ByVal w() As Int32, ByVal sortedtypearray() As String, ByVal n As Int32, ByRef sixnotites() As Single)
        Dim ind As Int32 = 0
        Dim output As String = ""
        Dim temp As String
        Dim fr() As Int32
        Dim textfreq(5000) As Int32
        fr = w

        For i = 0 To n - 1
            temp = sortedtypearray(i)

            ind = Array.IndexOf(typearray, temp)


            If ind = -1 Then  'den vrethike
                textfreq(i) = 0
            Else
                textfreq(i) = fr(ind)
            End If


        Next

        For i = 0 To n - 1
            sixnotites(i) = (textfreq(i) / lekseis) * 100
            output &= i & ". " & sortedtypearray(i) & " : " & textfreq(i) & " : " & sixnotites(i) & vbNewLine
        Next


        nsix.Text &= output
    End Sub


    Private Sub testform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        lw_c.Add(0)
        For i = 1 To 20
            lw_c.Add(0)
        Next

    End Sub


   
End Class
