﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class testform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.openbtn = New System.Windows.Forms.Button()
        Me.executebtn = New System.Windows.Forms.Button()
        Me.exitbtn = New System.Windows.Forms.Button()
        Me.wText = New System.Windows.Forms.TextBox()
        Me.wclbl = New System.Windows.Forms.Label()
        Me.ttrlbl = New System.Windows.Forms.Label()
        Me.type = New System.Windows.Forms.Label()
        Me.awllbl = New System.Windows.Forms.Label()
        Me.wlcsd = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.origtext = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.awltext = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.stext = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.sl_sd = New System.Windows.Forms.TextBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.ad = New System.Windows.Forms.TextBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.lwch = New System.Windows.Forms.TextBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.wordfr = New System.Windows.Forms.TextBox()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.nsix = New System.Windows.Forms.TextBox()
        Me.sl = New System.Windows.Forms.Label()
        Me.slsdlbl = New System.Windows.Forms.Label()
        Me.dislbl = New System.Windows.Forms.Label()
        Me.apaxlbl = New System.Windows.Forms.Label()
        Me.apax_dis = New System.Windows.Forms.Label()
        Me.LDtxt = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.SuspendLayout()
        '
        'openbtn
        '
        Me.openbtn.Location = New System.Drawing.Point(12, 376)
        Me.openbtn.Name = "openbtn"
        Me.openbtn.Size = New System.Drawing.Size(75, 23)
        Me.openbtn.TabIndex = 0
        Me.openbtn.Text = "Άνοιγμα"
        Me.openbtn.UseVisualStyleBackColor = True
        '
        'executebtn
        '
        Me.executebtn.Location = New System.Drawing.Point(127, 376)
        Me.executebtn.Name = "executebtn"
        Me.executebtn.Size = New System.Drawing.Size(75, 23)
        Me.executebtn.TabIndex = 1
        Me.executebtn.Text = "Εκτέλεση"
        Me.executebtn.UseVisualStyleBackColor = True
        '
        'exitbtn
        '
        Me.exitbtn.Location = New System.Drawing.Point(235, 376)
        Me.exitbtn.Name = "exitbtn"
        Me.exitbtn.Size = New System.Drawing.Size(75, 23)
        Me.exitbtn.TabIndex = 2
        Me.exitbtn.Text = "Έξοδος"
        Me.exitbtn.UseVisualStyleBackColor = True
        '
        'wText
        '
        Me.wText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.wText.Location = New System.Drawing.Point(3, 3)
        Me.wText.Multiline = True
        Me.wText.Name = "wText"
        Me.wText.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.wText.Size = New System.Drawing.Size(376, 319)
        Me.wText.TabIndex = 3
        '
        'wclbl
        '
        Me.wclbl.AutoSize = True
        Me.wclbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.wclbl.Location = New System.Drawing.Point(423, 26)
        Me.wclbl.Name = "wclbl"
        Me.wclbl.Size = New System.Drawing.Size(85, 17)
        Me.wclbl.TabIndex = 4
        Me.wclbl.Text = "Wordcount :"
        '
        'ttrlbl
        '
        Me.ttrlbl.AutoSize = True
        Me.ttrlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.ttrlbl.Location = New System.Drawing.Point(423, 55)
        Me.ttrlbl.Name = "ttrlbl"
        Me.ttrlbl.Size = New System.Drawing.Size(48, 17)
        Me.ttrlbl.TabIndex = 5
        Me.ttrlbl.Text = "TTR : "
        '
        'type
        '
        Me.type.AutoSize = True
        Me.type.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.type.Location = New System.Drawing.Point(423, 84)
        Me.type.Name = "type"
        Me.type.Size = New System.Drawing.Size(54, 17)
        Me.type.TabIndex = 6
        Me.type.Text = "types : "
        '
        'awllbl
        '
        Me.awllbl.AutoSize = True
        Me.awllbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.awllbl.Location = New System.Drawing.Point(423, 114)
        Me.awllbl.Name = "awllbl"
        Me.awllbl.Size = New System.Drawing.Size(36, 17)
        Me.awllbl.TabIndex = 7
        Me.awllbl.Text = "awl :"
        '
        'wlcsd
        '
        Me.wlcsd.AutoSize = True
        Me.wlcsd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.wlcsd.Location = New System.Drawing.Point(423, 146)
        Me.wlcsd.Name = "wlcsd"
        Me.wlcsd.Size = New System.Drawing.Size(68, 16)
        Me.wlcsd.TabIndex = 8
        Me.wlcsd.Text = "WL_Csd : "
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Location = New System.Drawing.Point(12, 1)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(390, 369)
        Me.TabControl1.TabIndex = 9
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.origtext)
        Me.TabPage4.Location = New System.Drawing.Point(4, 40)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(382, 325)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "orig text"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'origtext
        '
        Me.origtext.Dock = System.Windows.Forms.DockStyle.Fill
        Me.origtext.Location = New System.Drawing.Point(3, 3)
        Me.origtext.Multiline = True
        Me.origtext.Name = "origtext"
        Me.origtext.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.origtext.Size = New System.Drawing.Size(376, 319)
        Me.origtext.TabIndex = 4
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.wText)
        Me.TabPage1.Location = New System.Drawing.Point(4, 40)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(382, 325)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "words"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.awltext)
        Me.TabPage2.Location = New System.Drawing.Point(4, 40)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(382, 325)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "awl"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'awltext
        '
        Me.awltext.Dock = System.Windows.Forms.DockStyle.Fill
        Me.awltext.Location = New System.Drawing.Point(3, 3)
        Me.awltext.Multiline = True
        Me.awltext.Name = "awltext"
        Me.awltext.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.awltext.Size = New System.Drawing.Size(376, 319)
        Me.awltext.TabIndex = 4
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.stext)
        Me.TabPage3.Location = New System.Drawing.Point(4, 40)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(382, 325)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "sentences"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'stext
        '
        Me.stext.Dock = System.Windows.Forms.DockStyle.Fill
        Me.stext.Location = New System.Drawing.Point(0, 0)
        Me.stext.Multiline = True
        Me.stext.Name = "stext"
        Me.stext.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.stext.Size = New System.Drawing.Size(382, 325)
        Me.stext.TabIndex = 4
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.sl_sd)
        Me.TabPage5.Location = New System.Drawing.Point(4, 40)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(382, 325)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Slsd"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'sl_sd
        '
        Me.sl_sd.Dock = System.Windows.Forms.DockStyle.Fill
        Me.sl_sd.Location = New System.Drawing.Point(3, 3)
        Me.sl_sd.Multiline = True
        Me.sl_sd.Name = "sl_sd"
        Me.sl_sd.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.sl_sd.Size = New System.Drawing.Size(376, 319)
        Me.sl_sd.TabIndex = 5
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.ad)
        Me.TabPage6.Location = New System.Drawing.Point(4, 40)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(382, 325)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "apax/dis"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'ad
        '
        Me.ad.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ad.Location = New System.Drawing.Point(3, 3)
        Me.ad.Multiline = True
        Me.ad.Name = "ad"
        Me.ad.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.ad.Size = New System.Drawing.Size(376, 319)
        Me.ad.TabIndex = 6
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.lwch)
        Me.TabPage7.Location = New System.Drawing.Point(4, 40)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(382, 325)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "lw chars"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'lwch
        '
        Me.lwch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lwch.Location = New System.Drawing.Point(3, 3)
        Me.lwch.Multiline = True
        Me.lwch.Name = "lwch"
        Me.lwch.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.lwch.Size = New System.Drawing.Size(376, 319)
        Me.lwch.TabIndex = 6
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.wordfr)
        Me.TabPage8.Location = New System.Drawing.Point(4, 40)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(382, 325)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "wordlist frequency"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'wordfr
        '
        Me.wordfr.Dock = System.Windows.Forms.DockStyle.Fill
        Me.wordfr.Location = New System.Drawing.Point(3, 3)
        Me.wordfr.Multiline = True
        Me.wordfr.Name = "wordfr"
        Me.wordfr.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.wordfr.Size = New System.Drawing.Size(376, 319)
        Me.wordfr.TabIndex = 0
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.nsix)
        Me.TabPage9.Location = New System.Drawing.Point(4, 40)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(382, 325)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "n sixnoteres"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'nsix
        '
        Me.nsix.Dock = System.Windows.Forms.DockStyle.Fill
        Me.nsix.Location = New System.Drawing.Point(3, 3)
        Me.nsix.Multiline = True
        Me.nsix.Name = "nsix"
        Me.nsix.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.nsix.Size = New System.Drawing.Size(376, 319)
        Me.nsix.TabIndex = 0
        '
        'sl
        '
        Me.sl.AutoSize = True
        Me.sl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.sl.Location = New System.Drawing.Point(423, 178)
        Me.sl.Name = "sl"
        Me.sl.Size = New System.Drawing.Size(30, 16)
        Me.sl.TabIndex = 10
        Me.sl.Text = "SL: "
        '
        'slsdlbl
        '
        Me.slsdlbl.AutoSize = True
        Me.slsdlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.slsdlbl.Location = New System.Drawing.Point(423, 206)
        Me.slsdlbl.Name = "slsdlbl"
        Me.slsdlbl.Size = New System.Drawing.Size(48, 16)
        Me.slsdlbl.TabIndex = 11
        Me.slsdlbl.Text = "SLsd : "
        '
        'dislbl
        '
        Me.dislbl.AutoSize = True
        Me.dislbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.dislbl.Location = New System.Drawing.Point(423, 265)
        Me.dislbl.Name = "dislbl"
        Me.dislbl.Size = New System.Drawing.Size(72, 16)
        Me.dislbl.TabIndex = 12
        Me.dislbl.Text = "Perc_Dis : "
        '
        'apaxlbl
        '
        Me.apaxlbl.AutoSize = True
        Me.apaxlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.apaxlbl.Location = New System.Drawing.Point(423, 235)
        Me.apaxlbl.Name = "apaxlbl"
        Me.apaxlbl.Size = New System.Drawing.Size(81, 16)
        Me.apaxlbl.TabIndex = 13
        Me.apaxlbl.Text = "Perc_Hapl : "
        '
        'apax_dis
        '
        Me.apax_dis.AutoSize = True
        Me.apax_dis.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.apax_dis.Location = New System.Drawing.Point(423, 293)
        Me.apax_dis.Name = "apax_dis"
        Me.apax_dis.Size = New System.Drawing.Size(73, 16)
        Me.apax_dis.TabIndex = 14
        Me.apax_dis.Text = "Dis_Hapl : "
        '
        'LDtxt
        '
        Me.LDtxt.AutoSize = True
        Me.LDtxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LDtxt.Location = New System.Drawing.Point(425, 328)
        Me.LDtxt.Name = "LDtxt"
        Me.LDtxt.Size = New System.Drawing.Size(34, 16)
        Me.LDtxt.TabIndex = 15
        Me.LDtxt.Text = "LD : "
        '
        'testform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(603, 411)
        Me.Controls.Add(Me.LDtxt)
        Me.Controls.Add(Me.apax_dis)
        Me.Controls.Add(Me.apaxlbl)
        Me.Controls.Add(Me.dislbl)
        Me.Controls.Add(Me.slsdlbl)
        Me.Controls.Add(Me.sl)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.wlcsd)
        Me.Controls.Add(Me.awllbl)
        Me.Controls.Add(Me.type)
        Me.Controls.Add(Me.ttrlbl)
        Me.Controls.Add(Me.wclbl)
        Me.Controls.Add(Me.exitbtn)
        Me.Controls.Add(Me.executebtn)
        Me.Controls.Add(Me.openbtn)
        Me.Name = "testform"
        Me.Text = "Testform"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents openbtn As System.Windows.Forms.Button
    Friend WithEvents executebtn As System.Windows.Forms.Button
    Friend WithEvents exitbtn As System.Windows.Forms.Button
    Friend WithEvents wText As System.Windows.Forms.TextBox
    Friend WithEvents wclbl As System.Windows.Forms.Label
    Friend WithEvents ttrlbl As System.Windows.Forms.Label
    Friend WithEvents type As System.Windows.Forms.Label
    Friend WithEvents awllbl As System.Windows.Forms.Label
    Friend WithEvents wlcsd As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents awltext As System.Windows.Forms.TextBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents stext As System.Windows.Forms.TextBox
    Friend WithEvents sl As System.Windows.Forms.Label
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents sl_sd As System.Windows.Forms.TextBox
    Friend WithEvents slsdlbl As System.Windows.Forms.Label
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents origtext As System.Windows.Forms.TextBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents ad As System.Windows.Forms.TextBox
    Friend WithEvents lwch As System.Windows.Forms.TextBox
    Friend WithEvents dislbl As System.Windows.Forms.Label
    Friend WithEvents apaxlbl As System.Windows.Forms.Label
    Friend WithEvents apax_dis As System.Windows.Forms.Label
    Friend WithEvents LDtxt As System.Windows.Forms.Label
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents wordfr As System.Windows.Forms.TextBox
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents nsix As System.Windows.Forms.TextBox

End Class
