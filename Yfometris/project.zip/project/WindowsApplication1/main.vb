﻿Imports System.Net.Mime.MediaTypeNames
Imports System.IO


Public Class program

    Dim filetoopen As String
    Dim filesaved As String
    Dim exceltoopen, msg21, msg22, msg3 As String
    Dim oeo As String = ""
    'Start a new workbook in Excel.
    Dim oXL As Microsoft.Office.Interop.Excel.Application
    Dim oWB As Microsoft.Office.Interop.Excel.Workbook
    Dim oSheet As Microsoft.Office.Interop.Excel.Worksheet
    Dim orng As Microsoft.Office.Interop.Excel.Range
    Dim irow As Long
    Dim icol As Long
    Dim path As String
    Dim arxeio, fakelos, epilogi As Boolean
    Dim textcol As String
    Dim frm As columnselectionfrm
    Dim passdata As String
    Dim s() As String
    Dim dt As New System.Data.DataTable("dtExcel")
    Dim result As New System.Data.DataTable("result")
    Dim s1data As New System.Data.DataTable("sub1")
    Dim s2data As New System.Data.DataTable("sub2")
    Dim s3data As New System.Data.DataTable("sub3")
    Dim s4data As New System.Data.DataTable("sub4")

    Dim ds As New DataSet()
    Dim dr As DataRow
    Dim lw_c As New ArrayList
    Dim keimeno As String
    Dim s_keimeno As String
    Dim file1 As String
    Dim lekseis As Int32
    Dim sln As Single
    Dim apax, dis As Int32
    Dim max As Int32
    Dim m As Single
    Dim newfile As Boolean
    Dim subcount As Int32 = 0
    Dim s1activated As Boolean = False
    Dim s2activated As Boolean = False
    Dim s3activated As Boolean = False
    Dim s4activated As Boolean = False
    Dim listaleksewn As String = ""
    Dim uw As New ArrayList
    Dim a(800) As String

    Dim sinolokeimenwn As String
    Dim sinolotypearray() As String
    Dim sinolosixnotitwn() As Int32
    Dim sinolofreq() As Int32
    Dim w() As Int32
    Dim sinolotypwn As Int32
    Dim types As Int32

    Dim n As Int32
    Dim sortedtype() As String
    Dim sortedfreq() As Int32
    Dim freq() As Int32
    Dim freq2() As Int32
    Dim sixnot() As Double
    Dim mx As Int32
    Dim processingfile As String


    Private Sub Form1_close(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.FormClosing
        Dim int2 As Integer

        quit(int2)

        If int2 <> vbYes Then
            e.Cancel = True
        End If
    End Sub

    Private Sub selectallbutton_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles selectallbutton.Click
        var1.Checked = True
        var2.Checked = True
        var3.Checked = True
        'var4.Checked = True
        'var5.Checked = True
        var6.Checked = True
        var7.Checked = True
        var8.Checked = True
        var9.Checked = True
        var10.Checked = True
        var11.Checked = True
        var12.Checked = True
        'var13.Checked = True
        var14.Checked = True
        var15.Checked = True
        var16.Checked = True
        var17.Checked = True

    End Sub

    Private Sub selectnonebutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles selectnonebutton.Click
        var1.Checked = False
        var2.Checked = False
        var3.Checked = False
        'var4.Checked = False
        'var5.Checked = False
        var6.Checked = False
        var7.Checked = False
        var8.Checked = False
        var9.Checked = False
        var10.Checked = False
        var11.Checked = False
        var12.Checked = False
        'var13.Checked = False
        var14.Checked = False
        var15.Checked = False
        var16.Checked = False
        var17.Checked = False
    End Sub

    Private Sub Variablesmenu_cick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Variablesmenu.Click

        Tabs.Visible = True
        varpanel.Visible = True
    End Sub

    Private Sub cancelbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        varpanel.Visible = False
    End Sub

    Private Sub GreekMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Greekmenu.Click
        Greekmenu.Checked = True
        Englishmenu.Checked = False
        Italianmenu.Checked = False
        Validatefilemenu.Text = "Επικύρωση Αρχείων"
        Filemenu.Text = "Σώμα"
        openexcelmenu.Text = "'Ανοιγμα αρχείου Excel"

        overviewmenu1.Text = "Επισκόπηση"
        OverviewMenu.Text = "Επισκόπηση"
        Saveasmenu.Text = "Αποθήκευση ως"

        Closemenu.Text = "Κλείσιμο"
        Quittmenu.Text = "Έξοδος"
        virtualcorpusmenu.Text = "Υπόσωμα"
        Newmenu.Text = "Νέο"
        Activatemenu.Text = "Ενεργοποίηση"
        Deletemenu.Text = "Διαγραφή"
        Variablesmenu.Text = "Μεταβλητές"
        Executemenu.Text = "Εκτέλεση"
        Languagemenu.Text = "Γλώσσα"
        Englishmenu.Text = "Αγγλικά"
        Greekmenu.Text = "Ελληνικά"
        Italianmenu.Text = "Ιταλικά"
        Helpmenu.Text = "Βοήθεια"
        Aboutmenu.Text = "Σχετικά"
        IndexOfHelpmenu.Text = "Θέματα Στη Βοήθεια"
        selectallbutton.Text = "Επιλογή Όλων"
        selectnonebutton.Text = "Άποεπιλογή όλων"
        tab1.Text = "Απλές Μεταβλητές"
        Tab2.Text = "Επώνυμες Μεταβλητές"
        TabPage1.Text = "Παραμετροποίηση"
        opendir.Text = "Επιλογή φακέλου αρχείων"
        directorylbl.Text = "Φάκελος"
        excellbl.Text = "Αρχείο Excel"
        Aboutmenu.Text = "Σχετικά με το Text Analysis"
        Form4.closebtn.Text = "Κλείσιμο"
        Form4.excelbtn.Text = "Αποθήκευση σε Excel"
        cancelbtn.Text = "Ακύρωση"


        Form4.Text = "Επισκόπηση Σώματος"
        If statusdir.Text = "Not Selected" Or statusdir.Text = "Non sono stati selezionati" Then
            statusdir.Text = "Δεν έχει επιλεχθεί"
        End If
        If statusfile.Text = "Not Selected" Or statusfile.Text = "Non sono stati selezionati" Then
            statusfile.Text = "Δεν έχει επιλεχθεί"
        End If

        Select Case dtlbl.Text
            Case 0
                Corpus.Text = "Κυριώς σώμα επιλεγμένο"
            Case 1
                Corpus.Text = "Το υπόσωμα : " & actSub1.Text & " , ενεργοποιήθηκε"
            Case 2
                Corpus.Text = "Το υπόσωμα : " & actSub2.Text & " , ενεργοποιήθηκε"
            Case 3
                Corpus.Text = "Το υπόσωμα : " & actSub3.Text & " , ενεργοποιήθηκε"
            Case 4
                Corpus.Text = "Το υπόσωμα : " & actSub4.Text & " , ενεργοποιήθηκε"
        End Select







    End Sub

    Private Sub Englishmenu_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Englishmenu.Click
        Greekmenu.Checked = False
        Validatefilemenu.Text = "File Validation"
        Englishmenu.Checked = True
        Italianmenu.Checked = False
        Filemenu.Text = "File"
        openexcelmenu.Text = "Open Excel File"

        overviewmenu1.Text = "Overview"
        OverviewMenu.Text = "Overview"
        Saveasmenu.Text = "Save as"

        Closemenu.Text = "Close"
        Quittmenu.Text = "Quit"
        virtualcorpusmenu.Text = "Sub-Corpus"
        Newmenu.Text = "New"
        Activatemenu.Text = "Activate"
        Deletemenu.Text = "Delete"
        Variablesmenu.Text = "Variables"
        Executemenu.Text = "Execute"
        Languagemenu.Text = "Language"
        Englishmenu.Text = "English"
        Greekmenu.Text = "Greek"
        Italianmenu.Text = "Italian"
        Helpmenu.Text = "Help"
        Aboutmenu.Text = "About"
        IndexOfHelpmenu.Text = "Index Of Help"
        selectallbutton.Text = "Select All"
        selectnonebutton.Text = "Select None"
        tab1.Text = "Simple Variables"
        Tab2.Text = "Named Variables"
        TabPage1.Text = "Customisation"
        opendir.Text = "Select text Directory"
        directorylbl.Text = "Directory"
        excellbl.Text = "Excel File"
        Aboutmenu.Text = "About Text Analysis"
        Form4.closebtn.Text = "Close"
        Form4.excelbtn.Text = "Save To Excel"
        cancelbtn.Text = "cancel"

        If statusdir.Text = "Δεν έχει επιλεχθεί" Or statusdir.Text = "Non sono stati selezionati" Then
            statusdir.Text = "Not Selected"
        End If
        If statusfile.Text = "Δεν έχει επιλεχθεί" Or statusfile.Text = "Non sono stati selezionati" Then
            statusfile.Text = "Not Selected"
        End If

        Select Case dtlbl.Text
            Case 0
                Corpus.Text = "Main corpus selected"
            Case 1
                Corpus.Text = "SubCorpus : " & actSub1.Text & " , Activated "
            Case 2
                Corpus.Text = "SubCorpus : " & actSub2.Text & " , Activated "
            Case 3
                Corpus.Text = "SubCorpus : " & actSub3.Text & " , Activated "
            Case 4
                Corpus.Text = "SubCorpus : " & actSub4.Text & " , Activated "

        End Select






    End Sub

    Private Sub Italianmenu_cick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Italianmenu.Click
        Greekmenu.Checked = False
        Englishmenu.Checked = False
        Italianmenu.Checked = True
        Filemenu.Text = "Corpus"
        openexcelmenu.Text = "Aperta Excel"
        Validatefilemenu.Text = "Corpus Convalida"
        overviewmenu1.Text = "Panoramica"
        OverviewMenu.Text = "Panoramica"

        Saveasmenu.Text = "Salva con nome"
        Closemenu.Text = "Chiudere"
        Quittmenu.Text = "Uscita"
        virtualcorpusmenu.Text = "Sotto Corpus "
        Newmenu.Text = "Nuovo"
        Activatemenu.Text = "attivare"
        Deletemenu.Text = "Elimina"
        Variablesmenu.Text = "Variabili"
        Executemenu.Text = "Eseguire"
        Languagemenu.Text = "Lingua"
        Englishmenu.Text = "Inglese"
        Greekmenu.Text = "Greco"
        Italianmenu.Text = "Italiano"
        Helpmenu.Text = "Aiuto"
        Aboutmenu.Text = "Informazioni"
        IndexOfHelpmenu.Text = "Indice della Guida"
        selectallbutton.Text = "Seleziona tutto"
        selectnonebutton.Text = "Seleziona Nessuno"
        tab1.Text = "Simple Variables"
        Tab2.Text = "Named Variables"
        TabPage1.Text = "Customisation"
        opendir.Text = "Aperta Directory"
        directorylbl.Text = "Directory"
        excellbl.Text = "Excel File"
        Aboutmenu.Text = " Text Analysis"
        Form4.closebtn.Text = "Chiudere "
        Form4.excelbtn.Text = "Salvare in formato excel"
        cancelbtn.Text = "Annulla"

        Form4.Text = "Corpus Panoramica"
        If statusdir.Text = "Δεν έχει επιλεχθεί" Or statusdir.Text = "Not Selected" Then
            statusdir.Text = "Non sono stati selezionati"
        End If
        If statusfile.Text = "Δεν έχει επιλεχθεί" Or statusfile.Text = "Not Selected" Then
            statusfile.Text = "Non sono stati selezionati"
        End If

        Select Case dtlbl.Text
            Case 0
                Corpus.Text = "Corpus principale selezionato"
            Case 1
                Corpus.Text = "SubCorpus : " & actSub1.Text & " , attivato"
            Case 2
                Corpus.Text = "SubCorpus : " & actSub2.Text & " , attivato"
            Case 3
                Corpus.Text = "SubCorpus : " & actSub3.Text & " , attivato"
            Case 4
                Corpus.Text = "SubCorpus : " & actSub4.Text & " , attivato"
        End Select

    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub Saveasmenu_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Saveasmenu.Click
        Dim oxl1 As Microsoft.Office.Interop.Excel.Application
        Dim oWB1 As Microsoft.Office.Interop.Excel.Workbook
        Dim oSheet1 As Microsoft.Office.Interop.Excel.Worksheet
        Dim dttosave As System.Data.DataTable = dt

        Select Case tosave.Text
            Case 1
                dttosave = s1data
            Case 2
                dttosave = s2data
            Case 3
                dttosave = s3data
            Case 4
                dttosave = s4data
            Case 0
                Select Case dtlbl.Text
                    Case 0
                        dttosave = dt
                    Case 1
                        dttosave = s1data
                    Case 2
                        dttosave = s2data
                    Case 3
                        dttosave = s3data
                    Case 4
                        dttosave = s4data

                End Select


        End Select
        Dim eng, gr, it, output As String
        Dim savefileasdlg As New SaveFileDialog
        oxl1 = New Microsoft.Office.Interop.Excel.Application
        oxl1.DisplayAlerts = False
        owb1 = oxl1.Workbooks.Add
        oSheet1 = DirectCast(oWB1.ActiveSheet, Microsoft.Office.Interop.Excel.Worksheet)


        savefileasdlg.Filter = "All Microsoft Office Excel Files(*.xl*)|*.*xl*"


        savefileasdlg.AddExtension = True
        savefileasdlg.DefaultExt = "xls"

        Dim rowsc As Int32 = dttosave.Rows.Count
        Dim colc As Int32 = dttosave.Columns.Count
        Dim max As Int32 = rowsc * colc

        Form4.prb.Maximum = max
        Form4.prb.Value = 0
        prb.Maximum = max
        prb.Value = 0
        Dim errorpresented As String = ""
        If savefileasdlg.ShowDialog = Windows.Forms.DialogResult.OK Then


            ''''''''''''''''''''''' Creating text files saving confirmation dialogue '''''''''''''''
            Dim intResponse As Integer
            Dim message As String = ""
            Dim title As String = ""

            eng = "Do you wish to save the text files as well?" & vbNewLine & vbNewLine _
                & " if you choose yes , a directory will be created " & vbNewLine & "with the same name as the excel file"
            gr = "Θέλετε να σώσετε και τα αρχεία κείμενου?" & vbNewLine & vbNewLine _
                & "Αν επιλεξετε ΝΑΙ , θα δημιουργηθεί είνας φάκελος " & vbNewLine & "με το ίδιο όνομα όπως το αρχείο excel"
            it = "Non si vuole salvare il file di testo?" & vbNewLine & vbNewLine _
                & " Se si sceglie sì, sarà creata una directory" & vbNewLine & "Con lo stesso nome del file excel"

            translate(message, eng, gr, it)
            translate(title, "Text files saving Confirmation", "Επιβεβαίωση αποθήκευσης αρχείων κειμένου", "Salvare i file di testo conferma")
            intResponse = MsgBox(message, vbYesNo + vbQuestion + vbDefaultButton2, title)

            '--------------------------------------------------------------------------------------------
            Try
                filesaved = savefileasdlg.FileName
                Form4.prb.Show()
                savebarpanel.Visible = True
                ' Create the data rows 
                Dim rowCount As Integer = 1
                Dim stiliarxeiwn As Int32 = statusindex.Text - 1

                Dim testarray(100) As String
                Dim sourcefile As String = ""
                Dim destfile As String = ""
                Dim temppathfile As String
                Dim directorysaved As String = ""
                Dim filetosave As String = ""

                If intResponse = vbYes Then

                    '''''''find the dir to save texts using an array to trim the xls'''''''''''

                    testarray = filesaved.Split(".xls")
                    directorysaved = testarray(0)
                    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                    '------------directory creation check ( if it exists or not) -----------------

                    If Not System.IO.Directory.Exists(directorysaved) Then
                        System.IO.Directory.CreateDirectory(directorysaved)
                    End If
                    '-------------------------------------------------------------------------------
                End If

                For Each dr As DataRow In dttosave.Rows

                    If intResponse = vbYes Then
                        temppathfile = dr(stiliarxeiwn)
                        sourcefile = check(temppathfile)


                        '''''''''''i need the same array to cut the path''''''''''''''''''

                        destfile = directorysaved & "\" & dr(stiliarxeiwn)
                        ' MsgBox(sourcefile & vbNewLine & destfile)

                        Try
                            File.Copy(sourcefile, destfile, True)
                        Catch oups As Exception
                            errorpresented &= dr(stiliarxeiwn) & vbNewLine
                        End Try
                        '----------------------------------------------------------------
                    End If

                    rowCount += 1
                    For i As Integer = 1 To dttosave.Columns.Count
                        ' Add the header the first time through 
                        If rowCount = 2 Then
                            oSheet1.Cells(1, i) = dttosave.Columns(i - 1).ColumnName
                        End If
                        oSheet1.Cells(rowCount, i) = dr.Item(i - 1)
                        prb.Value += 1
                        Form4.prb.Value += 1
                    Next

                Next
                Form4.prb.Hide()
                savebarpanel.Visible = False

                oWB1.SaveAs(filesaved)
                oxl1.DisplayAlerts = True
                oWB1.Close()
                oxl1.Quit()
                oSheet1 = Nothing
                oWB1 = Nothing
                oxl1 = Nothing
                GC.WaitForPendingFinalizers()
                GC.Collect()

                'exceltoopen = filesaved
                'oWB = oXL.Workbooks.Open(exceltoopen)
                'oSheet = oWB.Worksheets(0)
                statusfile.Text = filesaved
                filesaved = ""
            Catch ex As Exception
                Form4.prb.Hide()
                savebarpanel.Visible = False
                eng = "Unable to save.. please try again" & vbNewLine
                gr = " Αδυναμία αποθήκευσης.. Παρακαλώ ξαναπροσπαθήστε" & vbNewLine
                it = "In grado di salvare..Vi preghiamo di provare di nuovo" & vbNewLine
                output = ""
                translate(output, eng, gr, it)

                MsgBox(output & vbNewLine & ex.ToString)
            End Try
            If Not errorpresented = "" Then

                eng = "The following files allready existed  and could not be overwritten"
                gr = "Τα παρακάτω αρχεία υπήρχαν ήδη και δεν ήταν δυνατό να επαναγραφούν"
                it = "I seguenti file gia esistenti e non potrebbe essere sovrascritto"
                msg21 = ""
                translate(msg21, eng, gr, it)
                MsgBox(msg21 & vbNewLine & errorpresented)
            End If

        End If

    End Sub

    Private Sub Closemenu_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Closemenu.Click
        statusdir.Visible = False
        stext.Text = ""
        varpanel.Visible = False
        virtualcorpusmenu.Enabled = False
        Variablesmenu.Enabled = False
        Executemenu.Enabled = False
        OverviewMenu.Enabled = False
        Closemenu.Enabled = False
        Saveasmenu.Enabled = False
        Validatefilemenu.Enabled = False

        exceltoopen = ""
        Corpus.Text = ""

        Dim output10 As String = ""
        Dim eng, gr, it As String
        eng = "Not selected"
        gr = "Δεν έχει επιλεχθεί"
        it = ""
        translate(output10, eng, gr, it)
        statusfile.Text = output10
        statusdir.Text = output10


    End Sub

    Private Sub openexcelmenu_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles openexcelmenu.Click
        If Not (oSheet Is Nothing) Then
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oSheet)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oXL)
            oSheet = Nothing
            oWB = Nothing
            oXL = Nothing
            GC.Collect()
        End If

        'Open excel

        Dim openexceldlg As New OpenFileDialog
        openexceldlg.Filter = "All Microsoft Office Excel Files(*.xl*)|*.*xl*"
        Dim sfile As String = ""
        If openexceldlg.ShowDialog = Windows.Forms.DialogResult.OK Then
            columnselectionfrm.combo.Items.Clear()
            ds.Clear()
            dt.Columns.Clear()
            dt.Clear()
            stext.Text = ""
            virtualcorpusmenu.Enabled = False
            Variablesmenu.Enabled = False
            Executemenu.Enabled = False
            OverviewMenu.Enabled = False
            Closemenu.Enabled = False
            Saveasmenu.Enabled = False

            newfile = True
            Try
                exceltoopen = openexceldlg.FileName
                statusfile.Text = exceltoopen
                excellbl.Visible = True
                sfile = exceltoopen
                oXL = New Microsoft.Office.Interop.Excel.Application
                oWB = oXL.Workbooks.Open(exceltoopen)
                oSheet = oWB.Worksheets(1)

                'calculate row and column length
                calcrowcol(irow, icol)

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''Automati epilogi Column arxeiwn''''''''''''''''''''''
                Dim filecolumn As Int32 = 1

                Dim chance As Int32 = 0

                autocolumnselect(filecolumn, chance)

                opendirectory(icol, dt)

                result = dt
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''





                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''' Manual Epilogi column arxeiwn'''''''''''''''''''''''''''''''''


                'create header list
                Try
                    Dim Value_Array(20) As String
                    For j = 1 To icol


                        If oSheet.Cells(1, j).value <> Nothing Then
                            Value_Array(j) = oSheet.Cells(1, j).value
                            'populate combo box
                            columnselectionfrm.combo.Items.Add(Value_Array(j))

                        End If
                    Next



                    columnselectionfrm.combo.SelectedIndex = 0
                Catch ex As Exception

                End Try

                'set message
                Dim output7 As String
                output7 = ""
                Dim eng, gr, it As String
                eng = "Please select the column" & vbNewLine & "where the txt filenames are stored"
                gr = "Παρακαλώ να επιλέξετε την στήλη του excel" & vbNewLine _
                    & "στην οποία βρίσκονται τα ονόματα " _
                    & vbNewLine & "των αρχείων κειμένου"
                it = "Si prega di selezionare " & vbNewLine & _
                    "la colonna dove sono " & vbNewLine & "memorizzati i nomi del testo"
                translate(output7, eng, gr, it)
                columnselectionfrm.prompt.Text = output7

                'set title
                Dim title As String = ""
                eng = "filename column selection"
                gr = "Επιλογή στήλης ονόματος αρχείων"
                it = "selectionare file column"
                translate(title, eng, gr, it)
                columnselectionfrm.Text = title



                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            Catch ex As Exception
                MsgBox(ex.ToString)

            End Try


        ElseIf sfile = "" And MsgBoxResult.Cancel Then

            Dim bartext As String = ""
            exceltoopen = ""
            translate(bartext, "Please select an Excel file", "Παρακαλώ επιλέξτε ένα αρχείο Excel", "Selezioni prego una lima dell'Excel")
            statusfile.Text = bartext
            Validatefilemenu.Enabled = False
        End If




    End Sub

    Private Sub autocolumnselect(ByRef oui As Int32, ByRef chances As Int32)
        Dim alfar As String
        Dim chance As Int32

        For j = 1 To icol
            chance = 0
            For i = 2 To 10
                alfar = oSheet.Cells(i, j).value

                If InStr(1, alfar, ".txt") <> 0 Or InStr(1, alfar, ".txt") <> 0 Then

                    chance += 1
                End If

            Next


            If chance > 5 Then

                oui = j
                chances = chance
                statusindex.Text = oui
            End If

        Next
    End Sub

    Public Sub texttovar(ByVal textname As String, ByRef varname As String)
        Dim fs As FileStream
        Dim sr As StreamReader

        fs = New FileStream(textname, FileMode.Open)
        sr = New StreamReader(fs, System.Text.Encoding.Default)

        varname = sr.ReadToEnd
        fs.Close()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Aboutmenu.Click
        Dim output As String

        output = ""
        Dim eng As String = "This Program is the result" & vbNewLine & "Of a great team work by" _
                            & vbNewLine & "Theodore Doganis" & vbNewLine & "Panagiota Kontovounisiou" & vbNewLine & "Zoi Mentza"
        Dim gr As String = "Αυτό το πρόγραμμα είναι το αποτέλεσμα " & vbNewLine & "Μιας τεράστιας ομαδικής προσπάθειας απο τους" _
                           & vbNewLine & "Θόδωρος Δογάνης" & vbNewLine & "Γιώτα Κοντοβουνίσιου" & vbNewLine & "Ζωή Μεντζά"
        Dim it As String = "Questo programma è il frutto" & vbNewLine & " di un lavoro di grande tema" & _
                                vbNewLine & "Theodore Doganis" & vbNewLine & "Panagiota Kontovounisiou" & vbNewLine & "Zoi Mentza"
        translate(output, eng, gr, it)
        MsgBox(output, vbInformation, _
           "About The Creatorz")
    End Sub

    Private Sub Quittmenu_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Quittmenu.Click
        Dim Int1 As Integer = 15
        quit(Int1)
    End Sub

    Public Sub quit(ByRef int As Integer)
        Dim intResponse As Integer
        Dim message As String = ""
        Dim title As String = ""
        translate(message, "Do you wish to Exit Text Analysis ?", "Θέλετε να βγείτε απο την εφαρμογή ? ", "Desiderate rimuovere Text Analysis")
        translate(title, "Exit Confirmation", "Επιβεβαίωση Εξόδου", "Rimuova la conferma")
        intResponse = MsgBox(message, _
        vbYesNo + vbQuestion + vbDefaultButton2, title)

        If intResponse = vbYes Then
            Try
                If Not oWB Is Nothing Then
                    oWB.Close()
                    oXL.Quit()
                    oSheet = Nothing
                    oWB = Nothing
                    oXL = Nothing
                    GC.Collect()
                End If
                End
            Catch ex As Exception
                MsgBox(ex.ToString)
                End
            End Try

        End If
    End Sub

    Private Sub OverviewMenu_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OverviewMenu.Click
        Dim dttoview As System.Data.DataTable = dt
        Dim output, eng, it, gr As String
        eng = ""
        gr = ""
        it = ""

        Select Case dtlbl.Text
            Case 0
                dttoview = dt
                eng = "Corpus Overview "
                gr = "Επισκοπηση Σώματος "
                it = "Corpus Panoramica  "
            Case 1
                dttoview = s1data
                eng = "Sub-Corpus Overview : " & actSub1.Text
                gr = "Επισκοπηση ΥποΣώματος : " & actSub1.Text
                it = "SubCorpus Panoramica : " & actSub1.Text
            Case 2
                dttoview = s2data
                eng = "Sub-Corpus Overview : " & actSub2.Text
                gr = "Επισκοπηση ΥποΣώματος: " & actSub2.Text
                it = "SubCorpus Panoramica: " & actSub2.Text
            Case 3
                dttoview = s3data
                eng = "Sub-Corpus Overview : " & actSub3.Text
                gr = "Επισκοπηση ΥποΣώματος : " & actSub3.Text
                it = "SubCorpus Panoramica : " & actSub3.Text
            Case 4
                dttoview = s4data
                eng = "Sub-Corpus Overview : " & actSub4.Text
                gr = "Επισκοπηση ΥποΣώματος : " & actSub4.Text
                it = "SubCorpus Panoramica : " & actSub4.Text
        End Select


        output = ""


        translate(output, eng, gr, it)
        Form4.Text = output

        eng = "Close"
        gr = "Κλείσιμο"
        it = "chiudere"
        translate(output, eng, gr, it)
        Form4.closebtn.Text = output

        eng = "Save to Excel"
        gr = "Αποθήκευση σε Excel"
        it = "Salvare in formato excel"
        translate(output, eng, gr, it)

        Form4.excelbtn.Text = output

        'Dim defaultwidth As Int32
        Form4.DataGridView1.DataSource = dttoview
        Dim i As Int32
        For i = 0 To Form4.DataGridView1.Columns.Count - 1
            Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            'defaultwidth = Form4.DataGridView1.Columns(i).Width
            'Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.NotSet
            'Form4.DataGridView1.Columns(i).Width = defaultwidth

        Next

        Me.Enabled = False
        Form4.Show()

        'form6.Text = output
        'oXL.Application.DisplayAlerts = False
        'oWB.EnableAutoRecover = False

        'oWB.SaveCopyAs(Environment.CurrentDirectory.ToString & "t1e2m3p.xls")
        'Try
        '    oWB.SaveCopyAs(Environment.CurrentDirectory.ToString & "t1e2m3p2.xls")
        'Catch ex As Exception
        '    If Not ex.ToString = "" Then
        '        oWB.Save()
        '    End If
        'End Try
        'oWB.Close()
        'oXL.Quit()
        'oWB = Nothing
        'oXL = Nothing
        'oSheet = Nothing

        'GC.Collect()
        'GC.WaitForPendingFinalizers()
        'System.Threading.Thread.Sleep(1000)

        'oXL = New Microsoft.Office.Interop.Excel.Application
        'oWB = oXL.Workbooks.Open(Environment.CurrentDirectory.ToString & "t1e2m3p2.xls")
        'oSheet = oWB.Worksheets(1)
        'form6.ControlBox = False
        'form6.Show()

    End Sub

    Private Function IsFileOpen(ByVal filename As String) As Boolean
        Try
            File.Open(filename, FileMode.Open,
            FileAccess.Read, FileShare.None)
            FileClose(1)
            Return False
        Catch ex As Exception
            Return True
        End Try
    End Function

    Function isOpen(ByVal wbName) As Boolean
        Dim xl As Microsoft.Office.Interop.Excel.Application
        isOpen = False
        On Error Resume Next
        xl = GetObject(, "Excel.Application")
        If Err.Number <> 0 Then Exit Function
        xl.Workbooks(wbName).Activate()
        If Err.Number = 0 Then isOpen = True
    End Function

    Private Sub okbutton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okbutton.Click
        Tabs.Visible = False
    End Sub

    Private Sub reset1enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okbutton.MouseEnter, uwbtn.MouseEnter, selectallbutton.MouseEnter, selectnonebutton.MouseEnter, cancelbtn.MouseEnter, w1btn.MouseEnter, okbtnn.MouseEnter
        Me.Cursor = Cursors.Hand

    End Sub

    Private Sub reset1leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okbutton.MouseLeave, uwbtn.MouseLeave, selectallbutton.MouseLeave, selectnonebutton.MouseLeave, cancelbtn.MouseLeave, w1btn.MouseLeave, okbtnn.MouseLeave
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub ExcelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Excelmenu.Click




        If oXL.Visible = True Then
            oXL.Visible = False
        Else
            oXL.Visible = True

        End If


    End Sub

    Public Sub calcrowcol(ByRef irow, ByRef icol)
        irow = oSheet.Cells(65535, 1).End(Microsoft.Office.Interop.Excel.XlDirection.xlUp).row
        icol = oSheet.Cells(1, 256).End(Microsoft.Office.Interop.Excel.XlDirection.xlToLeft).Column
        columnselectionfrm.icollbl.Text = icol
    End Sub

    Public Sub showrowcol(ByRef irow, ByRef icol)
        Dim lol As String
        lol = ""
        translate(lol, "rows : ", "Γραμμές : ", "File : ")
        msg3 = lol & irow
        translate(lol, "columns : ", "Στήλες : ", "Colonne : ")
        msg3 &= vbNewLine & lol & icol
        MsgBox(msg3, vbOK)
    End Sub

    Public Sub translate(ByRef alfar As String, ByVal eng As String, ByVal gr As String, ByVal it As String)

        If Englishmenu.Checked = True Then
            alfar = eng
        ElseIf Greekmenu.Checked = True Then
            alfar = gr
        ElseIf Italianmenu.Checked = True Then
            alfar = it
        End If

    End Sub

    Public Function check(ByRef input As String) As String
        If input.Contains(":\") = False Then
            Dim dirtxt As String = statusdir.Text
            If dirtxt.Length = 3 Then
                input = dirtxt + input
            Else
                input = dirtxt + "\" + input
            End If

        End If
        If input.EndsWith(".txt") = False Then
            input &= ".txt"
        End If
        check = input
    End Function

    Private Sub selecttextdirmenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles opendir.Click
        opendirectory(icol, dt)
    End Sub

    Public Sub opendirectory(ByRef icol As Int32, ByRef dt As System.Data.DataTable)
        Dim epilogi As Boolean
        If columnselectionfrm.acceptcancel.Text = "ok" Then
            epilogi = True
        Else
            epilogi = False
        End If

        'anoigma fakelou txt

        Dim opendirdlg As New FolderBrowserDialog
        With opendirdlg
            .RootFolder = Environment.SpecialFolder.Desktop
            .SelectedPath = "c:\"
            Dim output5 As String = ""
            translate(output5, "Text Directory Selection", "Επιλογή φακέλου αρχείων κειμένου", "Testo directory selezione")
            .Description = output5
            If .ShowDialog = DialogResult.OK Then
                statusdir.Text = .SelectedPath
                Validatefilemenu.Enabled = True

                validateall(icol, dt)

            Else

                Dim output6, gr1, eng1, it1 As String
                output6 = ""
                gr1 = "Πρέπει να δώσετε φάκελο αρχείων" _
                          & vbNewLine & "Αρχείο -> Επιλογή Φακέλου αρχείων"
                eng1 = "You need to select text foler" _
                    & vbNewLine & "File -> Select Text Directory "
                it1 = "E' necessario selezionare testo directory" _
                    & vbNewLine & "Corpus -> Aperta Directory"
                translate(output6, eng1, gr1, it1)
                MessageBox.Show(output6)

            End If
        End With
    End Sub

    Private Sub Validatefilemenu_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Validatefilemenu.Click
        validateall(icol, dt)


    End Sub

    Private Sub validateall(ByRef icol As Int32, ByRef dt As System.Data.DataTable)

        Dim i, k, j, l, intreply, dellist(100), max As Int32
        Dim notfound(100) As String
        Dim temp, checkfile As String
        icol += 1
        columnselectionfrm.icollbl.Text = icol
        ProgressBar.Value = 0
        max = irow * icol + irow - 1
        ProgressBar.Maximum = max
        percentage.Show()

        ProgressBar.Show()

        job.Show()

        j = statusindex.Text
        k = 0
        l = 0


        oSheet.Cells(1, icol).value = "Words"

        Try
            For i = 2 To irow
                temp = oSheet.Cells(i, j).value
                checkfile = check(temp)
                job.Text = "Checking file :" & temp
                ProgressBar.Value += 1
                percentage.Text = Math.Round(ProgressBar.Value / max * 100) & "%"

                If (File.Exists(checkfile) = False) And (k < 100) Then
                    k = k + 1
                    notfound(k) = checkfile
                    dellist(k) = i + 1 - k
                ElseIf File.Exists(checkfile) Then
                    l = l + 1
                    'find word number and put it to excel file

                    texttovar(checkfile, keimeno)
                    proetoimasia_keimenou(keimeno)
                    simeia_stiksis(keimeno)

                    oSheet.Cells(i, icol).value = words(keimeno)

                End If
            Next


            'missing files report
            If (k = 0) And (l <> 0) Then    ' vrethikahn ola ta arxeia
                createtext(dt)

                Dim title As String = ""
                translate(oeo, "All files are present", "Όλα τα αρχεία είναι παρόντα", "tutte le lime sono presenti")
                msg21 = oeo
                translate(title, "Good News", "Ευχάριστα Νέα", "buone notizie")
                MsgBox(msg21, vbOKOnly + MsgBoxStyle.Information, title)

                'make menus visible
                emfanisemenu()

            ElseIf k <> 0 And l <> 0 Then ' vrethikan kapoia arxeia

                translate(oeo, "The following files are missing", "Τα παρακάτω αρχεία λείπουν", "le seguenti lime mancano")
                msg22 = oeo & vbNewLine


                For i = 1 To k
                    msg22 &= vbNewLine & notfound(i)
                Next

                translate(oeo, "Remove these rows automatically?", "Αυτόματη αφαίρεση γραμμών? ", "rimuova automaticamente le file?")
                msg22 &= vbNewLine + oeo
                translate(oeo, "Missing files Report", "Αναφορά ελλειπόντων αρχείων", "rapporto mancante delle lime")
                intreply = MsgBox(msg22, vbYesNo + MsgBoxStyle.Information, oeo)



                ' file deletion

                If intreply = vbYes Then
                    For j = 1 To k
                        oSheet.Rows(dellist(j)).delete()
                    Next
                    irow = irow - k
                    createtext(dt)
                    emfanisemenu()
                Else
                    ProgressBar.Hide()
                    percentage.Text = ""
                    job.Text = ""

                End If
            ElseIf l = 0 Then  'den vrethikahn arxeia
                job.Text = ""
                ProgressBar.Hide()
                percentage.Text = ""
                selectfilecolumn()

            End If

        Catch ex As Exception

        End Try


    End Sub
    Private Sub selectfilecolumn()

        Dim output8, eng, gr, it As String
        output8 = ""
        eng = "You have chosen a column" + vbNewLine + "without files" _
            + vbNewLine + "or the wrong directory"
        gr = "Έχετε επιλέξει στήλη δίχως " + vbNewLine + "ονόματα αρχείων" _
            + vbNewLine + "'Η λάθος φάκελο αρχείων"
        it = "Lei ha optato colonna senza archivi" _
            + vbNewLine + "o sbagliato file "
        translate(output8, eng, gr, it)
        MsgBox(output8)
        Me.Enabled = False
        columnselectionfrm.Show()

    End Sub


    Private Sub createtext(ByRef dt As System.Data.DataTable)
        Dim i, j As Int32
        Dim l(20) As Int32
        Dim max As Int32
        Dim tmp As String
        Dim passtext As String = ""
        Dim icol As Int32
        icol = columnselectionfrm.icollbl.Text
        passdata = ""
        max = irow * icol + irow - 1
        Dim eng As String = ""
        Dim gr As String = ""
        Dim it As String = ""


        Dim oRng As Microsoft.Office.Interop.Excel.Range

        Try
            '''''''''''text and datatable creation''''''''''''''''''''''''''''''''''''''

            i = 1
            For j = 1 To icol
                '''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''text headers'''''''''''''
                tmp = oSheet.Cells(i, j).value
                'need to check for null entries
                If tmp = Nothing Then
                    tmp = ""
                End If
                job.Text = "creating headers.. " & vbNewLine & "object :" & tmp
                ProgressBar.Value += 1
                percentage.Text = Math.Round(ProgressBar.Value / max * 100) & "%"
                passdata &= tmp & vbTab
                ''''''''''''''''''''''''''''''''''''''''''''
                '''''''''''''''''''''''''''''''''''''''''''


                ''''''''''''datatable headers'''''''''''''''''
                ''''''''''''''''''''''''''''''''''''''''''''''
                Try
                    Dim header As String
                    header = oSheet.Cells(1, j).value
                    dt.Columns.Add(header, System.Type.GetType("System.String"))
                    s1data.Columns.Add(header, System.Type.GetType("System.String"))
                    s2data.Columns.Add(header, System.Type.GetType("System.String"))
                    s3data.Columns.Add(header, System.Type.GetType("System.String"))
                    s4data.Columns.Add(header, System.Type.GetType("System.String"))
                    result.Columns.Add(header, System.Type.GetType("System.String"))
                Catch ex As Exception
                End Try


                ''''''''''''''''''''''''''''''''''''''''''''
                ''''''''''''''''''''''''''''''''''''''''''''

            Next



            passdata = ""
            For i = 2 To irow
                dr = ds.Tables("dtExcel").NewRow()
                For j = 1 To icol

                    ''''''''''''text data''''''''''''
                    '''''''''''''''''''''''''''''''''

                    tmp = oSheet.Cells(i, j).value
                    'need to check for null entries
                    If tmp = Nothing Then
                        tmp = ""
                    End If
                    job.Text = "creating database.. " & vbNewLine & "object :" & tmp
                    ProgressBar.Value += 1
                    percentage.Text = Math.Round(ProgressBar.Value / max * 100) & "%"
                    passdata &= tmp & vbTab

                    '''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''''''''''''''

                    '''''''''datatable data'''''''''''''''
                    ''''''''''''''''''''''''''''''''''''''

                    oRng = CType(oSheet.Cells(i, j), Microsoft.Office.Interop.Excel.Range)
                    dr(oSheet.Cells(1, j).value) = oRng.Text

                    ''''''''''''''''''''''''''''''''''''''
                    '''''''''''''''''''''''''''''''''''''
                Next
                ds.Tables("dtExcel").Rows.Add(dr)
                passdata &= vbNewLine
            Next


        Catch ex As Exception
            eng = "Can not create Database"
            gr = "Αδυναμία δημιουργίας βάσης"
            it = "Non può creare database"
            Dim msg21 As String = ""
            translate(msg21, eng, gr, it)
            MsgBox(msg21 & vbNewLine & "Error : " & ex.ToString)
        End Try

        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        passtext = Environment.CurrentDirectory.ToString & "\passdata.txt"
        Dim grafias As New StreamWriter(passtext)
        grafias.Write(passdata)
        grafias.Close()

        job.Text = ""
        ProgressBar.Hide()
        percentage.Text = ""

        Form4.DataGridView1.DataSource = ds.Tables(0)

        stileslbl.Text = dt.Columns.Count

        Corpus.Visible = True
        msg21 = ""
        eng = "Main corpus selected"
        gr = "Κυριώς σώμα επιλεγμένο"
        it = "Corpus principale selezionato"
        translate(msg21, eng, gr, it)
        Corpus.Text = msg21
        dtlbl.Text = 0
        oXL.DisplayAlerts = False
        oXL.Quit()
        oXL.DisplayAlerts = True
        oSheet = Nothing
        oWB = Nothing
        oXL = Nothing
        GC.Collect()

    End Sub

    Private Sub emfanisemenu()


        virtualcorpusmenu.Enabled = True
        Variablesmenu.Enabled = True
        Executemenu.Enabled = True
        OverviewMenu.Enabled = True
        Closemenu.Enabled = True
        Saveasmenu.Enabled = True

        Validatefilemenu.Enabled = False
        opendir.Enabled = False
    End Sub

    Public Sub program_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ReDim sortedtype(5000)
        ReDim sortedfreq(5000)

        ReDim s(5000)

        ReDim sixnot(100000)
        ReDim freq2(100000)
        ReDim sinolotypearray(100000)
        ReDim sinolofreq(100000)

        ds.Tables.Add(dt)
        lw_c.Add(0)
        For i = 1 To 20
            lw_c.Add(0)
        Next
    End Sub

    Private Sub Newmenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Newmenu.Click
        Try
            form3.Combo1.Items.Clear()
            form3.Combo1.SelectedIndex = -1
            form3.Combo2.Items.Clear()
            form3.Combo2.SelectedIndex = -1
            form3.Combo3.Items.Clear()
            form3.Combo3.SelectedIndex = -1
            form3.Combo4.Items.Clear()
            form3.Combo4.SelectedIndex = -1
            form3.Combo1value.Items.Clear()
            form3.Combo2value.Items.Clear()
            form3.Combo3value.Items.Clear()
            form3.Combo4value.Items.Clear()

            'set parameters for newform
            Dim output9 As String = ""
            Dim eng, gr, it As String
            'title
            eng = "New subcorpus"
            gr = "Νέο Υπόσωμα"
            it = "Nuovo subcorpus"
            translate(output9, eng, gr, it)
            form3.Text = output9
            'header
            eng = "Meta Linguistic Features"
            gr = "Μετακειμενικά Χαρακτηριστικά"
            it = "Meta caratteristiche linguistiche"
            translate(output9, eng, gr, it)
            form3.header.Text = output9
            'wordcount
            eng = "Words per text"
            gr = "Λέξεις ανά αρχείο"
            it = "Parole al testo"
            translate(output9, eng, gr, it)
            form3.wordcountlbl.Text = output9
            'filecount
            eng = "Text File Count"
            gr = "Αριθμός Αρχείων"
            it = "File di testo Conte"
            translate(output9, eng, gr, it)
            form3.textcountlbl.Text = output9

            'subname
            eng = "Sub Corpus Name"
            gr = "Όνομα Υποσώματος"
            it = "Sub nome Corpus"
            translate(output9, eng, gr, it)
            form3.subnamelbl.Text = output9

            'accept button
            eng = "Close"
            gr = "Κλείσιμο"
            it = "chiudere"
            translate(output9, eng, gr, it)
            form3.acceptbtn.Text = output9

            eng = "Subcorpus created !!!"
            gr = "Το υπόσωμα δημιουργήθηκε !!!"
            it = "Subcorpus creato !!!"
            translate(output9, eng, gr, it)
            form3.Created1.Text = output9

            eng = "Quantitative Selection"
            gr = " Ποσοτική Επιλογή"
            it = "Selezione quantitativa"
            translate(output9, eng, gr, it)
            form3.GB1.Text = output9

            eng = "Create"
            gr = "Δημιουργία"
            it = "Creare"
            translate(output9, eng, gr, it)
            form3.createtbn.Text = output9
        Catch ex As Exception
            MsgBox("new menu error start" & ex.ToString)
        End Try
        Try
            Dim j As Int32

            'make a list of headers and of columns
            Dim k As Int32
            Dim combolist(200) As String
            Dim c(200) As Int32
            k = 1
            For j = 1 To stileslbl.Text
                If (j <> statusindex.Text) And (k <= 20) Then
                    'combolist(k) = oSheet.Cells(1, j).value
                    combolist(k) = dt.Columns(j - 1).ColumnName

                    c(k) = j
                    k = k + 1
                End If
            Next

            'populate header combos
            For i = 1 To k - 1
                form3.Combo1.Items.Add(combolist(i))

            Next
            For i = 1 To k - 1
                form3.Combo2.Items.Add(combolist(i))

            Next
            For i = 1 To k - 1
                form3.Combo3.Items.Add(combolist(i))
            Next
            For i = 1 To k - 1
                form3.Combo4.Items.Add(combolist(i))
            Next



        Catch ex As Exception
            MsgBox("new error 1" & ex.ToString)
        End Try

        Try
            form3.Combo1.Text = ""
            form3.Combo2.Text = ""
            form3.Combo3.Text = ""
            form3.Combo4.Text = ""
            form3.Combo1value.Text = ""
            form3.Combo2value.Text = ""
            form3.Combo3value.Text = ""
            form3.Combo4value.Text = ""
        Catch ex As Exception
            MsgBox("new error 2 : arxikopoiisi " & ex.ToString)
        End Try
        Try
            Me.Enabled = False
            form3.Show()
        Catch ex As Exception
            MsgBox("new error 3 : show " & ex.ToString)
        End Try
    End Sub

    Private Sub advselectall_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles advselectall.Click
        advvar1.Checked = True
        advvar2.Checked = True
        advvar3.Checked = True
        advvar4.Checked = True
        advvar5.Checked = True
        advvar6.Checked = True
        advvar7.Checked = True
    End Sub

    Private Sub advselectnone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles advselectnone.Click
        advvar1.Checked = False
        advvar2.Checked = False
        advvar3.Checked = False
        advvar4.Checked = False
        advvar5.Checked = False
        advvar6.Checked = False
        advvar7.Checked = False
    End Sub

    Private Sub actsub1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles actSub1.Click
        Dim intreply As Integer
        'sub1 activation
        Dim eng, gr, it As String

        eng = "Do you wish to activate the subcorpus " & vbNewLine & actSub1.Text & "?"
        gr = "Θέλετε να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub1.Text & "?"
        it = "Vuoi attivare il subcorpus " & vbNewLine & actSub1.Text & "?"
        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)
        Dim s() As String


        If intreply = vbYes Then



            s1data.Clear()
            s1activated = True
            Dim data As String = ""
            Dim inputfile As String = System.Environment.CurrentDirectory & "\sub1.txt"
            texttovar(inputfile, data)
            s = data.Split(vbTab)
            Dim row As DataRow

            For i = 0 To UBound(s) - 1
                row = dt.Rows(s(i))
                s1data.ImportRow(row)
            Next

            dtlbl.Text = 1
            eng = "SubCorpus : " & actSub1.Text & " , Activated "
            gr = "Το υπόσωμα : " & actSub1.Text & " , ενεργοποιήθηκε"
            it = "SubCorpus : " & actSub1.Text & " , attivato"
            translate(msg21, eng, gr, it)
            Corpus.Text = msg21

            ''''''''''''''''''''''''''''''''''''''''''''''''''

            actSub1.Checked = True
            actSub2.Checked = False
            actSub3.Checked = False
            actSub4.Checked = False

            oversub1.Checked = True

            cancelbtn.Visible = True

            ''''''''''''''''''''''''''''''''''''''''''''''''''
            Executemenu.Enabled = True
        End If


    End Sub

    Private Sub actSub2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles actSub2.Click
        Dim intreply As Integer
        'sub1 activation
        actSub2.Checked = True

        Dim eng, gr, it As String
        eng = "Do you wish to activate the subcorpus " & vbNewLine & actSub2.Text & "?"
        gr = "Θέλετε να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub2.Text & "?"
        it = "Vuoi attivare il subcorpus " & vbNewLine & actSub2.Text & "?"
        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)


        If intreply = vbYes Then
            s2data.Clear()
            s2activated = True
            Dim data As String = ""
            Dim inputfile As String = System.Environment.CurrentDirectory & "\sub2.txt"
            texttovar(inputfile, data)
            s = data.Split(vbTab)
            Dim row As DataRow

            For i = 0 To UBound(s) - 1
                row = dt.Rows(s(i))
                s2data.ImportRow(row)
            Next

            dtlbl.Text = 2
            eng = "SubCorpus : " & actSub2.Text & " , Activated "
            gr = "Το υπόσωμα : " & actSub2.Text & " , ενεργοποιήθηκε"
            it = "SubCorpus : " & actSub2.Text & " , attivato"
            translate(msg21, eng, gr, it)
            Corpus.Text = msg21


            ''''''''''''''''''''''''''''''''''''''''''''''''''

            actSub1.Checked = False
            actSub2.Checked = True
            actSub3.Checked = False
            actSub4.Checked = False


            oversub2.Checked = True

            cancelbtn.Visible = True

            ''''''''''''''''''''''''''''''''''''''''''''''''''
            Executemenu.Enabled = True
        End If

    End Sub

    Private Sub actSub3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles actSub3.Click
        Dim intreply As Integer
        'sub1 activation
        actSub3.Checked = True
        Dim eng, gr, it As String
        eng = "Do you want to activate the subcorpus " & vbNewLine & actSub3.Text & "?"
        gr = "Θέλετε να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub3.Text & "?"
        it = "Vuoi attivare il subcorpus " & vbNewLine & actSub3.Text & "?"
        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)

        If intreply = vbYes Then
            s3data.Clear()
            s3activated = True
            Dim data As String = ""
            Dim inputfile As String = System.Environment.CurrentDirectory & "\sub3.txt"
            texttovar(inputfile, data)
            s = data.Split(vbTab)
            Dim row As DataRow

            For i = 0 To UBound(s) - 1
                row = dt.Rows(s(i))
                s3data.ImportRow(row)
            Next

            dtlbl.Text = 3
            eng = "SubCorpus : " & actSub3.Text & " , Activated "
            gr = "Το υπόσωμα : " & actSub3.Text & " , ενεργοποιήθηκε"
            it = "SubCorpus : " & actSub3.Text & " , attivato"
            translate(msg21, eng, gr, it)
            Corpus.Text = msg21


            ''''''''''''''''''''''''''''''''''''''''''''''''''

            actSub1.Checked = False
            actSub2.Checked = False
            actSub3.Checked = True
            actSub4.Checked = False

            oversub3.Checked = True

            cancelbtn.Visible = True

            ''''''''''''''''''''''''''''''''''''''''''''''''''
            Executemenu.Enabled = True
        End If

    End Sub

    Private Sub actSub4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles actSub4.Click
        Dim intreply As Integer
        'sub1 activation
        actSub4.Checked = True
        Dim eng, gr, it As String
        eng = "Do you want to activate the subcorpus " & vbNewLine & actSub4.Text & "?"
        gr = "Θέλετε να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub4.Text & "?"
        it = "Vuoi attivare il subcorpus " & vbNewLine & actSub4.Text & "?"
        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)

        If intreply = vbYes Then
            s4data.Clear()
            s4activated = True
            Dim data As String = ""
            Dim inputfile As String = System.Environment.CurrentDirectory & "\sub4.txt"
            texttovar(inputfile, data)
            s = data.Split(vbTab)
            Dim row As DataRow

            For i = 0 To UBound(s) - 1
                row = dt.Rows(s(i))
                s4data.ImportRow(row)
            Next

            dtlbl.Text = 4
            eng = "SubCorpus : " & actSub4.Text & " , Activated "
            gr = "Το υπόσωμα : " & actSub4.Text & " , ενεργοποιήθηκε"
            it = "SubCorpus : " & actSub4.Text & " , attivato"
            translate(msg21, eng, gr, it)
            Corpus.Text = msg21

            ''''''''''''''''''''''''''''''''''''''''''''''''''

            actSub1.Checked = False
            actSub2.Checked = False
            actSub3.Checked = False
            actSub4.Checked = True

            oversub4.Checked = True

            cancelbtn.Visible = True

            ''''''''''''''''''''''''''''''''''''''''''''''''''
            Executemenu.Enabled = True
        End If

    End Sub

    Private Sub var1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var1.CheckedChanged

    End Sub

    Private Sub var2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var2.CheckedChanged


        If var2.Checked Then
        Else
            var3.Checked = False
        End If
    End Sub

    Private Sub var3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var3.CheckedChanged


        If var3.Checked Then
            var2.Checked = True
        End If
    End Sub

    Private Sub var6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var6.CheckedChanged

        If var6.Checked Then
        Else
            var7.Checked = False
        End If
    End Sub

    Private Sub var7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var7.CheckedChanged

        If var7.Checked Then
            var6.Checked = True
        End If
    End Sub

    Private Sub var8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var8.CheckedChanged

        If var8.Checked Then
            var9.Checked = True
            var10.Checked = True
        Else
            var9.Checked = False
            var10.Checked = False
        End If

    End Sub

    Private Sub var9_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var9.CheckedChanged

        If var9.Checked Then
            var8.Checked = True
            var10.Checked = True
        Else
            var8.Checked = False
            var10.Checked = False
        End If

    End Sub

    Private Sub var10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var10.CheckedChanged

        If var10.Checked Then
            var9.Checked = True
            var8.Checked = True
        Else
            var9.Checked = False
            var8.Checked = False
        End If

    End Sub

    Private Sub var11_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var11.CheckedChanged


    End Sub

    Private Sub var12_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var12.CheckedChanged


    End Sub

    Private Sub var14_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var14.CheckedChanged
        If var14.Checked And textn.Text = "" Then
            Paneln.Show()
        End If

    End Sub

    Private Sub var15_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var15.CheckedChanged
        listaleksewn = System.IO.Directory.GetCurrentDirectory & "\wordlist.txt"
        If var15.Checked And listaleksewn = "" Then
            Dim anoigmalistas As New OpenFileDialog
            anoigmalistas.Filter = "All Text files (*.txt)|*.txt"
            msg21 = ""
            translate(msg21, " Please select word list " & vbNewLine & "for frequency measurement", _
                      "Παρακαλώ επιλέξτε λίστα λέξεων" & " για μέτρηση συχνότητας", _
                       "Si prega di selezionare lista di parola" & vbNewLine & " per misurazione frequenza")

            anoigmalistas.Title = msg21
            If anoigmalistas.ShowDialog = Windows.Forms.DialogResult.OK Then
                listaleksewn = anoigmalistas.FileName
            Else
                var15.Checked = False
            End If
        End If

    End Sub

    Private Sub var16_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var16.CheckedChanged


    End Sub

    Private Sub var17_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles var17.CheckedChanged


    End Sub

    Public Sub proetoimasia_keimenou(ByRef rep2 As String)


        'ΚΑΘΑΡΙΣΜΟΣ ΚΕΙΜΕΝΟΥ

        'νέα γραμμή και tab
        rep2 = rep2.Replace(vbNewLine, " "c)
        rep2 = rep2.Replace(vbTab, " "c)


        ' κύριος, κυρία
        rep2 = rep2.Replace("κ.", " "c)
        rep2 = rep2.Replace("κα.", " "c)

        ' τα μικρά ονόματα με τελεία
        rep2 = rep2.Replace("Α.", " "c)
        rep2 = rep2.Replace("Β.", " "c)
        rep2 = rep2.Replace("Γ.", " "c)
        rep2 = rep2.Replace("Δ.", " "c)
        rep2 = rep2.Replace("Ε.", " "c)
        rep2 = rep2.Replace("Ζ.", " "c)
        rep2 = rep2.Replace("Η.", " "c)
        rep2 = rep2.Replace("Θ.", " "c)
        rep2 = rep2.Replace("Ι.", " "c)
        rep2 = rep2.Replace("Κ.", " "c)
        rep2 = rep2.Replace("Λ.", " "c)
        rep2 = rep2.Replace("Μ.", " "c)
        rep2 = rep2.Replace("Ν.", " "c)
        rep2 = rep2.Replace("Ξ.", " "c)
        rep2 = rep2.Replace("Ο.", " "c)
        rep2 = rep2.Replace("Π.", " "c)
        rep2 = rep2.Replace("Ρ.", " "c)
        rep2 = rep2.Replace("Σ.", " "c)
        rep2 = rep2.Replace("Τ.", " "c)
        rep2 = rep2.Replace("Υ.", " "c)
        rep2 = rep2.Replace("Φ.", " "c)
        rep2 = rep2.Replace("Χ.", " "c)
        rep2 = rep2.Replace("Ψ.", " "c)
        rep2 = rep2.Replace("Ω.", " "c)

        'αριθμοί
        rep2 = rep2.Replace("1", "")
        rep2 = rep2.Replace("2", "")
        rep2 = rep2.Replace("3", "")
        rep2 = rep2.Replace("4", "")
        rep2 = rep2.Replace("5", "")
        rep2 = rep2.Replace("6", "")
        rep2 = rep2.Replace("7", "")
        rep2 = rep2.Replace("8", "")
        rep2 = rep2.Replace("9", "")
        rep2 = rep2.Replace("0", "")

        'ειδικοί χαρακτήρες
        'rep2 = rep2.Replace("'"c, " "c)
        rep2 = rep2.Replace("("c, " "c)
        rep2 = rep2.Replace(")"c, " "c)
        rep2 = rep2.Replace("-"c, " "c)
        rep2 = rep2.Replace("%"c, " "c)
        rep2 = rep2.Replace(", ", " "c)
        rep2 = rep2.Replace(":", " "c)


        'kena
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("  ", " "c)

    End Sub

    Public Sub simeia_stiksis(ByRef rep2 As String)
        'σημεία στίξης
        rep2 = rep2.Replace(";"c, " "c)
        rep2 = rep2.Replace("!"c, " "c)
        rep2 = rep2.Replace("?", " "c)
        rep2 = rep2.Replace("...", " "c)
        rep2 = rep2.Replace("..", " "c)
        rep2 = rep2.Replace(". ", " "c)
        rep2 = rep2.Replace(" .", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("   ", " "c)
        rep2 = rep2.Replace("  ", " "c)
    End Sub

    Public Function words(ByRef datas As String)

        Dim rep() As Char = {" "c}
        s = datas.Split(rep)

        ' set column size for the s array
        Dim wds As Int32 = UBound(s)
        Dim test As String = ""

        Do Until test <> ""
            test = s(wds)
            test = test.Replace("   ", "")
            test = test.Replace("   ", "")
            test = test.Replace("   ", "")
            test = test.Replace("  ", "")
            test = test.Replace(" ", "")
            If test = "" Then
                wds -= 1
            End If
        Loop

        Dim minus As Int32 = 0
        'Dim excludelist() As String = {"ο", "Ο", "Η", "η", "ή"}
        'Dim item_in_list As Boolean
        datas = ""
        For i = 0 To wds
            'item_in_list = excludelist.Contains(s(i))
            If s(i).Length < 1 Then
                If i <> 0 Then
                    datas &= s(i) & vbNewLine
                Else
                    minus += 1
                End If
            Else
                datas &= s(i) & vbNewLine
            End If


        Next
        words = wds + 1 - minus




    End Function


    Public Function awl(ByVal datas As String) As Single
        Dim s() As String
        s = datas.Split(vbNewLine)

        Dim l As Int32
        Dim m As Single = s(0).Length
        Dim words As Int32 = UBound(s)
        For i = 1 To words - 1

            l = s(i).Length

            m += l - 1
        Next
        awl = m / words

        percentage.Text = Math.Round(ProgressBar.Value / mx * 100) & "%"
        job.Text = processingfile
        ProgressBar.Value += 1


    End Function

    Public Function wl_csd(ByVal datas As String, ByVal m As Single) As Single
        Dim wordlist() As String
        wordlist = datas.Split(vbNewLine)

        Dim wlc As Single
        Dim max As Int32
        Dim x_m As Single
        x_m = 0
        max = UBound(wordlist) - 1
        For i = 0 To max
            wlc = wordlist(i).Length - 1
            x_m += (wlc - m) ^ 2
        Next


        wl_csd = Math.Sqrt(x_m) / m

    End Function

    Public Function Sentence_Length(ByRef datas As String) As Single
        Dim chararray() As Char = {".", ";", "!", "?"}
        Dim rep2 As String
        rep2 = datas
        rep2 = rep2.Replace("...", "."c)
        rep2 = rep2.Replace("..", "."c)
        s = rep2.Split(chararray)
        Dim max As Int32 = UBound(s)
        Dim sum As Int32 = 0
        Dim counter As Int32 = 1
        Dim minus As Int32 = 0

        Dim w() As String
        Dim l As Int32
        w = s(0).Split(" "c)

        sum += UBound(w) + 1
        Dim test As String
        Dim sentences As Int32 = 1
        '----------erase------------------
        Dim output As String = "1.  " & s(0) & "  " & sum & vbNewLine
        '---------------------------------
        datas = s(0) & vbNewLine

        For i = 1 To max
            w = s(i).Split(" "c)
            l = UBound(w)
            test = ""

            Do Until test <> "" Or l = -1
                test = w(l)
                If test = "" Then
                    l -= 1
                End If
            Loop

            If l > -1 Then
                sum += l
                sentences += 1
                '---------erase--------------------------------------
                output &= sentences & ".  " & s(i) & "  " & l & vbNewLine
                '----------------------------------------------------
                datas &= s(i) & vbNewLine

            End If

        Next
        max = sentences
        Sentence_Length = lekseis / max


        '---erase---------------------------
        output &= vbNewLine & "sum = " & sum & vbNewLine
        stext.Text &= output & " Λέξεις : " & lekseis & "  Προτάσεις : " & max

        sl.Text = Sentence_Length
        sent.Text = max
        '-----------------------------------

    End Function

    Public Function slsd(ByVal datas As String) As Single

        s = datas.Split(vbNewLine)


        Dim max As Int32 = UBound(s)
        Dim sum As Int32 = 0
        Dim counter As Int32 = 1
        Dim minus As Int32 = 0

        Dim w() As String
        Dim l As Int32
        w = s(0).Split(" "c)
        l = UBound(w) + 1
        Dim test As String
        Dim sentences As Int32 = 1



        datas = s(0) & vbNewLine
        sum = (l - sln) ^ 2

        For i = 1 To max - 1
            w = s(i).Split(" "c)
            l = UBound(w)
            test = ""

            Do Until test <> "" Or l = -1
                test = w(l)
                If test = "" Then
                    l -= 1
                End If
            Loop

            If l > -1 Then
                sum += (l - sln) ^ 2
                sentences += 1

                datas &= s(i) & vbNewLine

            End If

        Next
        max = sentences

        slsd = Math.Sqrt(sum / max)


    End Function

    Public Sub apaxdis(ByVal datas As String, ByRef ap As Int32, ByRef di As Int32)

        s = datas.Split(vbNewLine)
        Dim temp As String
        Dim apaxlist As New ArrayList
        Dim dislist As New ArrayList
        Dim multilist As New ArrayList
        Dim checklist As New ArrayList(s)
        apaxlist.Add("")
        dislist.Add("")
        multilist.Add("")


        For i = 1 To lekseis - 1
            temp = checklist.Item(i)
            If Not multilist.Contains(temp) Then
                If Not dislist.Contains(temp) Then
                    If Not apaxlist.Contains(temp) Then
                        apaxlist.Add(temp)
                    Else
                        apaxlist.Remove(temp)
                        dislist.Add(temp)
                    End If
                Else
                    dislist.Remove(temp)
                    multilist.Add(temp)
                End If
            End If
        Next
        Dim trimmed As String
        temp = s(0)
        Dim upper As Int32
        trimmed = datas.TrimStart(temp)
        Dim splitted() As String
        Dim add1 As Int32 = 0
        Dim add2 As Int32 = 0

        If Not trimmed.Contains(temp) Then
            apaxlist.Add(temp)
        Else
            splitted = trimmed.Split(temp)
            upper = UBound(splitted)

            If upper = 1 Then

                'MsgBox(" need to remove from apaxlist")
                add1 = -1

                dislist.Add(temp)
            ElseIf upper = 2 Then
                'MsgBox("need to remove from dislist")

                add2 = -1
            End If
        End If

        ap = apaxlist.Count - 1 + add1
        di = dislist.Count - 1 + add2






    End Sub

    Public Function periexei(ByVal mialista As ArrayList, ByVal price As String) As Boolean
        Dim exei As Boolean
        exei = False
        For i = 0 To mialista.Count - 1
            If mialista.Item(0) = price Then
                exei = True
            End If
        Next
        periexei = exei
    End Function

    Public Function LD(ByVal datas As String) As Single
        Dim f() As String
        Dim fdata As String = ""
        Dim filename As String = System.Environment.CurrentDirectory & "\fw.txt"
        texttovar(filename, fdata)
        fdata.Replace("   ", "")
        fdata.Replace("   ", "")
        fdata.Replace("   ", "")
        fdata.Replace("  ", "")
        fdata.Replace(" "c, "")

        f = fdata.Split(vbNewLine)
        Dim fw As New ArrayList(f)
        s = datas.Split(vbNewLine)
        Dim checkword As String
        Dim countl As Int32 = 0
        Dim output As String = "periexomenou : "
        For i = 0 To lekseis - 1
            checkword = s(i)
            If fw.Contains(checkword) Then
                countl += 1
            Else
                output &= checkword & " "
            End If
        Next
        Dim leitourgikes = countl
        Dim periexomenou = lekseis - countl

        LD = leitourgikes / periexomenou




    End Function

    Public Sub lw_c1(ByVal datas As String, ByRef lw As ArrayList)
        Dim temp As String
        Dim l As Int32
        s = datas.Split(vbNewLine)

        '---- arxikopoiisi timwn

        For i = 1 To 20
            lw.Item(i) = 0
        Next


        ' dimiourgw ti lista

        For i = 0 To lekseis - 1
            temp = s(i)
            If i = 0 Then
                l = temp.Length
            Else
                l = temp.Length - 1
            End If

            Select Case l
                Case 1
                    lw.Item(1) += 1
                Case 2
                    lw.Item(2) += 1
                Case 3
                    lw.Item(3) += 1
                Case 4
                    lw.Item(4) += 1
                Case 5
                    lw.Item(5) += 1
                Case 6
                    lw.Item(6) += 1
                Case 7
                    lw.Item(7) += 1
                Case 8
                    lw.Item(8) += 1
                Case 9
                    lw.Item(9) += 1
                Case 10
                    lw.Item(10) += 1
                Case 11
                    lw.Item(11) += 1
                Case 12
                    lw.Item(12) += 1
                Case 13
                    lw.Item(13) += 1
                Case 14
                    lw.Item(14) += 1
                Case 15
                    lw.Item(15) += 1
                Case 16
                    lw.Item(16) += 1
                Case 17
                    lw.Item(17) += 1
                Case 18
                    lw.Item(18) += 1
                Case 19
                    lw.Item(19) += 1
                Case 20
                    lw.Item(20) += 1
            End Select
        Next
        Dim oeo As Int32 = 0
        For i = 1 To 20
            oeo = lw.Item(i)
            lw.Item(i) = (oeo / lekseis) * 100
        Next

    End Sub

    Public Sub uw1(ByVal datas As String, ByRef uw As ArrayList)
        Dim ll As String = ""
        texttovar(listaleksewn, ll)
        proetoimasia_keimenou(ll)
        simeia_stiksis(ll)
        s = ll.Split(" "c)

        For i = 0 To UBound(s) - 1
            uw.Add(0)

        Next
        Dim pin() As String
        Dim freqcount As Int32
        Dim leksoula As String
        For i = 0 To UBound(s) - 1
            leksoula = s(i)
            pin = datas.Split(leksoula)
            freqcount = UBound(pin) - 1
            uw.Item(0) = freqcount
        Next


    End Sub

    Public Sub uw1(ByVal listaleksewn As String, ByVal datas As String, ByRef uw As ArrayList, ByRef a() As String)
        Dim ll As String = ""
        Dim w() As String


        texttovar(listaleksewn, ll)
        ll.Replace(" "c, "")

        s = datas.Split(vbNewLine)
        w = ll.Split(vbNewLine)
        For i = 0 To UBound(w)
            a(i) = w(i)
        Next

        uw.Clear()
        a(w.Length) = a(0)

        For i = 0 To w.Length

            uw.Add(0)

        Next


        Dim j As Int32


        For i = 0 To lekseis - 1

            For j = 1 To w.Length
                If s(i).Contains(a(j)) Then
                    uw.Item(j) += 1
                End If
            Next


            'If w.Contains(s(i)) Then
            '    j = Array.IndexOf(w, s(i))
            '    uw.Item(j) += 1
            'End If

        Next



        ''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''
        For i = 1 To w.Length

            uw.Item(i) = (uw.Item(i) / lekseis) * 100


        Next
        ''''''''''''''''''''''''''''''''''''''''''''
        ''''''''''''''''''''''''''''''''''''''''''''


        ' '''''''''''''''''''''''''''''''''''''''''''''
        ' '''''''''''''''''''''''''''''''''''''''''''''

        'Dim output As String = ""

        'For i = 1 To w.Length
        '    output &= a(i) & " :   " & uw.Item(i) & vbNewLine
        'Next

        'wordfr.Text = output

        ' '''''''''''''''''''''''''''''''''''''''''''''
        ' '''''''''''''''''''''''''''''''''''''''''''''



    End Sub

    Private Function TTR(ByVal datas As String)
        Dim s() As String
        Dim typearray(5000) As String
        s = datas.Split(vbNewLine)
        Dim ind As Int32
        Dim w(5000) As Int32
        Dim tokens As Int32 = UBound(s)

        'Dim tokenlist As New ArrayList
        'Dim vrethike As Boolean
        types = 1
        Dim test As String

        typearray(0) = s(0)

        w(0) = 1

        For i = 1 To UBound(s) - 1

            test = s(i)

            If Not typearray.Contains(s(i)) Then 'an den periexei ti leksi, tin prosthetoume
                types += 1
                typearray(types) = s(i)
                w(types) = 1
            Else
                ind = Array.IndexOf(typearray, s(i))  'vriskoume se pio index einai i leksi sto typesarray

                w(ind) += 1        ''''''  metraw mia akoma leksi sto sigekrimeno index
            End If

        Next

        If tokens = 1 Then
            types = 1
        Else
            types -= 1
        End If
        TTR = types / tokens
    End Function

    Public Sub TTR2(ByVal datas As String, ByRef typesarray() As String, ByRef w() As Int32, ByRef types As Int32)
        Dim s() As String

        s = datas.Split(vbNewLine)
        Dim ind As Int32

        Dim tokens As Int32 = UBound(s)

        'Dim tokenlist As New ArrayList
        'Dim vrethike As Boolean

        Dim test As String

        For i = 0 To UBound(s) - 1

            test = s(i)

            If Not typesarray.Contains(s(i)) Then 'an den periexei ti leksi, tin prosthetoume
                types += 1
                typesarray(types) = s(i)
                w(types) = 1
            Else
                ind = Array.IndexOf(typesarray, s(i))  'vriskoume se pio index einai i leksi sto typesarray

                w(ind) += 1        ''''''  metraw mia akoma leksi sto sigekrimeno index
            End If

        Next

        If tokens = 1 Then
            types = 1
        Else
            types -= 1
        End If

    End Sub

    Private Sub w_sort(ByVal n As Int32, ByVal typesarray() As String, ByVal w() As Int32, ByRef sortedtype() As String, ByRef sortedfreq() As Int32, ByVal typecount As Int32)
        Dim max As Int32
        Dim fr() As Int32
        Dim ind As Int32
        Dim output As String = ""

        fr = w

        For i = 0 To n - 1
            max = fr(0)
            For j = 1 To typecount
                If max < fr(j) Then
                    max = fr(j)
                    ind = j


                    'form6.Worktext.Text = "processing : " & max

                End If
            Next
            sortedfreq(i) = max
            sortedtype(i) = typesarray(ind)
            fr(ind) = 0



        Next





    End Sub


    Private Sub euresisixnotitwn(ByVal typesarray() As String, ByVal w() As Int32, ByVal sortedtypearray() As String, ByVal n As Int32, ByRef sixnotites() As Double)
        Dim ind As Int32 = 0
        Dim output As String = ""
        Dim temp As String
        Dim fr() As Int32
        Dim textfreq(5000) As Int32
        fr = w

        For i = 0 To n - 1
            temp = sortedtypearray(i)

            ind = Array.IndexOf(typesarray, temp)


            If ind = -1 Then  'den vrethike
                textfreq(i) = 0
            Else
                textfreq(i) = fr(ind)
            End If


        Next

        For i = 0 To n - 1
            sixnotites(i) = (textfreq(i) / lekseis) * 100

        Next



    End Sub

    Private Sub Executemenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Executemenu.Click

        varpanel.Visible = False

        Select Case dtlbl.Text
            Case 0
                result = dt
            Case 1
                result = s1data
            Case 2
                result = s2data
            Case 3
                result = s3data
            Case 4
                result = s4data



        End Select



        Dim n2 As Integer

        Dim firstrun(17) As Boolean
        Dim varlist(17) As Boolean
        Dim i As Int32 = 0
        Dim columnname As String



        Dim wordnumber As Int32 = 0
        Dim drow As DataRow
        Dim filename As String
        Dim filecol As Int32




        '''''''''arxikopoiisi''' 
        For i = 1 To 17
            firstrun(i) = True
        Next

        For i = 1 To 21
            lw_c.Add(0)
        Next

        ''''''''''''''''''''''''

        drow = result.Rows(0)





        'Form6.workbar.Tag = "Processing.."
        'Form6.workbar.Value = 0
        'Form6.workbar.Hide()

        mx = result.Rows.Count
        'Form6.workbar.Maximum = mx
        ProgressBar.Maximum = mx
        ProgressBar.Value = 0

        percentage.Text = "0%"

        job.Text = "processing.."
        ProgressBar.Show()

        For Each drow In result.Rows

            filecol = statusindex.Text - 1
            i += 1
            filename = drow(filecol)
            texttovar(check(filename), keimeno)

            proetoimasia_keimenou(keimeno)


            processingfile = filename

            'Form6.Worktext.Text = "processing : " & drow(filecol)
            'Form6.workbar.Value += 1
            'Form6.perc.Text = Math.Round(ProgressBar.Value / max * 100) & "%"

            'ksexwrizoume to keimeno gia sentence length
            s_keimeno = keimeno

            'efarmozoume tin apokopi simeiwn stiksis tou keimenou gia tis lekseis
            simeia_stiksis(keimeno)

            ' kataxwrisi apotelesmatwn
            'sinolo leksewn ----------------- --------> lekseis
            'Mesos oros leksewn se xaraktires --------->  m
            'meso mikos protasis se lekseis ----------> sln
            Dim ttr1, wl_csd1, slsd1, ld1 As Single

            lekseis = words(keimeno)

            ttr1 = TTR(keimeno)
            TTR2(keimeno, sinolotypearray, sinolofreq, sinolotypwn)
            m = awl(keimeno)

            wl_csd1 = wl_csd(keimeno, m)

            ''''''''''''''''''''''''''''''''''''''''''''''''''''''
            stext.Text = s_keimeno
            '''''''''''''''''''''''''''''''''''''''''''''''''''

            leks.Text = lekseis

            sln = Sentence_Length(s_keimeno)

            slsd1 = slsd(s_keimeno)

            'apax dis legomena
            apaxdis(keimeno, apax, dis)
            'apaxlbl.Text &= apax
            'dislbl.Text &= dis
            'apax_dis.Text &= dis / apax

            lw_c1(keimeno, lw_c)
            ld1 = LD(keimeno)


            If var1.Checked Then

                If firstrun(1) Then
                    Try
                        result.Columns.Add("TTR", System.Type.GetType("System.String"))
                    Catch ex As Exception
                    End Try
                End If
                drow("TTR") = ttr1
                firstrun(1) = False
            End If

            If var2.Checked Then

                If firstrun(2) Then
                    Try
                        result.Columns.Add("AWL_C", System.Type.GetType("System.String"))
                    Catch ex As Exception
                    End Try
                End If

                drow("AWL_C") = m
                firstrun(2) = False
            End If

            If var3.Checked Then

                If firstrun(3) Then
                    Try
                        result.Columns.Add("WL_Csd", System.Type.GetType("System.String"))
                    Catch ex As Exception

                    End Try

                End If
                drow("WL_Csd") = wl_csd1

                firstrun(3) = False
            End If

            If var4.Checked Then

                If firstrun(4) Then
                    Try
                        result.Columns.Add("AWL_S", System.Type.GetType("System.String"))
                    Catch ex As Exception

                    End Try

                End If

                firstrun(4) = False

            End If
            If var5.Checked Then

                If firstrun(5) Then
                    Try
                        result.Columns.Add("WL_Ssd", System.Type.GetType("System.String"))
                    Catch ex As Exception

                    End Try
                End If
                firstrun(5) = False
            End If

            If var6.Checked Then

                If firstrun(6) Then
                    Try
                        result.Columns.Add("SL", System.Type.GetType("System.String"))

                    Catch ex As Exception

                    End Try
                End If

                drow("SL") = sln
                firstrun(6) = False
            End If

            If var7.Checked Then

                If firstrun(7) Then
                    Try
                        result.Columns.Add("SL_sd", System.Type.GetType("System.String"))

                    Catch ex As Exception

                    End Try
                End If
                drow("SL_sd") = slsd1
                firstrun(7) = False
            End If

            If var8.Checked Then

                If firstrun(8) Then
                    Try
                        result.Columns.Add("Perc_Hapl", System.Type.GetType("System.String"))

                    Catch ex As Exception

                    End Try
                End If

                drow("Perc_Hapl") = apax
                firstrun(8) = False
            End If

            If var9.Checked Then

                If firstrun(9) Then
                    Try
                        result.Columns.Add("Perc_Displ", System.Type.GetType("System.String"))

                    Catch ex As Exception

                    End Try
                End If


                drow("Perc_Displ") = dis
                firstrun(9) = False
            End If

            If var10.Checked Then

                If firstrun(10) Then
                    Try
                        result.Columns.Add("Dis_Hapl", System.Type.GetType("System.String"))

                    Catch ex As Exception

                    End Try
                End If

                drow("Dis_Hapl") = dis / apax
                firstrun(10) = False
            End If

            If var11.Checked Then

                If firstrun(11) Then
                    Try
                        result.Columns.Add("LD", System.Type.GetType("System.String"))

                    Catch ex As Exception

                    End Try
                End If
                drow("LD") = ld1
                firstrun(11) = False
            End If

            If var12.Checked Then


                For j = 1 To 20
                    columnname = "lw_c" & j
                    If firstrun(12) Then
                        Try
                            result.Columns.Add(columnname, System.Type.GetType("System.String"))

                        Catch ex As Exception

                        End Try
                    End If
                    drow(columnname) = lw_c(j)
                Next

                firstrun(12) = False
            End If

            If var13.Checked Then

                If firstrun(13) Then
                    Try

                    Catch ex As Exception

                    End Try
                End If
                firstrun(13) = False
            End If

            If var14.Checked Then

                For j = 0 To n2 - 1

                    columnname = "w" & j & vbNewLine & sortedtype(j)
                    If firstrun(14) Then

                        result.Columns.Add(columnname, System.Type.GetType("System.String"))
                    End If


                Next
                firstrun(14) = False
            End If

            If var15.Checked Then

                uw1(listaleksewn, keimeno, uw, a)
                For j = 1 To uw.Count - 1
                    columnname = a(j)
                    If firstrun(15) Then
                        Try
                            result.Columns.Add(columnname, System.Type.GetType("System.String"))
                        Catch ex As Exception

                        End Try

                    End If
                    drow(columnname) = uw(j)
                Next

                firstrun(15) = False

            End If

            If var16.Checked Then

                If firstrun(16) Then
                    Try

                    Catch ex As Exception

                    End Try

                End If
                firstrun(16) = False
            End If

            If var17.Checked Then

                If firstrun(17) Then
                    Try

                    Catch ex As Exception

                    End Try
                End If
                firstrun(17) = False
            End If



        Next
        ProgressBar.Hide()
        job.Text = ""
        percentage.Text = ""
        Executemenu.Enabled = False

        'Dim defaultwidth As Int32
        Form4.DataGridView1.DataSource = result

        For i = 0 To Form4.DataGridView1.Columns.Count - 1
            Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            '    'defaultwidth = Form4.DataGridView1.Columns(i).Width
            '    'Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.NotSet
            '    'Form4.DataGridView1.Columns(i).Width = defaultwidth

        Next



        Me.Enabled = False
        Form4.Show()

    End Sub

    Private Sub delsub1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delsub1.Click


        Dim intreply As Integer


        Dim eng, gr, it As String

        eng = "Do you wish to erase the subcorpus " & actSub1.Text & "?"
        gr = "Θέλετε να σβήσετε το υπόσωμα " & actSub1.Text & "?"
        it = "Vuoi cancellare il subcorpus " & actSub1.Text & "?"

        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)

        If intreply = vbYes Then

            ''''''''''''''''''''''''''''
            s1activated = False

            delsub1.Text = "Sub1"
            oversub1.Text = "sub1"
            actSub1.Text = "Sub1"

            '''''''''''''''''''''''''''''''
            delsub1.Visible = False
            oversub1.Visible = False
            actSub1.Visible = False
            oversub1.Checked = False
            'remove 1 from subnumber

            Dim sn As Int32 = sbcount.Text
            sn -= 1
            sbcount.Text = sn

            If dtlbl.Text = 1 Then
                eng = "Main corpus selected"
                gr = "Κυριώς σώμα επιλεγμένο"
                it = "Corpus principale selezionato"
                translate(msg21, eng, gr, it)
                Corpus.Text = msg21
                dtlbl.Text = 0
                cancelbtn.Visible = False
                Executemenu.Enabled = True
            End If



            ' make spot free

            free1.Text = 0


        End If


    End Sub

    Private Sub delsub2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delsub2.Click
        Dim intreply As Integer

        Dim eng, gr, it As String

        eng = "Do you wish to erase the subcorpus " & actSub2.Text & "?"
        gr = "Θέλετε να σβήσετε το υπόσωμα " & actSub2.Text & "?"
        it = "Vuoi cancellare il subcorpus " & actSub2.Text & "?"

        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)


        If intreply = vbYes Then
            s2activated = False
            delsub2.Text = "Sub2"
            oversub2.Text = "sub2"
            actSub2.Text = "Sub2"
            delsub2.Visible = False
            oversub2.Visible = False
            actSub2.Visible = False
            oversub2.Checked = False
            ''''''''''''''''''''''''''''''
            Dim sn As Int32 = sbcount.Text
            sn -= 1
            sbcount.Text = sn


            If dtlbl.Text = 2 Then
                eng = "Main corpus selected"
                gr = "Κυριώς σώμα επιλεγμένο"
                it = "Corpus principale selezionato"
                translate(msg21, eng, gr, it)
                Corpus.Text = msg21
                dtlbl.Text = 0
                cancelbtn.Visible = False
                Executemenu.Enabled = True
            End If


            ' make spot free

            free2.Text = 0


        End If
    End Sub

    Private Sub delsub3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delsub3.Click
        Dim intreply As Integer

        Dim eng, gr, it As String

        eng = "Do you wish to erase the subcorpus " & actSub3.Text & "?"
        gr = "Θέλετε να σβήσετε το υπόσωμα " & actSub3.Text & "?"
        it = "Vuoi cancellare il subcorpus " & actSub3.Text & "?"

        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)

        If intreply = vbYes Then
            s3activated = False
            delsub3.Text = "Sub3"
            oversub3.Text = "sub3"
            actSub3.Text = "Sub3"
            delsub3.Visible = False
            oversub3.Visible = False
            actSub3.Visible = False
            oversub3.Checked = False
            ''''''''''''''''''''''''''''''


            Dim sn As Int32 = sbcount.Text
            sn -= 1
            sbcount.Text = sn

            If dtlbl.Text = 3 Then
                eng = "Main corpus selected"
                gr = "Κυριώς σώμα επιλεγμένο"
                it = "Corpus principale selezionato"
                translate(msg21, eng, gr, it)
                Corpus.Text = msg21
                dtlbl.Text = 0
                cancelbtn.Visible = False
                Executemenu.Enabled = True
            End If



            ' make spot free

            free3.Text = 0




        End If
    End Sub

    Private Sub delsub4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delsub4.Click
        Dim intreply As Integer

        Dim eng, gr, it As String

        eng = "Do you wish to erase the subcorpus " & actSub4.Text & "?"
        gr = "Θέλετε να σβήσετε το υπόσωμα " & actSub4.Text & "?"
        it = "Vuoi cancellare il subcorpus " & actSub4.Text & "?"

        translate(msg21, eng, gr, it)
        intreply = MsgBox(msg21, vbYesNo + MsgBoxStyle.Information, oeo)

        If intreply = vbYes Then
            s4activated = False
            delsub4.Text = "Sub4"
            oversub4.Text = "sub4"
            actSub4.Text = "Sub4"
            delsub4.Visible = False
            oversub4.Visible = False
            actSub4.Visible = False
            oversub4.Checked = False

            ''''''''''''''''''''''''''''''


            Dim sn As Int32 = sbcount.Text
            sn -= 1
            sbcount.Text = sn

            If dtlbl.Text = 4 Then
                eng = "Main corpus selected"
                gr = "Κυριώς σώμα επιλεγμένο"
                it = "Corpus principale selezionato"
                translate(msg21, eng, gr, it)
                Corpus.Text = msg21
                dtlbl.Text = 0
                cancelbtn.Visible = False
                Executemenu.Enabled = True
            End If


            ' make spot free

            free4.Text = 0


        End If
    End Sub

    Private Sub oversub1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles oversub1.Click
        Dim eng, gr, it As String
        Dim output As String = ""
        eng = "Sub-Corpus Overview : " & actSub1.Text
        gr = "Επισκοπηση ΥποΣώματος : " & actSub1.Text
        it = "SubCorpus Panoramica : " & actSub1.Text
        translate(output, eng, gr, it)
        Form4.Text = output

        eng = "Close"
        gr = "Κλείσιμο"
        it = "chiudere"
        translate(output, eng, gr, it)
        Form4.closebtn.Text = output

        eng = "Save to Excel"
        gr = "Αποθήκευση σε Excel"
        it = "Salvare in formato excel"
        translate(output, eng, gr, it)
        Form4.excelbtn.Text = output


        If s1activated Then
            Form4.DataGridView1.DataSource = s1data
            Dim i As Int32
            For i = 0 To Form4.DataGridView1.Columns.Count - 1
                Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                'defaultwidth = Form4.DataGridView1.Columns(i).Width
                'Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.NotSet
                'Form4.DataGridView1.Columns(i).Width = defaultwidth

            Next
            tosave.Text = 1
            Me.Enabled = False

            Form4.Show()
        Else


            eng = "You need to activate subcorpus " & vbNewLine & actSub1.Text & vbNewLine & " at least once " & vbNewLine & " in order to overview"
            gr = "Χρειάζεται να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub1.Text & vbNewLine & " τουλάχιστον μιά φορά " & vbNewLine & " για να κάνετε επισκόπηση"
            it = "È necessario attivare subcorpus" & vbNewLine & actSub1.Text & vbNewLine & " almeno una volta " & vbNewLine & " ordine alla panoramica"

            translate(msg21, eng, gr, it)
            MsgBox(msg21)
        End If


    End Sub

    Private Sub oversub2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles oversub2.Click
        Dim eng, gr, it As String
        Dim output As String = ""


        eng = "Sub-Corpus Overview : " & actSub2.Text
        gr = "Επισκοπηση ΥποΣώματος : " & actSub2.Text
        it = "SubCorpus Panoramica : " & actSub2.Text
        translate(output, eng, gr, it)
        Form4.Text = output

        eng = "Close"
        gr = "Κλείσιμο"
        it = "chiudere"
        translate(output, eng, gr, it)
        Form4.closebtn.Text = output

        eng = "Save to Excel"
        gr = "Αποθήκευση σε Excel"
        it = "Salvare in formato excel"
        translate(output, eng, gr, it)
        Form4.excelbtn.Text = output


        If s2activated Then
            Form4.DataGridView1.DataSource = s2data
            Dim i As Int32
            For i = 0 To Form4.DataGridView1.Columns.Count - 1
                Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                'defaultwidth = Form4.DataGridView1.Columns(i).Width
                'Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.NotSet
                'Form4.DataGridView1.Columns(i).Width = defaultwidth

            Next
            tosave.Text = 2
            Me.Enabled = False
            Form4.Show()
        Else


            eng = "You need to activate subcorpus " & vbNewLine & actSub2.Text & vbNewLine & " at least once " & vbNewLine & " in order to overview"
            gr = "Χρειάζεται να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub2.Text & vbNewLine & " τουλάχιστον μιά φορά " & vbNewLine & " για να κάνετε επισκόπηση"
            it = "È necessario attivare subcorpus" & vbNewLine & actSub2.Text & vbNewLine & " almeno una volta " & vbNewLine & " ordine alla panoramica"

            translate(msg21, eng, gr, it)
            MsgBox(msg21)
        End If

    End Sub

    Private Sub oversub3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles oversub3.Click

        Dim eng, gr, it As String
        Dim output As String = ""


        eng = "Sub-Corpus Overview : " & actSub3.Text
        gr = "Επισκοπηση ΥποΣώματος : " & actSub3.Text
        it = "SubCorpus Panoramica : " & actSub3.Text
        translate(output, eng, gr, it)
        Form4.Text = output

        eng = "Close"
        gr = "Κλείσιμο"
        it = "chiudere"
        translate(output, eng, gr, it)
        Form4.closebtn.Text = output

        eng = "Save to Excel"
        gr = "Αποθήκευση σε Excel"
        it = "Salvare in formato excel"
        translate(output, eng, gr, it)
        Form4.excelbtn.Text = output


        If s3activated Then
            Form4.DataGridView1.DataSource = s3data
            Dim i As Int32
            For i = 0 To Form4.DataGridView1.Columns.Count - 1
                Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                'defaultwidth = Form4.DataGridView1.Columns(i).Width
                'Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.NotSet
                'Form4.DataGridView1.Columns(i).Width = defaultwidth

            Next
            tosave.Text = 3
            Me.Enabled = False
            Form4.Show()
        Else


            eng = "You need to activate subcorpus " & vbNewLine & actSub3.Text & vbNewLine & " at least once " & vbNewLine & " in order to overview"
            gr = "Χρειάζεται να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub3.Text & vbNewLine & " τουλάχιστον μιά φορά " & vbNewLine & " για να κάνετε επισκόπηση"
            it = "È necessario attivare subcorpus " & vbNewLine & actSub3.Text & vbNewLine & " almeno una volta " & vbNewLine & " ordine alla panoramica"

            translate(msg21, eng, gr, it)
            MsgBox(msg21)
        End If

    End Sub

    Private Sub oversub4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles oversub4.Click

        Dim eng, gr, it As String
        Dim output As String = ""


        eng = "Sub-Corpus Overview : " & actSub4.Text
        gr = "Επισκοπηση ΥποΣώματος : " & actSub4.Text
        it = "SubCorpus Panoramica : " & actSub4.Text
        translate(output, eng, gr, it)
        Form4.Text = output

        eng = "Close"
        gr = "Κλείσιμο"
        it = "chiudere"
        translate(output, eng, gr, it)
        Form4.closebtn.Text = output

        eng = "Save to Excel"
        gr = "Αποθήκευση σε Excel"
        it = "Salvare in formato excel"
        translate(output, eng, gr, it)
        Form4.excelbtn.Text = output
        If s4activated Then
            Form4.DataGridView1.DataSource = s4data
            Dim i As Int32
            For i = 0 To Form4.DataGridView1.Columns.Count - 1
                Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                'defaultwidth = Form4.DataGridView1.Columns(i).Width
                'Form4.DataGridView1.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.NotSet
                'Form4.DataGridView1.Columns(i).Width = defaultwidth

            Next
            tosave.Text = 4
            Me.Enabled = False
            Form4.Show()
        Else


            eng = "You need to activate subcorpus " & vbNewLine & actSub4.Text & vbNewLine & " at least once " & vbNewLine & " in order to overview"
            gr = "Χρειάζεται να ενεργοποιήσετε το υπόσωμα " & vbNewLine & actSub4.Text & vbNewLine & " τουλάχιστον μιά φορά " & vbNewLine & " για να κάνετε επισκόπηση"
            it = "È necessario attivare subcorpus " & vbNewLine & actSub4.Text & vbNewLine & " almeno una volta " & vbNewLine & " ordine alla panoramica"

            translate(msg21, eng, gr, it)
            MsgBox(msg21)
        End If
    End Sub


    Private Sub cancelbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cancelbtn.Click
        Dim intreply As Integer

        Dim eng, gr, it As String

        eng = "Are you sure you want to switch back to main corpus?"
        gr = "Θέλετε σίγουρα να επιστρέψετε στο κυρίως σώμα?"
        it = "Sei sicuro di voler tornare alla principale corpus?"

        translate(msg22, eng, gr, it)

        intreply = MsgBox(msg22, vbYesNo + MsgBoxStyle.Information, oeo)


        If intreply = vbYes Then
            result = dt
            eng = "Main corpus selected"
            gr = "Κυριώς σώμα επιλεγμένο"
            it = "Corpus principale selezionato"
            translate(msg21, eng, gr, it)
            Corpus.Text = msg21
            dtlbl.Text = 0
            cancelbtn.Visible = False
            Executemenu.Enabled = True
        End If
    End Sub

    Private Sub uwbtn_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles uwbtn.Click
        Dim anoigmalistas As New OpenFileDialog
        anoigmalistas.Filter = "All Text files (*.txt)|*.txt"
        msg21 = ""

        translate(msg21, " Please select word list " & vbNewLine & "for frequency measurement", _
                       "Παρακαλώ επιλέξτε λίστα λέξεων" & " για μέτρηση συχνότητας", _
                        "Si prega di selezionare lista di parola" & vbNewLine & " per misurazione frequenza")

        anoigmalistas.Title = msg21

        If anoigmalistas.ShowDialog = Windows.Forms.DialogResult.OK Then
            listaleksewn = anoigmalistas.FileName
        End If
    End Sub



    Private Sub w1btn_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles w1btn.Click
        Paneln.Show()

    End Sub

    Private Sub oknbtn_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles okbtnn.Click
        Try
            If textn.Text > 0 Then
                Paneln.Hide()

            End If
        Catch ex As Exception
            If Not ex.ToString = "" Then
                var14.Checked = False
                textn.Text = ""
            End If
        End Try

    End Sub

    
End Class
