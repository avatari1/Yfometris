﻿Public Class Form4

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closebtn.Click
        program.tosave.Text = 0
        program.Enabled = True
        Me.Close()

    End Sub

    Private Sub closingsub(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.FormClosing
        program.tosave.Text = 0
        program.Enabled = True

    End Sub



    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles excelbtn.Click
        program.Saveasmenu.PerformClick()
    End Sub
    Private Sub reset1enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles excelbtn.MouseEnter, closebtn.MouseEnter
        Me.Cursor = Cursors.Hand


    End Sub
    Private Sub reset1leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles excelbtn.MouseLeave, closebtn.MouseLeave
        Me.Cursor = Cursors.Arrow

    End Sub

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class