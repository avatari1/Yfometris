﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class program
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.statusbar = New System.Windows.Forms.Panel()
        Me.menupanel = New System.Windows.Forms.Panel()
        Me.varpanel = New System.Windows.Forms.Panel()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OverviewToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.DeleteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubCorpusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ActivaeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OverviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VariablesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EecuteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LanguageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnglishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GreekToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItalianToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IndexOfHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu = New System.Windows.Forms.MenuStrip()
        Me.Openfol = New System.Windows.Forms.FolderBrowserDialog()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.CheckBox22 = New System.Windows.Forms.CheckBox()
        Me.CheckBox23 = New System.Windows.Forms.CheckBox()
        Me.CheckBox24 = New System.Windows.Forms.CheckBox()
        Me.selectall = New System.Windows.Forms.Button()
        Me.none = New System.Windows.Forms.Button()
        Me.done = New System.Windows.Forms.Button()
        Me.apply = New System.Windows.Forms.Button()
        Me.menupanel.SuspendLayout()
        Me.varpanel.SuspendLayout()
        Me.Menu.SuspendLayout()
        Me.SuspendLayout()
        '
        'statusbar
        '
        Me.statusbar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.statusbar.Location = New System.Drawing.Point(0, 296)
        Me.statusbar.Margin = New System.Windows.Forms.Padding(1)
        Me.statusbar.Name = "statusbar"
        Me.statusbar.Size = New System.Drawing.Size(360, 20)
        Me.statusbar.TabIndex = 0
        '
        'menupanel
        '
        Me.menupanel.Controls.Add(Me.Menu)
        Me.menupanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.menupanel.Location = New System.Drawing.Point(0, 0)
        Me.menupanel.Name = "menupanel"
        Me.menupanel.Size = New System.Drawing.Size(360, 30)
        Me.menupanel.TabIndex = 1
        '
        'varpanel
        '
        Me.varpanel.Controls.Add(Me.apply)
        Me.varpanel.Controls.Add(Me.done)
        Me.varpanel.Controls.Add(Me.none)
        Me.varpanel.Controls.Add(Me.selectall)
        Me.varpanel.Controls.Add(Me.CheckBox24)
        Me.varpanel.Controls.Add(Me.CheckBox23)
        Me.varpanel.Controls.Add(Me.CheckBox22)
        Me.varpanel.Controls.Add(Me.CheckBox21)
        Me.varpanel.Controls.Add(Me.CheckBox20)
        Me.varpanel.Controls.Add(Me.CheckBox19)
        Me.varpanel.Controls.Add(Me.CheckBox18)
        Me.varpanel.Controls.Add(Me.CheckBox17)
        Me.varpanel.Controls.Add(Me.CheckBox16)
        Me.varpanel.Controls.Add(Me.CheckBox15)
        Me.varpanel.Controls.Add(Me.CheckBox14)
        Me.varpanel.Controls.Add(Me.CheckBox13)
        Me.varpanel.Controls.Add(Me.CheckBox12)
        Me.varpanel.Controls.Add(Me.CheckBox11)
        Me.varpanel.Controls.Add(Me.CheckBox10)
        Me.varpanel.Controls.Add(Me.CheckBox9)
        Me.varpanel.Controls.Add(Me.CheckBox8)
        Me.varpanel.Controls.Add(Me.CheckBox7)
        Me.varpanel.Controls.Add(Me.CheckBox6)
        Me.varpanel.Controls.Add(Me.CheckBox5)
        Me.varpanel.Controls.Add(Me.CheckBox4)
        Me.varpanel.Controls.Add(Me.CheckBox3)
        Me.varpanel.Controls.Add(Me.CheckBox2)
        Me.varpanel.Controls.Add(Me.CheckBox1)
        Me.varpanel.Location = New System.Drawing.Point(12, 27)
        Me.varpanel.Name = "varpanel"
        Me.varpanel.Size = New System.Drawing.Size(336, 265)
        Me.varpanel.TabIndex = 2
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem1, Me.ToolStripSeparator2, Me.OpenToolStripMenuItem, Me.OverviewToolStripMenuItem1, Me.ToolStripSeparator3, Me.DeleteToolStripMenuItem1, Me.CloseToolStripMenuItem, Me.ToolStripSeparator4, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem1
        '
        Me.NewToolStripMenuItem1.Name = "NewToolStripMenuItem1"
        Me.NewToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NewToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.NewToolStripMenuItem1.Text = "New"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(149, 6)
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'OverviewToolStripMenuItem1
        '
        Me.OverviewToolStripMenuItem1.Name = "OverviewToolStripMenuItem1"
        Me.OverviewToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.OverviewToolStripMenuItem1.Text = "Overview"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(149, 6)
        '
        'DeleteToolStripMenuItem1
        '
        Me.DeleteToolStripMenuItem1.Name = "DeleteToolStripMenuItem1"
        Me.DeleteToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.DeleteToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.DeleteToolStripMenuItem1.Text = "Save"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(149, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "Quit"
        '
        'SubCorpusToolStripMenuItem
        '
        Me.SubCorpusToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.ToolStripSeparator1, Me.ActivaeToolStripMenuItem, Me.OverviewToolStripMenuItem, Me.DeleteToolStripMenuItem})
        Me.SubCorpusToolStripMenuItem.Name = "SubCorpusToolStripMenuItem"
        Me.SubCorpusToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.SubCorpusToolStripMenuItem.Text = "Sub-Corpus"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(149, 6)
        '
        'ActivaeToolStripMenuItem
        '
        Me.ActivaeToolStripMenuItem.Name = "ActivaeToolStripMenuItem"
        Me.ActivaeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ActivaeToolStripMenuItem.Text = "Activate"
        '
        'OverviewToolStripMenuItem
        '
        Me.OverviewToolStripMenuItem.Name = "OverviewToolStripMenuItem"
        Me.OverviewToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.OverviewToolStripMenuItem.Text = "Overview"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'VariablesToolStripMenuItem
        '
        Me.VariablesToolStripMenuItem.Name = "VariablesToolStripMenuItem"
        Me.VariablesToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.VariablesToolStripMenuItem.Text = "Variables"
        '
        'EecuteToolStripMenuItem
        '
        Me.EecuteToolStripMenuItem.Name = "EecuteToolStripMenuItem"
        Me.EecuteToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.EecuteToolStripMenuItem.Text = "Execute"
        '
        'LanguageToolStripMenuItem
        '
        Me.LanguageToolStripMenuItem.Checked = True
        Me.LanguageToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.LanguageToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.LanguageToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EnglishToolStripMenuItem, Me.GreekToolStripMenuItem, Me.ItalianToolStripMenuItem})
        Me.LanguageToolStripMenuItem.Name = "LanguageToolStripMenuItem"
        Me.LanguageToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.LanguageToolStripMenuItem.Text = "Language"
        '
        'EnglishToolStripMenuItem
        '
        Me.EnglishToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control
        Me.EnglishToolStripMenuItem.Checked = True
        Me.EnglishToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.EnglishToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.EnglishToolStripMenuItem.Name = "EnglishToolStripMenuItem"
        Me.EnglishToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.EnglishToolStripMenuItem.Text = "English"
        '
        'GreekToolStripMenuItem
        '
        Me.GreekToolStripMenuItem.Name = "GreekToolStripMenuItem"
        Me.GreekToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.GreekToolStripMenuItem.Text = "Greek"
        '
        'ItalianToolStripMenuItem
        '
        Me.ItalianToolStripMenuItem.Name = "ItalianToolStripMenuItem"
        Me.ItalianToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ItalianToolStripMenuItem.Text = "Italian"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.IndexOfHelpToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'IndexOfHelpToolStripMenuItem
        '
        Me.IndexOfHelpToolStripMenuItem.Name = "IndexOfHelpToolStripMenuItem"
        Me.IndexOfHelpToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.IndexOfHelpToolStripMenuItem.Text = "Index of help"
        '
        'Menu
        '
        Me.Menu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.SubCorpusToolStripMenuItem, Me.VariablesToolStripMenuItem, Me.EecuteToolStripMenuItem, Me.LanguageToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.Menu.Location = New System.Drawing.Point(0, 0)
        Me.Menu.Name = "Menu"
        Me.Menu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.Menu.Size = New System.Drawing.Size(360, 24)
        Me.Menu.TabIndex = 0
        Me.Menu.Text = "MenuStrip1"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(22, 5)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(48, 17)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "TTR"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(22, 28)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(63, 17)
        Me.CheckBox2.TabIndex = 1
        Me.CheckBox2.Text = "AWL_C"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(22, 51)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(68, 17)
        Me.CheckBox3.TabIndex = 2
        Me.CheckBox3.Text = "WL_Scd"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(22, 74)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(63, 17)
        Me.CheckBox4.TabIndex = 3
        Me.CheckBox4.Text = "AWL_S"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(22, 97)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(67, 17)
        Me.CheckBox5.TabIndex = 4
        Me.CheckBox5.Text = "WL_Ssd"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(22, 120)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(87, 17)
        Me.CheckBox6.TabIndex = 5
        Me.CheckBox6.Text = "Sent. Length"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(22, 143)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(50, 17)
        Me.CheckBox7.TabIndex = 6
        Me.CheckBox7.Text = "SLsd"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(22, 166)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(76, 17)
        Me.CheckBox8.TabIndex = 7
        Me.CheckBox8.Text = "Perc_Hapl"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(127, 5)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(71, 17)
        Me.CheckBox9.TabIndex = 8
        Me.CheckBox9.Text = "Perc_Disl"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(127, 28)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(69, 17)
        Me.CheckBox10.TabIndex = 9
        Me.CheckBox10.Text = "Dis_Hapl"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(127, 51)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(40, 17)
        Me.CheckBox11.TabIndex = 10
        Me.CheckBox11.Text = "LD"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(127, 74)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(64, 17)
        Me.CheckBox12.TabIndex = 11
        Me.CheckBox12.Text = "Yule's K"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(127, 97)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(78, 17)
        Me.CheckBox13.TabIndex = 12
        Me.CheckBox13.Text = "Simson's D"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(127, 120)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(61, 17)
        Me.CheckBox14.TabIndex = 13
        Me.CheckBox14.Text = "Zipf's Z"
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(127, 143)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(87, 17)
        Me.CheckBox15.TabIndex = 14
        Me.CheckBox15.Text = "CheckBox15"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Location = New System.Drawing.Point(127, 166)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(77, 17)
        Me.CheckBox16.TabIndex = 15
        Me.CheckBox16.Text = "Burrow's D"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Location = New System.Drawing.Point(224, 5)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(62, 17)
        Me.CheckBox17.TabIndex = 16
        Me.CheckBox17.Text = "Entropy"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Location = New System.Drawing.Point(224, 28)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(84, 17)
        Me.CheckBox18.TabIndex = 17
        Me.CheckBox18.Text = "Rel. Entropy"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(224, 51)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(86, 17)
        Me.CheckBox19.TabIndex = 18
        Me.CheckBox19.Text = "LW_C1....20"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(224, 74)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(83, 17)
        Me.CheckBox20.TabIndex = 19
        Me.CheckBox20.Text = "LW_S1...20"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Location = New System.Drawing.Point(224, 97)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(66, 17)
        Me.CheckBox21.TabIndex = 20
        Me.CheckBox21.Text = "W1,...,N"
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.Location = New System.Drawing.Point(224, 120)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(74, 17)
        Me.CheckBox22.TabIndex = 21
        Me.CheckBox22.Text = "UW1,....N"
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.Location = New System.Drawing.Point(224, 143)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(103, 17)
        Me.CheckBox23.TabIndex = 22
        Me.CheckBox23.Text = "B(G)_C(W)1,...N"
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.Location = New System.Drawing.Point(224, 166)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.Size = New System.Drawing.Size(91, 17)
        Me.CheckBox24.TabIndex = 23
        Me.CheckBox24.Text = "Disp Lex Freq"
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'selectall
        '
        Me.selectall.Location = New System.Drawing.Point(71, 189)
        Me.selectall.Name = "selectall"
        Me.selectall.Size = New System.Drawing.Size(81, 23)
        Me.selectall.TabIndex = 24
        Me.selectall.Text = "Select All"
        Me.selectall.UseVisualStyleBackColor = True
        '
        'none
        '
        Me.none.Location = New System.Drawing.Point(158, 189)
        Me.none.Name = "none"
        Me.none.Size = New System.Drawing.Size(81, 23)
        Me.none.TabIndex = 25
        Me.none.Text = "Select None"
        Me.none.UseVisualStyleBackColor = True
        '
        'done
        '
        Me.done.Location = New System.Drawing.Point(247, 243)
        Me.done.Name = "done"
        Me.done.Size = New System.Drawing.Size(89, 22)
        Me.done.TabIndex = 26
        Me.done.Text = "Done"
        Me.done.UseVisualStyleBackColor = True
        '
        'apply
        '
        Me.apply.Location = New System.Drawing.Point(152, 243)
        Me.apply.Name = "apply"
        Me.apply.Size = New System.Drawing.Size(89, 22)
        Me.apply.TabIndex = 27
        Me.apply.Text = "apply"
        Me.apply.UseVisualStyleBackColor = True
        '
        'program
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(360, 316)
        Me.Controls.Add(Me.varpanel)
        Me.Controls.Add(Me.menupanel)
        Me.Controls.Add(Me.statusbar)
        Me.MainMenuStrip = Me.Menu
        Me.Name = "program"
        Me.Text = "Text Analysis v1.0"
        Me.menupanel.ResumeLayout(False)
        Me.menupanel.PerformLayout()
        Me.varpanel.ResumeLayout(False)
        Me.varpanel.PerformLayout()
        Me.Menu.ResumeLayout(False)
        Me.Menu.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents statusbar As System.Windows.Forms.Panel
    Friend WithEvents menupanel As System.Windows.Forms.Panel
    Friend WithEvents varpanel As System.Windows.Forms.Panel
    Friend WithEvents Menu As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OverviewToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeleteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubCorpusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ActivaeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OverviewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VariablesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EecuteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LanguageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnglishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GreekToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItalianToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndexOfHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Openfol As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents CheckBox24 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox23 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox22 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox21 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox20 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox19 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox18 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox16 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox14 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox12 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox9 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox8 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents selectall As System.Windows.Forms.Button
    Friend WithEvents done As System.Windows.Forms.Button
    Friend WithEvents none As System.Windows.Forms.Button
    Friend WithEvents apply As System.Windows.Forms.Button

End Class
