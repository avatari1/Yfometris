﻿Public Class Form1

    Private Sub ActivaeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ActivaeToolStripMenuItem.Click

    End Sub
End Class
