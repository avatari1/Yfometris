﻿Imports System.IO

Public Class form3
    Dim irow, icol As Int32
    Dim K As Int32
    Dim passdata As String = Environment.CurrentDirectory.ToString & "\passdata.txt"
    Dim passwords As String = Environment.CurrentDirectory.ToString & "\passwords.txt"
    Dim s() As String
    Dim counter, tcbackup As Integer
    Dim fs As FileStream
    Dim sr As StreamReader
    Dim OK As Boolean
    Dim selcol1 As Int32 = 0
    Dim selcol2 As Int32 = 0
    Dim selcol3 As Int32 = 0
    Dim selcol4 As Int32 = 0
    Dim a(2000, 20) As String
    Dim c1(20), c2(20), c3(20), c4(20) As String
    Dim output As String
    Dim h(20), previewtext As String
    Dim ok1 As Boolean = False
    Dim ok2 As Boolean = False
    Dim ok3 As Boolean = False
    Dim ok4 As Boolean = False
    Dim filearray(2000), sublength As Int32
    Dim savearray(2000) As Int32
    Dim wcenable As Boolean
    Dim tcenable As Boolean
    Dim savelist As New ArrayList
    Dim metritis As Int32 = 0
    Dim out As String = ""
    Dim eng, gr, it As String


    Public Sub form3_show(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Shown
        Created1.Visible = False
        Try
            'clear combo
            Combo1value.Items.Clear()

            K = program.statusindex.Text
            Dim header, data As String
            Dim i As Int32
            Dim ai, aj As Int32
            fs = New FileStream(passdata, FileMode.Open)
            sr = New StreamReader(fs)

            header = sr.ReadLine()
            h = header.Split(" ")

            counter = -1

            output = ""

            While Not sr.EndOfStream
                counter = counter + 1
                data = sr.ReadLine()

                s = data.Split(vbTab)
                ' set column size for the s array
                icol = s.Length - 2
                For i = 0 To icol
                    ai = counter + 1
                    aj = i + 1
                    a(ai, aj) = s(i)

                Next

            End While
            fs.Close()
        Catch ex As Exception
            MsgBox("form 3 error 1 : table creation " & ex.ToString)
        End Try

        Try
            ' set row and column size for the a array
            irow = counter + 1
            icol += 1
            ' show bounds
            '  MsgBox("irow : " & irow & vbNewLine & "icol : " & icol)
            counter = 0
            irowlbl.Text &= irow
            icollbl.Text &= icol

        Catch ex As Exception
            MsgBox("form3 error 2 : arxikopoiisi selcol " & ex.ToString)
        End Try

    End Sub

    Private Sub acceptbtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles acceptbtn.Click
        Created1.Visible = False
        program.Enabled = True
        Me.Close()

    End Sub


    Private Sub closingsub(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.FormClosing
        Created1.Visible = False
        program.Enabled = True
    End Sub






    Public Sub Combo1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Combo1.SelectedIndexChanged
        Created1.Visible = False
        Combo1value.Items.Clear()
        Combo1value.Text = ""
        K = program.statusindex.Text

        If Combo1.SelectedIndex <> -1 Then
            'get column array for later selection
            Dim i As Int32

            If K = 1 Then
                For i = 1 To icol - 1
                    c1(i) = i + 1
                Next
            ElseIf K > 1 Then
                For i = 1 To K - 1
                    c1(i) = i
                Next
                For i = K + 1 To icol
                    c1(i - 1) = i
                Next
            End If
            If Combo1.SelectedIndex = -1 Then
                Combo1.SelectedIndex = 0
            End If
            selcol1 = c1(Combo1.SelectedIndex + 1)

            'populate value combo
            Dim datas1(2000) As String
            Dim idio As Boolean
            datas1(1) = a(1, selcol1)
            Combo1value.Items.Add(datas1(1))
            counter = 1
            For i = 1 To irow
                idio = False
                For j = 1 To counter
                    If a(i, selcol1) = datas1(j) Then
                        idio = True
                    End If
                Next
                If Not idio Then
                    counter = counter + 1
                    datas1(counter) = a(i, selcol1)
                    Combo1value.Items.Add(datas1(counter))

                End If
            Next

        End If


    End Sub

    Public Sub Combo2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Combo2.SelectedIndexChanged
        Created1.Visible = False
        Combo2value.Items.Clear()
        Combo2value.Text = ""
        K = program.statusindex.Text

        If Combo2.SelectedIndex <> -1 Then
            'get column array for later selection
            If K = 1 Then
                For i = 1 To icol - 1
                    c1(i) = i + 1
                Next
            ElseIf K > 1 Then
                For i = 1 To K - 1
                    c1(i) = i
                Next
                For i = K + 1 To icol
                    c1(i - 1) = i
                Next
            Else
                eng = "File Column Has Not Been Selected"
                gr = "Δεν έχει επιλεχθεί στήλη αρχείων"
                it = "File colonna non è stata selezionata"
                translate(out, eng, gr, it)

                MsgBox(out)
            End If
            selcol2 = c1(Combo2.SelectedIndex + 1)


            'populate value combo
            Dim datas2(2000) As String
            Dim idio As Boolean

            datas2(1) = a(1, selcol2)

            Combo2value.Items.Add(datas2(1))
            counter = 1
            For i = 1 To irow
                idio = False
                For j = 1 To counter
                    If a(i, selcol2) = datas2(j) Then
                        idio = True
                    End If
                Next
                If Not idio Then
                    counter = counter + 1
                    datas2(counter) = a(i, selcol2)
                    Combo2value.Items.Add(datas2(counter))
                End If
            Next

        End If

    End Sub

    Public Sub Combo3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Combo3.SelectedIndexChanged
        Created1.Visible = False
        Combo3value.Items.Clear()
        Combo3value.Text = ""

        K = program.statusindex.Text

        If Combo3.SelectedIndex <> -1 Then
            'get column array for later selection
            If K = 1 Then
                For i = 1 To icol - 1
                    c1(i) = i + 1
                Next
            ElseIf K > 1 Then
                For i = 1 To K - 1
                    c1(i) = i
                Next
                For i = K + 1 To icol
                    c1(i - 1) = i
                Next
            Else
                eng = "File Column Has Not Been Selected"
                gr = "Δεν έχει επιλεχθεί στήλη αρχείων"
                it = "File colonna non è stata selezionata"
                translate(out, eng, gr, it)

                MsgBox(out)
            End If
            selcol3 = c1(Combo3.SelectedIndex + 1)

            'populate value combo
            Dim datas3(2000) As String
            Dim idio As Boolean
            datas3(1) = a(1, selcol3)
            Combo3value.Items.Add(datas3(1))
            counter = 1
            For i = 1 To irow
                idio = False
                For j = 1 To counter
                    If a(i, selcol3) = datas3(j) Then
                        idio = True
                    End If
                Next
                If Not idio Then
                    counter = counter + 1
                    datas3(counter) = a(i, selcol3)
                    Combo3value.Items.Add(datas3(counter))
                End If
            Next

        End If

    End Sub

    Public Sub Combo4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Combo4.SelectedIndexChanged
        Created1.Visible = False
        Combo4value.Items.Clear()
        Combo4value.Text = ""
        K = program.statusindex.Text

        Dim i As Int32
        If Combo4.SelectedIndex <> -1 Then
            'get column array for later selection
            If K = 1 Then
                For i = 1 To icol - 1
                    c1(i) = i + 1
                Next
            ElseIf K > 1 Then
                For i = 1 To K - 1
                    c1(i) = i
                Next
                For i = K + 1 To icol
                    c1(i - 1) = i
                Next
            Else
                eng = "File Column Has Not Been Selected"
                gr = "Δεν έχει επιλεχθεί στήλη αρχείων"
                it = "File colonna non è stata selezionata"
                translate(out, eng, gr, it)

                MsgBox(out)
            End If
            selcol4 = c1(Combo4.SelectedIndex + 1)

            'populate value combo
            Dim datas4(2000) As String
            Dim idio As Boolean
            datas4(1) = a(1, selcol4)
            Combo4value.Items.Add(datas4(1))
            counter = 1
            For i = 1 To irow
                idio = False
                For j = 1 To counter
                    If a(i, selcol4) = datas4(j) Then
                        idio = True
                    End If
                Next
                If Not idio Then
                    counter = counter + 1
                    datas4(counter) = a(i, selcol4)
                    Combo4value.Items.Add(datas4(counter))
                End If
            Next

        End If

    End Sub


    Private Sub Combovalue_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Combo1value.SelectedIndexChanged, Combo2value.SelectedIndexChanged, Combo3value.SelectedIndexChanged, Combo4value.SelectedIndexChanged
        Created1.Visible = False
        Dim wc As Int32
        Dim i As Int32
        counter = 0
        wc = 0
        For i = 1 To irow

            If (check1(i) And check2(i) And check3(i) And check4(i)) Then
                counter += 1
                filearray(counter) = i

            End If

        Next
        sublength = counter
        textcount.Text = counter
        savearray = filearray

    End Sub

    Public Function check1(ByVal i As Integer) As Boolean
        If selcol1 = 0 Then
            check1 = True
        ElseIf (a(i, selcol1) = Combo1value.Text) Or (Combo1value.Text = "") Then
            check1 = True
        Else
            check1 = False
        End If
    End Function

    Public Function check2(ByVal i As Integer) As Boolean
        If selcol2 = 0 Then
            check2 = True
        ElseIf (a(i, selcol2) = Combo2value.Text) Or (Combo2value.Text = "") Then
            check2 = True
        Else
            check2 = False
        End If
    End Function
    Public Function check3(ByVal i As Integer) As Boolean
        If selcol3 = 0 Then
            check3 = True
        ElseIf (a(i, selcol3) = Combo3value.Text) Or (Combo3value.Text = "") Then
            check3 = True
        Else
            check3 = False
        End If
    End Function
    Public Function check4(ByVal i As Integer) As Boolean
        If selcol4 = 0 Then
            check4 = True
        ElseIf (a(i, selcol4) = Combo4value.Text) Or (Combo4value.Text = "") Then
            check4 = True
        Else
            check4 = False
        End If
    End Function

    Private Sub reset1enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reset1.MouseEnter, setwc.MouseEnter, settc.MouseEnter, acceptbtn.MouseEnter
        Me.Cursor = Cursors.Hand


    End Sub
    Private Sub reset1leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reset1.MouseLeave, setwc.MouseLeave, settc.MouseLeave, acceptbtn.MouseLeave
        Me.Cursor = Cursors.Arrow

    End Sub


    Private Sub reset1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reset1.Click

        selcol1 = 0
        selcol2 = 0
        selcol3 = 0
        selcol4 = 0
        resetall()
    End Sub

    Private Sub resetall()

        subname.Text = ""
        Created1.Visible = False
        Combo1.SelectedIndex = -1
        Combo1value.SelectedIndex = -1
        Combo1value.Items.Clear()
        Combo2.SelectedIndex = -1
        Combo2value.SelectedIndex = -1
        Combo2value.Items.Clear()
        Combo3.SelectedIndex = -1
        Combo3value.SelectedIndex = -1
        Combo3value.Items.Clear()
        Combo4.SelectedIndex = -1
        Combo4value.SelectedIndex = -1
        Combo4value.Items.Clear()
        textcount.Text = ""
        wordcount.Text = ""
        Checktc.Checked = False
        Checkwc.Checked = False
    End Sub




    Private Sub Checkwc_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Checkwc.CheckedChanged
        Created1.Visible = False
        If Checkwc.Checked Then
            wordcount.Enabled = True
            setwc.Visible = True
            opercombo.Enabled = True
            opercombo.SelectedIndex = 0
            If Not textcount.Text = "" Then
                tcbackup = textcount.Text
            Else
                tcbackup = -1
            End If
        Else
            wordcount.Font = New Font(wordcount.Font, FontStyle.Regular)
            wordcount.Enabled = False
            opercombo.Enabled = False
            setwc.Visible = False
            wcenable = False
            If tcbackup = -1 Then
                textcount.Text = tcbackup
            End If
        End If
    End Sub

    Private Sub Checktc_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Checktc.CheckedChanged
        Created1.Visible = False
        If Checktc.Checked Then
            textcount.Enabled = True
            settc.Visible = True
            If Not textcount.Text = "" Then
                tcbackup = textcount.Text
            Else
                tcbackup = 0
            End If

        Else
            textcount.Font = New Font(textcount.Font, FontStyle.Bold)
            textcount.Text = 0
            textcount.Enabled = False
            settc.Visible = False
            textcount.Text = tcbackup
            tcenable = False
        End If
    End Sub

    Private Sub create(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles createtbn.Click
        Dim condition0, condition1, condition4 As Boolean

        Dim subnumber As Int32 = program.sbcount.Text

        condition0 = (subnumber < 4)
        Try
            sublength = textcount.Text
        Catch ex As Exception
            sublength = 0
        End Try

        If Not condition0 Then

            eng = "There is no room for a new subcorpus"
            gr = " Δεν υπάρχει χώρος για επιπλέον υπόσωμα"
            it = "Non c'è spazio per un nuovo subcorpus"

            translate(out, eng, gr, it)
            MsgBox(out)
            'condition1 filearray length
        Else

            condition1 = (filearray(1) <> 0)
            If Not condition1 Then
                eng = "No meta linguistic feature selected"
                gr = " Δεν έχει επιλεχθεί κανένα Μετακειμενικό χαρακτηριστικό"
                it = "Non meta linguistica caratteristica selezionata"

                translate(out, eng, gr, it)
                MsgBox(out)
            Else
                'condition4 subcorpus name
                condition4 = (subname.Text <> "")
                If Not condition4 Then
                    eng = "Please select a subcorpus name"
                    gr = "Παρακαλώ επιλέξτε ένα όνομα για το υπόσωμα"
                    it = "Si prega di selezionare un nome subcorpus"
                    translate(out, eng, gr, it)
                    MsgBox(out)


                Else
                    Dim int As Int32
                    eng = "Do you wish to create Sub corpus " & subname.Text & " ?"
                    gr = "Θέλετε να δημιουργήσετε το υπόσωμα " & subname.Text & " ?"
                    it = "Deciderate creare subcorpus " & subname.Text & " ?"
                    translate(out, eng, gr, it)
                    Dim message As String = out
                    eng = "Subcorpus Creation"
                    gr = "Δημιουργία Υποσώματος"
                    it = "Subcorpus Creazione"
                    translate(out, eng, gr, it)
                    Dim title As String = out
                    int = MsgBox(message, vbYesNo + vbQuestion + vbDefaultButton2, title)

                    If int = vbYes Then


                        Dim ypostring As String = ""

                        For i = 1 To sublength
                            ypostring &= savearray(i) & vbTab
                        Next

                        'dimiourgia arxeiou

                        Dim arxeio As String
                        subnumber = program.sbcount.Text
                        subnumber += 1
                        program.sbcount.Text = subnumber


                        '''''''''''''''''''''''''''''''''''''''''''''
                        Dim sb As Int32
                        'need to find a free spot to enter the sub


                        If program.free1.Text = 0 Then
                            sb = 1
                        ElseIf program.free2.Text = 0 Then
                            sb = 2
                        ElseIf program.free3.Text = 0 Then
                            sb = 3
                        ElseIf program.free4.Text = 0 Then
                            sb = 4

                        End If

                        '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                        'spot found and stored in sb



                        arxeio = Environment.CurrentDirectory.ToString & "\sub" & sb & ".txt"
                        Dim grafe As New StreamWriter(arxeio)
                        grafe.Write(ypostring)
                        grafe.Close()


                        Select Case sb
                            Case 1
                                'energopoiisi twn kiriws menu 
                                'epeidi einai to prwto sub
                                program.Activatemenu.Enabled = True
                                program.overviewmenu1.Enabled = True
                                program.Deletemenu.Enabled = True

                                'dilwsi tou sub sta kiriws menu me to onoma tou
                                program.actSub1.Text = subname.Text
                                program.actSub1.Visible = True
                                program.oversub1.Visible = True
                                program.oversub1.Text = subname.Text
                                program.delsub1.Visible = True
                                program.delsub1.Text = subname.Text


                                ' make spot occupied

                                program.free1.Text = 1


                            Case 2
                                'dilwsi tou sub sta kiriws menu me to onoma tou

                                program.actSub2.Text = subname.Text
                                program.actSub2.Visible = True
                                program.oversub2.Text = subname.Text
                                program.oversub2.Visible = True
                                program.delsub2.Text = subname.Text
                                program.delsub2.Visible = True


                                ' make spot occupied

                                program.free2.Text = 1


                            Case 3
                                'dilwsi tou sub sta kiriws menu me to onoma tou

                                program.actSub3.Text = subname.Text
                                program.actSub3.Visible = True
                                program.oversub3.Text = subname.Text
                                program.oversub3.Visible = True
                                program.delsub3.Text = subname.Text
                                program.delsub3.Visible = True


                                ' make spot occupied

                                program.free3.Text = 1

                            Case 4
                                'dilwsi tou sub sta kiriws menu me to onoma tou
                                program.actSub4.Text = subname.Text
                                program.actSub4.Visible = True
                                program.oversub4.Text = subname.Text
                                program.oversub4.Visible = True
                                program.delsub4.Text = subname.Text
                                program.delsub4.Visible = True


                                ' make spot occupied

                                program.free4.Text = 1


                        End Select

                        resetall()
                        Created1.Visible = True
                    End If

                End If

            End If
        End If

    End Sub

    Public Sub translate(ByRef strigaki As String, ByVal eng As String, ByVal gr As String, ByVal it As String)

        If program.Englishmenu.Checked = True Then
            strigaki = eng
        ElseIf program.Greekmenu.Checked = True Then
            strigaki = gr
        ElseIf program.Italianmenu.Checked = True Then
            strigaki = it
        End If

    End Sub

    Private Function condition2(ByVal lekseis As Int32) As Boolean
        Dim wordlimit As Int32
        Dim telestis As String

        If Checkwc.Checked = False Then
            condition2 = True
        Else
            If wcenable = True Then
                wordlimit = wordcount.Text
                telestis = opercombo.SelectedText
                If telestis = ">=" Then
                    condition2 = (lekseis >= wordlimit)
                ElseIf telestis = "<=" Then
                    condition2 = (lekseis <= wordlimit)
                Else
                    condition2 = (lekseis = wordlimit)
                End If
            Else
                condition2 = True

            End If

        End If

    End Function

    Private Function condition3(ByVal filecounter As Int32, ByVal maxfilenumber As Int32) As Boolean

        If (Checktc.Checked = False) And (tcenable = False) Then
            condition3 = True
        Else
            condition3 = (filecounter < maxfilenumber)
        End If
    End Function



    Private Sub setwc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles setwc.Click
        Dim ir As Int32
        savelist.Clear()
        metritis = 0
        wcenable = True
        wordcount.Font = New Font(wordcount.Font, FontStyle.Bold)
        savelist.Add(0)
        Dim arx_num As Int32
        Try
            arx_num = wordcount.Text
        Catch ex As Exception
            Dim output21 As String = ""
            eng = "Please use integers only"
            gr = "Παρακαλώ χρησιμοποιείτε μόνο ακεραίους"
            it = "Si prega di usare solo numeri interi"
            translate(output21, eng, gr, it)
            MsgBox(output21)
        End Try

        Dim sigritiko As Int32
        If opercombo.SelectedIndex = 0 Then
            For i = 1 To sublength
                ir = filearray(i)
                sigritiko = a(ir, icol)
                If sigritiko >= arx_num Then
                    savelist.Add(ir)
                    metritis += 1
                End If
            Next
        ElseIf opercombo.SelectedIndex = 1 Then

            For i = 1 To sublength
                ir = filearray(i)
                sigritiko = a(ir, icol)

                If sigritiko <= arx_num Then
                    savelist.Add(ir)
                    metritis += 1
                End If
            Next


        ElseIf opercombo.SelectedIndex = 2 Then
            For i = 1 To sublength
                ir = filearray(i)
                sigritiko = a(ir, icol)
                If sigritiko = arx_num Then
                    savelist.Add(ir)
                    metritis += 1
                End If
            Next
        End If

        savearray = savelist.ToArray(GetType(Int32))

        textcount.Text = metritis


    End Sub

    Private Sub settc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles settc.Click


        If Not textcount.Text = "" Then
            textcount.Font = New Font(textcount.Font, FontStyle.Bold)
            tcenable = True

        End If

    End Sub


    Private Sub wordcount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles wordcount.TextChanged
        Created1.Visible = False
        wordcount.Font = New Font(wordcount.Font, FontStyle.Regular)
    End Sub

    Private Sub textcount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textcount.TextChanged
        Created1.Visible = False
        textcount.Font = New Font(textcount.Font, FontStyle.Regular)
    End Sub



  End Class