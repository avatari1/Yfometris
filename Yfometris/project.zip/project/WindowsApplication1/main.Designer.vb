﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class program
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.statusbar = New System.Windows.Forms.ToolStripStatusLabel()
        Me.menupanel = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Menu1 = New System.Windows.Forms.MenuStrip()
        Me.Filemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.openexcelmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.opendir = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.OverviewMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Validatefilemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.Saveasmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Closemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.Quittmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.virtualcorpusmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Newmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.Activatemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.actSub1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.actSub2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.actSub3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.actSub4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.overviewmenu1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.oversub1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.oversub2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.oversub3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.oversub4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Deletemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.delsub1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.delsub2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.delsub3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.delsub4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Variablesmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Executemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Languagemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Englishmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Greekmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Italianmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Helpmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Aboutmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.IndexOfHelpmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Excelmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tabs = New System.Windows.Forms.TabControl()
        Me.tab1 = New System.Windows.Forms.TabPage()
        Me.varpanel = New System.Windows.Forms.Panel()
        Me.Paneln = New System.Windows.Forms.Panel()
        Me.okbtnn = New System.Windows.Forms.Button()
        Me.textn = New System.Windows.Forms.TextBox()
        Me.w1btn = New System.Windows.Forms.Button()
        Me.uwbtn = New System.Windows.Forms.Button()
        Me.okbutton = New System.Windows.Forms.Button()
        Me.selectnonebutton = New System.Windows.Forms.Button()
        Me.selectallbutton = New System.Windows.Forms.Button()
        Me.var17 = New System.Windows.Forms.CheckBox()
        Me.var16 = New System.Windows.Forms.CheckBox()
        Me.var15 = New System.Windows.Forms.CheckBox()
        Me.var14 = New System.Windows.Forms.CheckBox()
        Me.var13 = New System.Windows.Forms.CheckBox()
        Me.var12 = New System.Windows.Forms.CheckBox()
        Me.var11 = New System.Windows.Forms.CheckBox()
        Me.var10 = New System.Windows.Forms.CheckBox()
        Me.var9 = New System.Windows.Forms.CheckBox()
        Me.var8 = New System.Windows.Forms.CheckBox()
        Me.var7 = New System.Windows.Forms.CheckBox()
        Me.var6 = New System.Windows.Forms.CheckBox()
        Me.var5 = New System.Windows.Forms.CheckBox()
        Me.var4 = New System.Windows.Forms.CheckBox()
        Me.var3 = New System.Windows.Forms.CheckBox()
        Me.var2 = New System.Windows.Forms.CheckBox()
        Me.var1 = New System.Windows.Forms.CheckBox()
        Me.Tab2 = New System.Windows.Forms.TabPage()
        Me.varpanel2 = New System.Windows.Forms.Panel()
        Me.advselectnone = New System.Windows.Forms.Button()
        Me.advselectall = New System.Windows.Forms.Button()
        Me.advvar7 = New System.Windows.Forms.CheckBox()
        Me.advvar6 = New System.Windows.Forms.CheckBox()
        Me.advvar5 = New System.Windows.Forms.CheckBox()
        Me.advvar4 = New System.Windows.Forms.CheckBox()
        Me.advvar3 = New System.Windows.Forms.CheckBox()
        Me.advvar2 = New System.Windows.Forms.CheckBox()
        Me.advvar1 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.leks = New System.Windows.Forms.Label()
        Me.sent = New System.Windows.Forms.Label()
        Me.sl = New System.Windows.Forms.Label()
        Me.defaultbutton = New System.Windows.Forms.Button()
        Me.stext = New System.Windows.Forms.TextBox()
        Me.statuspanel = New System.Windows.Forms.Panel()
        Me.labelswitches = New System.Windows.Forms.Panel()
        Me.tosave = New System.Windows.Forms.Label()
        Me.dtlbl = New System.Windows.Forms.Label()
        Me.freeslots = New System.Windows.Forms.Label()
        Me.free4 = New System.Windows.Forms.Label()
        Me.free3 = New System.Windows.Forms.Label()
        Me.free2 = New System.Windows.Forms.Label()
        Me.free1 = New System.Windows.Forms.Label()
        Me.sbcount = New System.Windows.Forms.Label()
        Me.stileslbl = New System.Windows.Forms.Label()
        Me.statusindex = New System.Windows.Forms.Label()
        Me.excellbl = New System.Windows.Forms.Label()
        Me.directorylbl = New System.Windows.Forms.Label()
        Me.statusdir = New System.Windows.Forms.Label()
        Me.statusfile = New System.Windows.Forms.Label()
        Me.percentage = New System.Windows.Forms.Label()
        Me.ProgressBar = New System.Windows.Forms.ProgressBar()
        Me.hidden = New System.Windows.Forms.Panel()
        Me.job = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.savebarpanel = New System.Windows.Forms.Panel()
        Me.saving = New System.Windows.Forms.Label()
        Me.prb = New System.Windows.Forms.ProgressBar()
        Me.cancelbtn = New System.Windows.Forms.Button()
        Me.Corpus = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.StatusStrip1.SuspendLayout()
        Me.menupanel.SuspendLayout()
        Me.Menu1.SuspendLayout()
        Me.Tabs.SuspendLayout()
        Me.tab1.SuspendLayout()
        Me.varpanel.SuspendLayout()
        Me.Paneln.SuspendLayout()
        Me.Tab2.SuspendLayout()
        Me.varpanel2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.statuspanel.SuspendLayout()
        Me.labelswitches.SuspendLayout()
        Me.hidden.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.savebarpanel.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statusbar})
        Me.StatusStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow
        Me.StatusStrip1.Location = New System.Drawing.Point(0, -3)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(584, 26)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'statusbar
        '
        Me.statusbar.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.statusbar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.statusbar.Name = "statusbar"
        Me.statusbar.Size = New System.Drawing.Size(66, 28)
        Me.statusbar.Text = "Ready"
        '
        'menupanel
        '
        Me.menupanel.Controls.Add(Me.Panel2)
        Me.menupanel.Controls.Add(Me.Menu1)
        Me.menupanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.menupanel.Location = New System.Drawing.Point(0, 0)
        Me.menupanel.Margin = New System.Windows.Forms.Padding(4)
        Me.menupanel.Name = "menupanel"
        Me.menupanel.Size = New System.Drawing.Size(762, 37)
        Me.menupanel.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(4, 36)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(771, 438)
        Me.Panel2.TabIndex = 1
        '
        'Menu1
        '
        Me.Menu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Filemenu, Me.virtualcorpusmenu, Me.Variablesmenu, Me.Executemenu, Me.Languagemenu, Me.Helpmenu, Me.Excelmenu})
        Me.Menu1.Location = New System.Drawing.Point(0, 0)
        Me.Menu1.Name = "Menu1"
        Me.Menu1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.Menu1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.Menu1.Size = New System.Drawing.Size(762, 28)
        Me.Menu1.TabIndex = 0
        Me.Menu1.Text = "MenuStrip1"
        '
        'Filemenu
        '
        Me.Filemenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.openexcelmenu, Me.opendir, Me.ToolStripSeparator2, Me.OverviewMenu, Me.Validatefilemenu, Me.ToolStripSeparator3, Me.Saveasmenu, Me.Closemenu, Me.ToolStripSeparator4, Me.Quittmenu})
        Me.Filemenu.Name = "Filemenu"
        Me.Filemenu.Size = New System.Drawing.Size(44, 24)
        Me.Filemenu.Text = "File"
        '
        'openexcelmenu
        '
        Me.openexcelmenu.Name = "openexcelmenu"
        Me.openexcelmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.openexcelmenu.Size = New System.Drawing.Size(265, 24)
        Me.openexcelmenu.Text = "Open Excel File"
        '
        'opendir
        '
        Me.opendir.Enabled = False
        Me.opendir.Name = "opendir"
        Me.opendir.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.opendir.Size = New System.Drawing.Size(265, 24)
        Me.opendir.Text = "Select text Directory"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(262, 6)
        '
        'OverviewMenu
        '
        Me.OverviewMenu.Enabled = False
        Me.OverviewMenu.Name = "OverviewMenu"
        Me.OverviewMenu.Size = New System.Drawing.Size(265, 24)
        Me.OverviewMenu.Text = "Overview"
        '
        'Validatefilemenu
        '
        Me.Validatefilemenu.Enabled = False
        Me.Validatefilemenu.Name = "Validatefilemenu"
        Me.Validatefilemenu.Size = New System.Drawing.Size(265, 24)
        Me.Validatefilemenu.Text = "Validate File"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(262, 6)
        '
        'Saveasmenu
        '
        Me.Saveasmenu.Enabled = False
        Me.Saveasmenu.Name = "Saveasmenu"
        Me.Saveasmenu.Size = New System.Drawing.Size(265, 24)
        Me.Saveasmenu.Text = "Save As"
        '
        'Closemenu
        '
        Me.Closemenu.Enabled = False
        Me.Closemenu.Name = "Closemenu"
        Me.Closemenu.Size = New System.Drawing.Size(265, 24)
        Me.Closemenu.Text = "Close"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(262, 6)
        '
        'Quittmenu
        '
        Me.Quittmenu.Name = "Quittmenu"
        Me.Quittmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.Quittmenu.Size = New System.Drawing.Size(265, 24)
        Me.Quittmenu.Text = "Quit"
        '
        'virtualcorpusmenu
        '
        Me.virtualcorpusmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Newmenu, Me.ToolStripSeparator1, Me.Activatemenu, Me.overviewmenu1, Me.Deletemenu})
        Me.virtualcorpusmenu.Enabled = False
        Me.virtualcorpusmenu.Name = "virtualcorpusmenu"
        Me.virtualcorpusmenu.Size = New System.Drawing.Size(98, 24)
        Me.virtualcorpusmenu.Text = "Sub-Corpus"
        '
        'Newmenu
        '
        Me.Newmenu.Name = "Newmenu"
        Me.Newmenu.Size = New System.Drawing.Size(139, 24)
        Me.Newmenu.Text = "New"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(136, 6)
        '
        'Activatemenu
        '
        Me.Activatemenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.actSub1, Me.actSub2, Me.actSub3, Me.actSub4})
        Me.Activatemenu.Enabled = False
        Me.Activatemenu.Name = "Activatemenu"
        Me.Activatemenu.Size = New System.Drawing.Size(139, 24)
        Me.Activatemenu.Text = "Activate"
        '
        'actSub1
        '
        Me.actSub1.Name = "actSub1"
        Me.actSub1.Size = New System.Drawing.Size(109, 24)
        Me.actSub1.Text = "sub1"
        Me.actSub1.Visible = False
        '
        'actSub2
        '
        Me.actSub2.Name = "actSub2"
        Me.actSub2.Size = New System.Drawing.Size(109, 24)
        Me.actSub2.Text = "sub2"
        Me.actSub2.Visible = False
        '
        'actSub3
        '
        Me.actSub3.Name = "actSub3"
        Me.actSub3.Size = New System.Drawing.Size(109, 24)
        Me.actSub3.Text = "sub3"
        Me.actSub3.Visible = False
        '
        'actSub4
        '
        Me.actSub4.Name = "actSub4"
        Me.actSub4.Size = New System.Drawing.Size(109, 24)
        Me.actSub4.Text = "sub4"
        Me.actSub4.Visible = False
        '
        'overviewmenu1
        '
        Me.overviewmenu1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.oversub1, Me.oversub2, Me.oversub3, Me.oversub4})
        Me.overviewmenu1.Enabled = False
        Me.overviewmenu1.Name = "overviewmenu1"
        Me.overviewmenu1.Size = New System.Drawing.Size(139, 24)
        Me.overviewmenu1.Text = "Overview"
        '
        'oversub1
        '
        Me.oversub1.Name = "oversub1"
        Me.oversub1.Size = New System.Drawing.Size(109, 24)
        Me.oversub1.Text = "sub1"
        Me.oversub1.Visible = False
        '
        'oversub2
        '
        Me.oversub2.Name = "oversub2"
        Me.oversub2.Size = New System.Drawing.Size(109, 24)
        Me.oversub2.Text = "sub2"
        Me.oversub2.Visible = False
        '
        'oversub3
        '
        Me.oversub3.Name = "oversub3"
        Me.oversub3.Size = New System.Drawing.Size(109, 24)
        Me.oversub3.Text = "sub3"
        Me.oversub3.Visible = False
        '
        'oversub4
        '
        Me.oversub4.Name = "oversub4"
        Me.oversub4.Size = New System.Drawing.Size(109, 24)
        Me.oversub4.Text = "sub4"
        Me.oversub4.Visible = False
        '
        'Deletemenu
        '
        Me.Deletemenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.delsub1, Me.delsub2, Me.delsub3, Me.delsub4})
        Me.Deletemenu.Enabled = False
        Me.Deletemenu.Name = "Deletemenu"
        Me.Deletemenu.Size = New System.Drawing.Size(139, 24)
        Me.Deletemenu.Text = "Delete"
        '
        'delsub1
        '
        Me.delsub1.Name = "delsub1"
        Me.delsub1.Size = New System.Drawing.Size(109, 24)
        Me.delsub1.Text = "sub1"
        Me.delsub1.Visible = False
        '
        'delsub2
        '
        Me.delsub2.Name = "delsub2"
        Me.delsub2.Size = New System.Drawing.Size(109, 24)
        Me.delsub2.Text = "sub2"
        Me.delsub2.Visible = False
        '
        'delsub3
        '
        Me.delsub3.Name = "delsub3"
        Me.delsub3.Size = New System.Drawing.Size(109, 24)
        Me.delsub3.Text = "sub3"
        Me.delsub3.Visible = False
        '
        'delsub4
        '
        Me.delsub4.Name = "delsub4"
        Me.delsub4.Size = New System.Drawing.Size(109, 24)
        Me.delsub4.Text = "sub4"
        Me.delsub4.Visible = False
        '
        'Variablesmenu
        '
        Me.Variablesmenu.Enabled = False
        Me.Variablesmenu.Name = "Variablesmenu"
        Me.Variablesmenu.Size = New System.Drawing.Size(82, 24)
        Me.Variablesmenu.Text = "Variables"
        '
        'Executemenu
        '
        Me.Executemenu.Enabled = False
        Me.Executemenu.Name = "Executemenu"
        Me.Executemenu.Size = New System.Drawing.Size(72, 24)
        Me.Executemenu.Text = "Execute"
        '
        'Languagemenu
        '
        Me.Languagemenu.Checked = True
        Me.Languagemenu.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Languagemenu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Languagemenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Englishmenu, Me.Greekmenu, Me.Italianmenu})
        Me.Languagemenu.Name = "Languagemenu"
        Me.Languagemenu.Size = New System.Drawing.Size(86, 24)
        Me.Languagemenu.Text = "Language"
        '
        'Englishmenu
        '
        Me.Englishmenu.BackColor = System.Drawing.SystemColors.Control
        Me.Englishmenu.Checked = True
        Me.Englishmenu.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Englishmenu.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Englishmenu.Name = "Englishmenu"
        Me.Englishmenu.Size = New System.Drawing.Size(125, 24)
        Me.Englishmenu.Text = "English"
        '
        'Greekmenu
        '
        Me.Greekmenu.Name = "Greekmenu"
        Me.Greekmenu.Size = New System.Drawing.Size(125, 24)
        Me.Greekmenu.Text = "Greek"
        '
        'Italianmenu
        '
        Me.Italianmenu.Name = "Italianmenu"
        Me.Italianmenu.Size = New System.Drawing.Size(125, 24)
        Me.Italianmenu.Text = "Italian"
        '
        'Helpmenu
        '
        Me.Helpmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Aboutmenu, Me.IndexOfHelpmenu})
        Me.Helpmenu.Name = "Helpmenu"
        Me.Helpmenu.Size = New System.Drawing.Size(53, 24)
        Me.Helpmenu.Text = "Help"
        '
        'Aboutmenu
        '
        Me.Aboutmenu.Name = "Aboutmenu"
        Me.Aboutmenu.Size = New System.Drawing.Size(165, 24)
        Me.Aboutmenu.Text = "About"
        '
        'IndexOfHelpmenu
        '
        Me.IndexOfHelpmenu.Name = "IndexOfHelpmenu"
        Me.IndexOfHelpmenu.Size = New System.Drawing.Size(165, 24)
        Me.IndexOfHelpmenu.Text = "Index of help"
        '
        'Excelmenu
        '
        Me.Excelmenu.Name = "Excelmenu"
        Me.Excelmenu.Size = New System.Drawing.Size(55, 24)
        Me.Excelmenu.Text = "excel"
        Me.Excelmenu.Visible = False
        '
        'Tabs
        '
        Me.Tabs.Controls.Add(Me.tab1)
        Me.Tabs.Controls.Add(Me.Tab2)
        Me.Tabs.Controls.Add(Me.TabPage1)
        Me.Tabs.Location = New System.Drawing.Point(16, 44)
        Me.Tabs.Margin = New System.Windows.Forms.Padding(4)
        Me.Tabs.Name = "Tabs"
        Me.Tabs.SelectedIndex = 0
        Me.Tabs.Size = New System.Drawing.Size(747, 427)
        Me.Tabs.TabIndex = 28
        Me.Tabs.Visible = False
        '
        'tab1
        '
        Me.tab1.Controls.Add(Me.varpanel)
        Me.tab1.Location = New System.Drawing.Point(4, 25)
        Me.tab1.Margin = New System.Windows.Forms.Padding(4)
        Me.tab1.Name = "tab1"
        Me.tab1.Padding = New System.Windows.Forms.Padding(4)
        Me.tab1.Size = New System.Drawing.Size(739, 398)
        Me.tab1.TabIndex = 0
        Me.tab1.Text = "Variables"
        Me.tab1.UseVisualStyleBackColor = True
        '
        'varpanel
        '
        Me.varpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.varpanel.Controls.Add(Me.Paneln)
        Me.varpanel.Controls.Add(Me.w1btn)
        Me.varpanel.Controls.Add(Me.uwbtn)
        Me.varpanel.Controls.Add(Me.okbutton)
        Me.varpanel.Controls.Add(Me.selectnonebutton)
        Me.varpanel.Controls.Add(Me.selectallbutton)
        Me.varpanel.Controls.Add(Me.var17)
        Me.varpanel.Controls.Add(Me.var16)
        Me.varpanel.Controls.Add(Me.var15)
        Me.varpanel.Controls.Add(Me.var14)
        Me.varpanel.Controls.Add(Me.var13)
        Me.varpanel.Controls.Add(Me.var12)
        Me.varpanel.Controls.Add(Me.var11)
        Me.varpanel.Controls.Add(Me.var10)
        Me.varpanel.Controls.Add(Me.var9)
        Me.varpanel.Controls.Add(Me.var8)
        Me.varpanel.Controls.Add(Me.var7)
        Me.varpanel.Controls.Add(Me.var6)
        Me.varpanel.Controls.Add(Me.var5)
        Me.varpanel.Controls.Add(Me.var4)
        Me.varpanel.Controls.Add(Me.var3)
        Me.varpanel.Controls.Add(Me.var2)
        Me.varpanel.Controls.Add(Me.var1)
        Me.varpanel.Location = New System.Drawing.Point(4, 2)
        Me.varpanel.Margin = New System.Windows.Forms.Padding(4)
        Me.varpanel.Name = "varpanel"
        Me.varpanel.Size = New System.Drawing.Size(727, 379)
        Me.varpanel.TabIndex = 3
        '
        'Paneln
        '
        Me.Paneln.Controls.Add(Me.okbtnn)
        Me.Paneln.Controls.Add(Me.textn)
        Me.Paneln.Location = New System.Drawing.Point(384, 242)
        Me.Paneln.Margin = New System.Windows.Forms.Padding(4)
        Me.Paneln.Name = "Paneln"
        Me.Paneln.Size = New System.Drawing.Size(129, 30)
        Me.Paneln.TabIndex = 30
        Me.Paneln.Visible = False
        '
        'okbtnn
        '
        Me.okbtnn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.okbtnn.Location = New System.Drawing.Point(71, 0)
        Me.okbtnn.Margin = New System.Windows.Forms.Padding(4)
        Me.okbtnn.Name = "okbtnn"
        Me.okbtnn.Size = New System.Drawing.Size(57, 30)
        Me.okbtnn.TabIndex = 1
        Me.okbtnn.Text = "ok"
        Me.okbtnn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.okbtnn.UseVisualStyleBackColor = True
        '
        'textn
        '
        Me.textn.Location = New System.Drawing.Point(5, 1)
        Me.textn.Margin = New System.Windows.Forms.Padding(4)
        Me.textn.Name = "textn"
        Me.textn.Size = New System.Drawing.Size(56, 22)
        Me.textn.TabIndex = 0
        '
        'w1btn
        '
        Me.w1btn.BackColor = System.Drawing.Color.WhiteSmoke
        Me.w1btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.w1btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.w1btn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.w1btn.Location = New System.Drawing.Point(264, 242)
        Me.w1btn.Margin = New System.Windows.Forms.Padding(4)
        Me.w1btn.Name = "w1btn"
        Me.w1btn.Size = New System.Drawing.Size(104, 30)
        Me.w1btn.TabIndex = 29
        Me.w1btn.Text = "W1,2,3....N"
        Me.w1btn.UseVisualStyleBackColor = False
        '
        'uwbtn
        '
        Me.uwbtn.BackColor = System.Drawing.Color.WhiteSmoke
        Me.uwbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.uwbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.uwbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.uwbtn.Location = New System.Drawing.Point(264, 279)
        Me.uwbtn.Margin = New System.Windows.Forms.Padding(4)
        Me.uwbtn.Name = "uwbtn"
        Me.uwbtn.Size = New System.Drawing.Size(104, 30)
        Me.uwbtn.TabIndex = 28
        Me.uwbtn.Text = "UW1,..K"
        Me.uwbtn.UseVisualStyleBackColor = False
        '
        'okbutton
        '
        Me.okbutton.Location = New System.Drawing.Point(588, 347)
        Me.okbutton.Margin = New System.Windows.Forms.Padding(4)
        Me.okbutton.Name = "okbutton"
        Me.okbutton.Size = New System.Drawing.Size(119, 27)
        Me.okbutton.TabIndex = 27
        Me.okbutton.Text = "OK"
        Me.okbutton.UseVisualStyleBackColor = True
        '
        'selectnonebutton
        '
        Me.selectnonebutton.Location = New System.Drawing.Point(569, 6)
        Me.selectnonebutton.Margin = New System.Windows.Forms.Padding(4)
        Me.selectnonebutton.Name = "selectnonebutton"
        Me.selectnonebutton.Size = New System.Drawing.Size(147, 28)
        Me.selectnonebutton.TabIndex = 25
        Me.selectnonebutton.Text = "Select None"
        Me.selectnonebutton.UseVisualStyleBackColor = True
        '
        'selectallbutton
        '
        Me.selectallbutton.Location = New System.Drawing.Point(413, 6)
        Me.selectallbutton.Margin = New System.Windows.Forms.Padding(4)
        Me.selectallbutton.Name = "selectallbutton"
        Me.selectallbutton.Size = New System.Drawing.Size(147, 28)
        Me.selectallbutton.TabIndex = 24
        Me.selectallbutton.Text = "Select All"
        Me.selectallbutton.UseVisualStyleBackColor = True
        '
        'var17
        '
        Me.var17.AutoSize = True
        Me.var17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var17.Location = New System.Drawing.Point(427, 62)
        Me.var17.Margin = New System.Windows.Forms.Padding(4)
        Me.var17.Name = "var17"
        Me.var17.Size = New System.Drawing.Size(137, 24)
        Me.var17.TabIndex = 23
        Me.var17.Text = "Disp Lex Freq"
        Me.var17.UseVisualStyleBackColor = True
        '
        'var16
        '
        Me.var16.AutoSize = True
        Me.var16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var16.Location = New System.Drawing.Point(240, 320)
        Me.var16.Margin = New System.Windows.Forms.Padding(4)
        Me.var16.Name = "var16"
        Me.var16.Size = New System.Drawing.Size(154, 24)
        Me.var16.TabIndex = 22
        Me.var16.Text = "B(G)_C(W)1,...N"
        Me.var16.UseVisualStyleBackColor = True
        '
        'var15
        '
        Me.var15.AutoSize = True
        Me.var15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var15.Location = New System.Drawing.Point(240, 283)
        Me.var15.Margin = New System.Windows.Forms.Padding(4)
        Me.var15.Name = "var15"
        Me.var15.Size = New System.Drawing.Size(99, 24)
        Me.var15.TabIndex = 21
        Me.var15.Text = "UW1,....K"
        Me.var15.UseVisualStyleBackColor = True
        '
        'var14
        '
        Me.var14.AutoSize = True
        Me.var14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var14.Location = New System.Drawing.Point(240, 246)
        Me.var14.Margin = New System.Windows.Forms.Padding(4)
        Me.var14.Name = "var14"
        Me.var14.Size = New System.Drawing.Size(88, 24)
        Me.var14.TabIndex = 20
        Me.var14.Text = "W1,...,N"
        Me.var14.UseVisualStyleBackColor = True
        '
        'var13
        '
        Me.var13.AutoSize = True
        Me.var13.Enabled = False
        Me.var13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var13.Location = New System.Drawing.Point(240, 209)
        Me.var13.Margin = New System.Windows.Forms.Padding(4)
        Me.var13.Name = "var13"
        Me.var13.Size = New System.Drawing.Size(116, 24)
        Me.var13.TabIndex = 19
        Me.var13.Text = "LW_S1...10"
        Me.var13.UseVisualStyleBackColor = True
        '
        'var12
        '
        Me.var12.AutoSize = True
        Me.var12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var12.Location = New System.Drawing.Point(240, 172)
        Me.var12.Margin = New System.Windows.Forms.Padding(4)
        Me.var12.Name = "var12"
        Me.var12.Size = New System.Drawing.Size(121, 24)
        Me.var12.TabIndex = 18
        Me.var12.Text = "LW_C1....20"
        Me.var12.UseVisualStyleBackColor = True
        '
        'var11
        '
        Me.var11.AutoSize = True
        Me.var11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var11.Location = New System.Drawing.Point(240, 135)
        Me.var11.Margin = New System.Windows.Forms.Padding(4)
        Me.var11.Name = "var11"
        Me.var11.Size = New System.Drawing.Size(54, 24)
        Me.var11.TabIndex = 10
        Me.var11.Text = "LD"
        Me.var11.UseVisualStyleBackColor = True
        '
        'var10
        '
        Me.var10.AutoSize = True
        Me.var10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var10.Location = New System.Drawing.Point(240, 98)
        Me.var10.Margin = New System.Windows.Forms.Padding(4)
        Me.var10.Name = "var10"
        Me.var10.Size = New System.Drawing.Size(107, 24)
        Me.var10.TabIndex = 9
        Me.var10.Text = "Dis_HapL"
        Me.var10.UseVisualStyleBackColor = True
        '
        'var9
        '
        Me.var9.AutoSize = True
        Me.var9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var9.Location = New System.Drawing.Point(240, 62)
        Me.var9.Margin = New System.Windows.Forms.Padding(4)
        Me.var9.Name = "var9"
        Me.var9.Size = New System.Drawing.Size(111, 24)
        Me.var9.TabIndex = 8
        Me.var9.Text = "Perc_DisL"
        Me.var9.UseVisualStyleBackColor = True
        '
        'var8
        '
        Me.var8.AutoSize = True
        Me.var8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var8.Location = New System.Drawing.Point(53, 320)
        Me.var8.Margin = New System.Windows.Forms.Padding(4)
        Me.var8.Name = "var8"
        Me.var8.Size = New System.Drawing.Size(116, 24)
        Me.var8.TabIndex = 7
        Me.var8.Text = "Perc_HapL"
        Me.var8.UseVisualStyleBackColor = True
        '
        'var7
        '
        Me.var7.AutoSize = True
        Me.var7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var7.Location = New System.Drawing.Point(53, 283)
        Me.var7.Margin = New System.Windows.Forms.Padding(4)
        Me.var7.Name = "var7"
        Me.var7.Size = New System.Drawing.Size(70, 24)
        Me.var7.TabIndex = 6
        Me.var7.Text = "SLsd"
        Me.var7.UseVisualStyleBackColor = True
        '
        'var6
        '
        Me.var6.AutoSize = True
        Me.var6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var6.Location = New System.Drawing.Point(53, 246)
        Me.var6.Margin = New System.Windows.Forms.Padding(4)
        Me.var6.Name = "var6"
        Me.var6.Size = New System.Drawing.Size(125, 24)
        Me.var6.TabIndex = 5
        Me.var6.Text = "Sent. Length"
        Me.var6.UseVisualStyleBackColor = True
        '
        'var5
        '
        Me.var5.AutoSize = True
        Me.var5.Enabled = False
        Me.var5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var5.Location = New System.Drawing.Point(53, 209)
        Me.var5.Margin = New System.Windows.Forms.Padding(4)
        Me.var5.Name = "var5"
        Me.var5.Size = New System.Drawing.Size(95, 24)
        Me.var5.TabIndex = 4
        Me.var5.Text = "WL_Ssd"
        Me.var5.UseVisualStyleBackColor = True
        '
        'var4
        '
        Me.var4.AutoSize = True
        Me.var4.Enabled = False
        Me.var4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var4.Location = New System.Drawing.Point(53, 172)
        Me.var4.Margin = New System.Windows.Forms.Padding(4)
        Me.var4.Name = "var4"
        Me.var4.Size = New System.Drawing.Size(88, 24)
        Me.var4.TabIndex = 3
        Me.var4.Text = "AWL_S"
        Me.var4.UseVisualStyleBackColor = True
        '
        'var3
        '
        Me.var3.AutoSize = True
        Me.var3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var3.Location = New System.Drawing.Point(53, 135)
        Me.var3.Margin = New System.Windows.Forms.Padding(4)
        Me.var3.Name = "var3"
        Me.var3.Size = New System.Drawing.Size(96, 24)
        Me.var3.TabIndex = 2
        Me.var3.Text = "WL_Csd"
        Me.var3.UseVisualStyleBackColor = True
        '
        'var2
        '
        Me.var2.AutoSize = True
        Me.var2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var2.Location = New System.Drawing.Point(53, 98)
        Me.var2.Margin = New System.Windows.Forms.Padding(4)
        Me.var2.Name = "var2"
        Me.var2.Size = New System.Drawing.Size(89, 24)
        Me.var2.TabIndex = 1
        Me.var2.Text = "AWL_C"
        Me.var2.UseVisualStyleBackColor = True
        '
        'var1
        '
        Me.var1.AutoSize = True
        Me.var1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.var1.Location = New System.Drawing.Point(53, 62)
        Me.var1.Margin = New System.Windows.Forms.Padding(4)
        Me.var1.Name = "var1"
        Me.var1.Size = New System.Drawing.Size(63, 24)
        Me.var1.TabIndex = 0
        Me.var1.Text = "TTR"
        Me.var1.UseVisualStyleBackColor = True
        '
        'Tab2
        '
        Me.Tab2.Controls.Add(Me.varpanel2)
        Me.Tab2.Location = New System.Drawing.Point(4, 25)
        Me.Tab2.Margin = New System.Windows.Forms.Padding(4)
        Me.Tab2.Name = "Tab2"
        Me.Tab2.Padding = New System.Windows.Forms.Padding(4)
        Me.Tab2.Size = New System.Drawing.Size(739, 398)
        Me.Tab2.TabIndex = 1
        Me.Tab2.Text = "Advanced Variables"
        Me.Tab2.UseVisualStyleBackColor = True
        '
        'varpanel2
        '
        Me.varpanel2.Controls.Add(Me.advselectnone)
        Me.varpanel2.Controls.Add(Me.advselectall)
        Me.varpanel2.Controls.Add(Me.advvar7)
        Me.varpanel2.Controls.Add(Me.advvar6)
        Me.varpanel2.Controls.Add(Me.advvar5)
        Me.varpanel2.Controls.Add(Me.advvar4)
        Me.varpanel2.Controls.Add(Me.advvar3)
        Me.varpanel2.Controls.Add(Me.advvar2)
        Me.varpanel2.Controls.Add(Me.advvar1)
        Me.varpanel2.Controls.Add(Me.TextBox1)
        Me.varpanel2.Location = New System.Drawing.Point(4, 2)
        Me.varpanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.varpanel2.Name = "varpanel2"
        Me.varpanel2.Size = New System.Drawing.Size(728, 389)
        Me.varpanel2.TabIndex = 2
        '
        'advselectnone
        '
        Me.advselectnone.Location = New System.Drawing.Point(569, 6)
        Me.advselectnone.Margin = New System.Windows.Forms.Padding(4)
        Me.advselectnone.Name = "advselectnone"
        Me.advselectnone.Size = New System.Drawing.Size(147, 28)
        Me.advselectnone.TabIndex = 36
        Me.advselectnone.Text = "Select None"
        Me.advselectnone.UseVisualStyleBackColor = True
        '
        'advselectall
        '
        Me.advselectall.Location = New System.Drawing.Point(413, 6)
        Me.advselectall.Margin = New System.Windows.Forms.Padding(4)
        Me.advselectall.Name = "advselectall"
        Me.advselectall.Size = New System.Drawing.Size(147, 28)
        Me.advselectall.TabIndex = 35
        Me.advselectall.Text = "Select All"
        Me.advselectall.UseVisualStyleBackColor = True
        '
        'advvar7
        '
        Me.advvar7.AutoSize = True
        Me.advvar7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.advvar7.Location = New System.Drawing.Point(243, 303)
        Me.advvar7.Margin = New System.Windows.Forms.Padding(4)
        Me.advvar7.Name = "advvar7"
        Me.advvar7.Size = New System.Drawing.Size(122, 24)
        Me.advvar7.TabIndex = 34
        Me.advvar7.Text = "Rel. Entropy"
        Me.advvar7.UseVisualStyleBackColor = True
        '
        'advvar6
        '
        Me.advvar6.AutoSize = True
        Me.advvar6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.advvar6.Location = New System.Drawing.Point(243, 266)
        Me.advvar6.Margin = New System.Windows.Forms.Padding(4)
        Me.advvar6.Name = "advvar6"
        Me.advvar6.Size = New System.Drawing.Size(88, 24)
        Me.advvar6.TabIndex = 33
        Me.advvar6.Text = "Entropy"
        Me.advvar6.UseVisualStyleBackColor = True
        '
        'advvar5
        '
        Me.advvar5.AutoSize = True
        Me.advvar5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.advvar5.Location = New System.Drawing.Point(243, 229)
        Me.advvar5.Margin = New System.Windows.Forms.Padding(4)
        Me.advvar5.Name = "advvar5"
        Me.advvar5.Size = New System.Drawing.Size(116, 24)
        Me.advvar5.TabIndex = 32
        Me.advvar5.Text = "Burrow's D"
        Me.advvar5.UseVisualStyleBackColor = True
        '
        'advvar4
        '
        Me.advvar4.AutoSize = True
        Me.advvar4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.advvar4.Location = New System.Drawing.Point(243, 192)
        Me.advvar4.Margin = New System.Windows.Forms.Padding(4)
        Me.advvar4.Name = "advvar4"
        Me.advvar4.Size = New System.Drawing.Size(165, 24)
        Me.advvar4.TabIndex = 31
        Me.advvar4.Text = "Malv & Richard's D"
        Me.advvar4.UseVisualStyleBackColor = True
        '
        'advvar3
        '
        Me.advvar3.AutoSize = True
        Me.advvar3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.advvar3.Location = New System.Drawing.Point(243, 155)
        Me.advvar3.Margin = New System.Windows.Forms.Padding(4)
        Me.advvar3.Name = "advvar3"
        Me.advvar3.Size = New System.Drawing.Size(85, 24)
        Me.advvar3.TabIndex = 30
        Me.advvar3.Text = "Zipf's Z"
        Me.advvar3.UseVisualStyleBackColor = True
        '
        'advvar2
        '
        Me.advvar2.AutoSize = True
        Me.advvar2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.advvar2.Location = New System.Drawing.Point(243, 118)
        Me.advvar2.Margin = New System.Windows.Forms.Padding(4)
        Me.advvar2.Name = "advvar2"
        Me.advvar2.Size = New System.Drawing.Size(118, 24)
        Me.advvar2.TabIndex = 29
        Me.advvar2.Text = "Simson's D"
        Me.advvar2.UseVisualStyleBackColor = True
        '
        'advvar1
        '
        Me.advvar1.AutoSize = True
        Me.advvar1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.advvar1.Location = New System.Drawing.Point(243, 81)
        Me.advvar1.Margin = New System.Windows.Forms.Padding(4)
        Me.advvar1.Name = "advvar1"
        Me.advvar1.Size = New System.Drawing.Size(92, 24)
        Me.advvar1.TabIndex = 28
        Me.advvar1.Text = "Yule's K"
        Me.advvar1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.AcceptsTab = True
        Me.TextBox1.AllowDrop = True
        Me.TextBox1.Location = New System.Drawing.Point(0, 1)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.MaximumSize = New System.Drawing.Size(532, 400)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(0, 22)
        Me.TextBox1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.leks)
        Me.TabPage1.Controls.Add(Me.sent)
        Me.TabPage1.Controls.Add(Me.sl)
        Me.TabPage1.Controls.Add(Me.defaultbutton)
        Me.TabPage1.Controls.Add(Me.stext)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Size = New System.Drawing.Size(739, 398)
        Me.TabPage1.TabIndex = 2
        Me.TabPage1.Text = "Options"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'leks
        '
        Me.leks.AutoSize = True
        Me.leks.Location = New System.Drawing.Point(527, 76)
        Me.leks.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.leks.Name = "leks"
        Me.leks.Size = New System.Drawing.Size(63, 17)
        Me.leks.TabIndex = 7
        Me.leks.Text = "lekseis ="
        '
        'sent
        '
        Me.sent.AutoSize = True
        Me.sent.Location = New System.Drawing.Point(527, 106)
        Me.sent.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.sent.Name = "sent"
        Me.sent.Size = New System.Drawing.Size(87, 17)
        Me.sent.TabIndex = 6
        Me.sent.Text = "Sentences ="
        '
        'sl
        '
        Me.sl.AutoSize = True
        Me.sl.Location = New System.Drawing.Point(527, 134)
        Me.sl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.sl.Name = "sl"
        Me.sl.Size = New System.Drawing.Size(33, 17)
        Me.sl.TabIndex = 5
        Me.sl.Text = "SL="
        '
        'defaultbutton
        '
        Me.defaultbutton.Location = New System.Drawing.Point(7, 345)
        Me.defaultbutton.Margin = New System.Windows.Forms.Padding(4)
        Me.defaultbutton.Name = "defaultbutton"
        Me.defaultbutton.Size = New System.Drawing.Size(100, 44)
        Me.defaultbutton.TabIndex = 4
        Me.defaultbutton.Text = "Default Settings"
        Me.defaultbutton.UseVisualStyleBackColor = True
        '
        'stext
        '
        Me.stext.BackColor = System.Drawing.SystemColors.Window
        Me.stext.ForeColor = System.Drawing.SystemColors.WindowText
        Me.stext.Location = New System.Drawing.Point(8, 7)
        Me.stext.Margin = New System.Windows.Forms.Padding(4)
        Me.stext.MinimumSize = New System.Drawing.Size(4, 368)
        Me.stext.Multiline = True
        Me.stext.Name = "stext"
        Me.stext.ReadOnly = True
        Me.stext.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.stext.Size = New System.Drawing.Size(484, 368)
        Me.stext.TabIndex = 3
        '
        'statuspanel
        '
        Me.statuspanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.statuspanel.Controls.Add(Me.labelswitches)
        Me.statuspanel.Controls.Add(Me.excellbl)
        Me.statuspanel.Controls.Add(Me.directorylbl)
        Me.statuspanel.Controls.Add(Me.statusdir)
        Me.statuspanel.Controls.Add(Me.statusfile)
        Me.statuspanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.statuspanel.Location = New System.Drawing.Point(0, 73)
        Me.statuspanel.Margin = New System.Windows.Forms.Padding(4)
        Me.statuspanel.Name = "statuspanel"
        Me.statuspanel.Size = New System.Drawing.Size(762, 62)
        Me.statuspanel.TabIndex = 34
        '
        'labelswitches
        '
        Me.labelswitches.Controls.Add(Me.tosave)
        Me.labelswitches.Controls.Add(Me.dtlbl)
        Me.labelswitches.Controls.Add(Me.freeslots)
        Me.labelswitches.Controls.Add(Me.free4)
        Me.labelswitches.Controls.Add(Me.free3)
        Me.labelswitches.Controls.Add(Me.free2)
        Me.labelswitches.Controls.Add(Me.free1)
        Me.labelswitches.Controls.Add(Me.sbcount)
        Me.labelswitches.Controls.Add(Me.stileslbl)
        Me.labelswitches.Controls.Add(Me.statusindex)
        Me.labelswitches.Dock = System.Windows.Forms.DockStyle.Right
        Me.labelswitches.Location = New System.Drawing.Point(583, 0)
        Me.labelswitches.Name = "labelswitches"
        Me.labelswitches.Size = New System.Drawing.Size(175, 58)
        Me.labelswitches.TabIndex = 47
        Me.labelswitches.Visible = False
        '
        'tosave
        '
        Me.tosave.AutoSize = True
        Me.tosave.Location = New System.Drawing.Point(154, 30)
        Me.tosave.Name = "tosave"
        Me.tosave.Size = New System.Drawing.Size(16, 17)
        Me.tosave.TabIndex = 47
        Me.tosave.Text = "0"
        '
        'dtlbl
        '
        Me.dtlbl.AutoSize = True
        Me.dtlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 5.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.dtlbl.Location = New System.Drawing.Point(104, 3)
        Me.dtlbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.dtlbl.Name = "dtlbl"
        Me.dtlbl.Size = New System.Drawing.Size(20, 12)
        Me.dtlbl.TabIndex = 1
        Me.dtlbl.Text = "sub"
        '
        'freeslots
        '
        Me.freeslots.AutoSize = True
        Me.freeslots.Location = New System.Drawing.Point(13, 13)
        Me.freeslots.Name = "freeslots"
        Me.freeslots.Size = New System.Drawing.Size(62, 17)
        Me.freeslots.TabIndex = 46
        Me.freeslots.Text = "freeslots"
        '
        'free4
        '
        Me.free4.AutoSize = True
        Me.free4.Location = New System.Drawing.Point(60, 30)
        Me.free4.Name = "free4"
        Me.free4.Size = New System.Drawing.Size(16, 17)
        Me.free4.TabIndex = 45
        Me.free4.Text = "0"
        '
        'free3
        '
        Me.free3.AutoSize = True
        Me.free3.Location = New System.Drawing.Point(43, 30)
        Me.free3.Name = "free3"
        Me.free3.Size = New System.Drawing.Size(16, 17)
        Me.free3.TabIndex = 44
        Me.free3.Text = "0"
        '
        'free2
        '
        Me.free2.AutoSize = True
        Me.free2.Location = New System.Drawing.Point(27, 30)
        Me.free2.Name = "free2"
        Me.free2.Size = New System.Drawing.Size(16, 17)
        Me.free2.TabIndex = 43
        Me.free2.Text = "0"
        '
        'free1
        '
        Me.free1.AutoSize = True
        Me.free1.Location = New System.Drawing.Point(13, 30)
        Me.free1.Name = "free1"
        Me.free1.Size = New System.Drawing.Size(16, 17)
        Me.free1.TabIndex = 42
        Me.free1.Text = "0"
        '
        'sbcount
        '
        Me.sbcount.AutoSize = True
        Me.sbcount.Location = New System.Drawing.Point(133, 30)
        Me.sbcount.Name = "sbcount"
        Me.sbcount.Size = New System.Drawing.Size(16, 17)
        Me.sbcount.TabIndex = 41
        Me.sbcount.Text = "0"
        '
        'stileslbl
        '
        Me.stileslbl.AutoSize = True
        Me.stileslbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 5.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.stileslbl.Location = New System.Drawing.Point(134, 2)
        Me.stileslbl.Name = "stileslbl"
        Me.stileslbl.Size = New System.Drawing.Size(27, 12)
        Me.stileslbl.TabIndex = 40
        Me.stileslbl.Text = "stiles"
        '
        'statusindex
        '
        Me.statusindex.AutoSize = True
        Me.statusindex.Font = New System.Drawing.Font("Microsoft Sans Serif", 5.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.statusindex.Location = New System.Drawing.Point(134, 18)
        Me.statusindex.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.statusindex.Name = "statusindex"
        Me.statusindex.Size = New System.Drawing.Size(27, 12)
        Me.statusindex.TabIndex = 34
        Me.statusindex.Text = "index"
        '
        'excellbl
        '
        Me.excellbl.AutoSize = True
        Me.excellbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.excellbl.Location = New System.Drawing.Point(19, 32)
        Me.excellbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.excellbl.Name = "excellbl"
        Me.excellbl.Size = New System.Drawing.Size(92, 20)
        Me.excellbl.TabIndex = 39
        Me.excellbl.Text = "Excel File :"
        '
        'directorylbl
        '
        Me.directorylbl.AutoSize = True
        Me.directorylbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.directorylbl.Location = New System.Drawing.Point(20, 7)
        Me.directorylbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.directorylbl.Name = "directorylbl"
        Me.directorylbl.Size = New System.Drawing.Size(88, 20)
        Me.directorylbl.TabIndex = 38
        Me.directorylbl.Text = "Directory :"
        '
        'statusdir
        '
        Me.statusdir.AutoSize = True
        Me.statusdir.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.statusdir.Location = New System.Drawing.Point(141, 7)
        Me.statusdir.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.statusdir.Name = "statusdir"
        Me.statusdir.Size = New System.Drawing.Size(105, 20)
        Me.statusdir.TabIndex = 37
        Me.statusdir.Text = "Not Selected"
        '
        'statusfile
        '
        Me.statusfile.AutoSize = True
        Me.statusfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.statusfile.Location = New System.Drawing.Point(141, 32)
        Me.statusfile.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.statusfile.Name = "statusfile"
        Me.statusfile.Size = New System.Drawing.Size(105, 20)
        Me.statusfile.TabIndex = 36
        Me.statusfile.Text = "Not Selected"
        '
        'percentage
        '
        Me.percentage.AutoSize = True
        Me.percentage.BackColor = System.Drawing.Color.Transparent
        Me.percentage.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.percentage.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.percentage.ForeColor = System.Drawing.Color.Maroon
        Me.percentage.Location = New System.Drawing.Point(75, 107)
        Me.percentage.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.percentage.Name = "percentage"
        Me.percentage.Size = New System.Drawing.Size(39, 28)
        Me.percentage.TabIndex = 41
        Me.percentage.Text = "0%"
        Me.percentage.Visible = False
        '
        'ProgressBar
        '
        Me.ProgressBar.Location = New System.Drawing.Point(131, 98)
        Me.ProgressBar.Margin = New System.Windows.Forms.Padding(4)
        Me.ProgressBar.Name = "ProgressBar"
        Me.ProgressBar.Size = New System.Drawing.Size(484, 44)
        Me.ProgressBar.TabIndex = 40
        Me.ProgressBar.Visible = False
        '
        'hidden
        '
        Me.hidden.Controls.Add(Me.job)
        Me.hidden.Controls.Add(Me.percentage)
        Me.hidden.Controls.Add(Me.ProgressBar)
        Me.hidden.Location = New System.Drawing.Point(0, 214)
        Me.hidden.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.hidden.Name = "hidden"
        Me.hidden.Size = New System.Drawing.Size(755, 246)
        Me.hidden.TabIndex = 35
        '
        'job
        '
        Me.job.AutoSize = True
        Me.job.Location = New System.Drawing.Point(128, 156)
        Me.job.Name = "job"
        Me.job.Size = New System.Drawing.Size(63, 17)
        Me.job.TabIndex = 42
        Me.job.Text = "job done"
        Me.job.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.savebarpanel)
        Me.Panel1.Controls.Add(Me.cancelbtn)
        Me.Panel1.Controls.Add(Me.Corpus)
        Me.Panel1.Location = New System.Drawing.Point(0, 11)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(761, 50)
        Me.Panel1.TabIndex = 36
        '
        'savebarpanel
        '
        Me.savebarpanel.Controls.Add(Me.saving)
        Me.savebarpanel.Controls.Add(Me.prb)
        Me.savebarpanel.Dock = System.Windows.Forms.DockStyle.Right
        Me.savebarpanel.Location = New System.Drawing.Point(558, 0)
        Me.savebarpanel.Name = "savebarpanel"
        Me.savebarpanel.Size = New System.Drawing.Size(199, 46)
        Me.savebarpanel.TabIndex = 5
        Me.savebarpanel.Visible = False
        '
        'saving
        '
        Me.saving.AutoSize = True
        Me.saving.Location = New System.Drawing.Point(46, 4)
        Me.saving.Name = "saving"
        Me.saving.Size = New System.Drawing.Size(63, 17)
        Me.saving.TabIndex = 5
        Me.saving.Text = "Saving..."
        '
        'prb
        '
        Me.prb.Location = New System.Drawing.Point(42, 25)
        Me.prb.Name = "prb"
        Me.prb.Size = New System.Drawing.Size(145, 15)
        Me.prb.TabIndex = 4
        '
        'cancelbtn
        '
        Me.cancelbtn.Location = New System.Drawing.Point(23, 14)
        Me.cancelbtn.Margin = New System.Windows.Forms.Padding(4)
        Me.cancelbtn.Name = "cancelbtn"
        Me.cancelbtn.Size = New System.Drawing.Size(82, 28)
        Me.cancelbtn.TabIndex = 2
        Me.cancelbtn.Text = "Cancel"
        Me.cancelbtn.UseVisualStyleBackColor = True
        Me.cancelbtn.Visible = False
        '
        'Corpus
        '
        Me.Corpus.AutoSize = True
        Me.Corpus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Corpus.Location = New System.Drawing.Point(112, 16)
        Me.Corpus.Name = "Corpus"
        Me.Corpus.Size = New System.Drawing.Size(63, 20)
        Me.Corpus.TabIndex = 0
        Me.Corpus.Text = "Corpus"
        Me.Corpus.Visible = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel1)
        Me.Panel3.Controls.Add(Me.statuspanel)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 457)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(762, 135)
        Me.Panel3.TabIndex = 37
        '
        'program
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(762, 592)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.menupanel)
        Me.Controls.Add(Me.Tabs)
        Me.Controls.Add(Me.hidden)
        Me.MainMenuStrip = Me.Menu1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "program"
        Me.Text = "Text Analysis"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.menupanel.ResumeLayout(False)
        Me.menupanel.PerformLayout()
        Me.Menu1.ResumeLayout(False)
        Me.Menu1.PerformLayout()
        Me.Tabs.ResumeLayout(False)
        Me.tab1.ResumeLayout(False)
        Me.varpanel.ResumeLayout(False)
        Me.varpanel.PerformLayout()
        Me.Paneln.ResumeLayout(False)
        Me.Paneln.PerformLayout()
        Me.Tab2.ResumeLayout(False)
        Me.varpanel2.ResumeLayout(False)
        Me.varpanel2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.statuspanel.ResumeLayout(False)
        Me.statuspanel.PerformLayout()
        Me.labelswitches.ResumeLayout(False)
        Me.labelswitches.PerformLayout()
        Me.hidden.ResumeLayout(False)
        Me.hidden.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.savebarpanel.ResumeLayout(False)
        Me.savebarpanel.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents statusframe As System.Windows.Forms.Panel
    Friend WithEvents menupanel As System.Windows.Forms.Panel
    Friend WithEvents Menu1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Filemenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OverviewMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Saveasmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Closemenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Quittmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents virtualcorpusmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Newmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Activatemenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents overviewmenu1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Deletemenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Variablesmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Executemenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Languagemenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Englishmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Greekmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Italianmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Helpmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Aboutmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndexOfHelpmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents statusbar As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents openexcelmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Validatefilemenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tabs As System.Windows.Forms.TabControl
    Friend WithEvents tab1 As System.Windows.Forms.TabPage
    Friend WithEvents varpanel As System.Windows.Forms.Panel
    Friend WithEvents okbutton As System.Windows.Forms.Button
    Friend WithEvents selectnonebutton As System.Windows.Forms.Button
    Friend WithEvents selectallbutton As System.Windows.Forms.Button
    Friend WithEvents var17 As System.Windows.Forms.CheckBox
    Friend WithEvents var16 As System.Windows.Forms.CheckBox
    Friend WithEvents var15 As System.Windows.Forms.CheckBox
    Friend WithEvents var14 As System.Windows.Forms.CheckBox
    Friend WithEvents var13 As System.Windows.Forms.CheckBox
    Friend WithEvents var12 As System.Windows.Forms.CheckBox
    Friend WithEvents var11 As System.Windows.Forms.CheckBox
    Friend WithEvents var10 As System.Windows.Forms.CheckBox
    Friend WithEvents var9 As System.Windows.Forms.CheckBox
    Friend WithEvents var8 As System.Windows.Forms.CheckBox
    Friend WithEvents var7 As System.Windows.Forms.CheckBox
    Friend WithEvents var6 As System.Windows.Forms.CheckBox
    Friend WithEvents var5 As System.Windows.Forms.CheckBox
    Friend WithEvents var4 As System.Windows.Forms.CheckBox
    Friend WithEvents var3 As System.Windows.Forms.CheckBox
    Friend WithEvents var2 As System.Windows.Forms.CheckBox
    Friend WithEvents var1 As System.Windows.Forms.CheckBox
    Friend WithEvents Tab2 As System.Windows.Forms.TabPage
    Friend WithEvents Excelmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents stext As System.Windows.Forms.TextBox
    Friend WithEvents opendir As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents statuspanel As System.Windows.Forms.Panel
    Friend WithEvents statusdir As System.Windows.Forms.Label
    Friend WithEvents statusfile As System.Windows.Forms.Label
    Friend WithEvents statusindex As System.Windows.Forms.Label
    Friend WithEvents excellbl As System.Windows.Forms.Label
    Friend WithEvents directorylbl As System.Windows.Forms.Label
    Friend WithEvents ProgressBar As System.Windows.Forms.ProgressBar
    Friend WithEvents defaultbutton As System.Windows.Forms.Button
    Friend WithEvents varpanel2 As System.Windows.Forms.Panel
    Friend WithEvents advselectnone As System.Windows.Forms.Button
    Friend WithEvents advselectall As System.Windows.Forms.Button
    Friend WithEvents advvar7 As System.Windows.Forms.CheckBox
    Friend WithEvents advvar6 As System.Windows.Forms.CheckBox
    Friend WithEvents advvar5 As System.Windows.Forms.CheckBox
    Friend WithEvents advvar4 As System.Windows.Forms.CheckBox
    Friend WithEvents advvar3 As System.Windows.Forms.CheckBox
    Friend WithEvents advvar2 As System.Windows.Forms.CheckBox
    Friend WithEvents advvar1 As System.Windows.Forms.CheckBox
    Friend WithEvents percentage As System.Windows.Forms.Label
    Friend WithEvents actSub1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents actSub2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents actSub3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents actSub4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents oversub1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents oversub2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents oversub3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents oversub4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents delsub1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents delsub2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents delsub3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents delsub4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents hidden As System.Windows.Forms.Panel
    Friend WithEvents job As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Corpus As System.Windows.Forms.Label
    Friend WithEvents sl As System.Windows.Forms.Label
    Friend WithEvents sent As System.Windows.Forms.Label
    Friend WithEvents leks As System.Windows.Forms.Label
    Friend WithEvents dtlbl As System.Windows.Forms.Label
    Friend WithEvents cancelbtn As System.Windows.Forms.Button
    Friend WithEvents uwbtn As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents w1btn As System.Windows.Forms.Button
    Friend WithEvents Paneln As System.Windows.Forms.Panel
    Friend WithEvents okbtnn As System.Windows.Forms.Button
    Friend WithEvents textn As System.Windows.Forms.TextBox
    Friend WithEvents stileslbl As System.Windows.Forms.Label
    Friend WithEvents sbcount As System.Windows.Forms.Label
    Friend WithEvents free4 As System.Windows.Forms.Label
    Friend WithEvents free3 As System.Windows.Forms.Label
    Friend WithEvents free2 As System.Windows.Forms.Label
    Friend WithEvents free1 As System.Windows.Forms.Label
    Friend WithEvents labelswitches As System.Windows.Forms.Panel
    Friend WithEvents tosave As System.Windows.Forms.Label
    Friend WithEvents freeslots As System.Windows.Forms.Label
    Friend WithEvents prb As System.Windows.Forms.ProgressBar
    Friend WithEvents savebarpanel As System.Windows.Forms.Panel
    Friend WithEvents saving As System.Windows.Forms.Label

End Class
