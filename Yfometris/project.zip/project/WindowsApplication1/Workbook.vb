﻿
Namespace Excel
    Class Workbook

        Private _worksheets As Worksheet

        Property Worksheets(ByVal p1 As String) As Worksheet
            Get
                Return _worksheets
            End Get
            Set(ByVal value As Worksheet)
                _worksheets = value
            End Set
        End Property

    End Class
End Namespace
