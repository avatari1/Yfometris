﻿
Namespace Excel
    Class ApplicationClass

    End Class
End Namespace
