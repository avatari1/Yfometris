﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(form3))
        Me.header = New System.Windows.Forms.Label()
        Me.Combo1 = New System.Windows.Forms.ComboBox()
        Me.Combo1value = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Combo3 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Combo2value = New System.Windows.Forms.ComboBox()
        Me.Combo2 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Combo4 = New System.Windows.Forms.ComboBox()
        Me.subnamelbl = New System.Windows.Forms.Label()
        Me.subname = New System.Windows.Forms.TextBox()
        Me.acceptbtn = New System.Windows.Forms.Button()
        Me.reset1 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.GB1 = New System.Windows.Forms.GroupBox()
        Me.opercombo = New System.Windows.Forms.ComboBox()
        Me.textcount = New System.Windows.Forms.TextBox()
        Me.wordcount = New System.Windows.Forms.TextBox()
        Me.Checktc = New System.Windows.Forms.CheckBox()
        Me.Checkwc = New System.Windows.Forms.CheckBox()
        Me.settc = New System.Windows.Forms.Button()
        Me.setwc = New System.Windows.Forms.Button()
        Me.icollbl = New System.Windows.Forms.Label()
        Me.irowlbl = New System.Windows.Forms.Label()
        Me.textcountlbl = New System.Windows.Forms.Label()
        Me.wordcountlbl = New System.Windows.Forms.Label()
        Me.Combo3value = New System.Windows.Forms.ComboBox()
        Me.Combo4value = New System.Windows.Forms.ComboBox()
        Me.createtbn = New System.Windows.Forms.Button()
        Me.Created1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.GB1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'header
        '
        Me.header.AutoSize = True
        Me.header.BackColor = System.Drawing.SystemColors.Control
        Me.header.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.header.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.header.ForeColor = System.Drawing.Color.Maroon
        Me.header.Location = New System.Drawing.Point(136, 5)
        Me.header.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.header.Name = "header"
        Me.header.Size = New System.Drawing.Size(194, 20)
        Me.header.TabIndex = 0
        Me.header.Text = "Meta Linguistic Features"
        '
        'Combo1
        '
        Me.Combo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo1.FormattingEnabled = True
        Me.Combo1.Location = New System.Drawing.Point(13, 11)
        Me.Combo1.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo1.Name = "Combo1"
        Me.Combo1.Size = New System.Drawing.Size(160, 24)
        Me.Combo1.TabIndex = 1
        '
        'Combo1value
        '
        Me.Combo1value.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo1value.FormattingEnabled = True
        Me.Combo1value.Location = New System.Drawing.Point(289, 11)
        Me.Combo1value.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo1value.Name = "Combo1value"
        Me.Combo1value.Size = New System.Drawing.Size(160, 24)
        Me.Combo1value.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label2.Location = New System.Drawing.Point(221, 11)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label3.Location = New System.Drawing.Point(221, 109)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 25)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "="
        '
        'Combo3
        '
        Me.Combo3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo3.FormattingEnabled = True
        Me.Combo3.Location = New System.Drawing.Point(13, 109)
        Me.Combo3.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo3.Name = "Combo3"
        Me.Combo3.Size = New System.Drawing.Size(160, 24)
        Me.Combo3.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label4.Location = New System.Drawing.Point(221, 60)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 25)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "="
        '
        'Combo2value
        '
        Me.Combo2value.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo2value.FormattingEnabled = True
        Me.Combo2value.Location = New System.Drawing.Point(289, 60)
        Me.Combo2value.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo2value.Name = "Combo2value"
        Me.Combo2value.Size = New System.Drawing.Size(160, 24)
        Me.Combo2value.TabIndex = 8
        '
        'Combo2
        '
        Me.Combo2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo2.FormattingEnabled = True
        Me.Combo2.Location = New System.Drawing.Point(13, 60)
        Me.Combo2.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo2.Name = "Combo2"
        Me.Combo2.Size = New System.Drawing.Size(160, 24)
        Me.Combo2.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label5.Location = New System.Drawing.Point(223, 158)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(24, 25)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "="
        '
        'Combo4
        '
        Me.Combo4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo4.FormattingEnabled = True
        Me.Combo4.Location = New System.Drawing.Point(15, 158)
        Me.Combo4.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo4.Name = "Combo4"
        Me.Combo4.Size = New System.Drawing.Size(160, 24)
        Me.Combo4.TabIndex = 10
        '
        'subnamelbl
        '
        Me.subnamelbl.AutoSize = True
        Me.subnamelbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.subnamelbl.Location = New System.Drawing.Point(31, 471)
        Me.subnamelbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.subnamelbl.Name = "subnamelbl"
        Me.subnamelbl.Size = New System.Drawing.Size(146, 20)
        Me.subnamelbl.TabIndex = 17
        Me.subnamelbl.Text = "Sub Corpus Name"
        '
        'subname
        '
        Me.subname.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.subname.Location = New System.Drawing.Point(236, 471)
        Me.subname.Margin = New System.Windows.Forms.Padding(4)
        Me.subname.Name = "subname"
        Me.subname.Size = New System.Drawing.Size(196, 26)
        Me.subname.TabIndex = 18
        '
        'acceptbtn
        '
        Me.acceptbtn.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.acceptbtn.FlatAppearance.BorderSize = 2
        Me.acceptbtn.Location = New System.Drawing.Point(395, 534)
        Me.acceptbtn.Margin = New System.Windows.Forms.Padding(4)
        Me.acceptbtn.Name = "acceptbtn"
        Me.acceptbtn.Size = New System.Drawing.Size(100, 28)
        Me.acceptbtn.TabIndex = 19
        Me.acceptbtn.Text = "Close"
        Me.acceptbtn.UseVisualStyleBackColor = True
        '
        'reset1
        '
        Me.reset1.BackColor = System.Drawing.Color.White
        Me.reset1.BackgroundImage = CType(resources.GetObject("reset1.BackgroundImage"), System.Drawing.Image)
        Me.reset1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.reset1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.reset1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Percent90
        Me.reset1.Location = New System.Drawing.Point(21, 20)
        Me.reset1.Name = "reset1"
        Me.reset1.Size = New System.Drawing.Size(30, 30)
        '
        'GB1
        '
        Me.GB1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GB1.Controls.Add(Me.opercombo)
        Me.GB1.Controls.Add(Me.textcount)
        Me.GB1.Controls.Add(Me.wordcount)
        Me.GB1.Controls.Add(Me.Checktc)
        Me.GB1.Controls.Add(Me.Checkwc)
        Me.GB1.Controls.Add(Me.settc)
        Me.GB1.Controls.Add(Me.setwc)
        Me.GB1.Controls.Add(Me.icollbl)
        Me.GB1.Controls.Add(Me.irowlbl)
        Me.GB1.Controls.Add(Me.textcountlbl)
        Me.GB1.Controls.Add(Me.wordcountlbl)
        Me.GB1.ForeColor = System.Drawing.Color.Maroon
        Me.GB1.Location = New System.Drawing.Point(32, 316)
        Me.GB1.Margin = New System.Windows.Forms.Padding(4)
        Me.GB1.Name = "GB1"
        Me.GB1.Padding = New System.Windows.Forms.Padding(4)
        Me.GB1.Size = New System.Drawing.Size(513, 139)
        Me.GB1.TabIndex = 24
        Me.GB1.TabStop = False
        Me.GB1.Text = "Quantitative Selection"
        '
        'opercombo
        '
        Me.opercombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.opercombo.Enabled = False
        Me.opercombo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.opercombo.FormattingEnabled = True
        Me.opercombo.Items.AddRange(New Object() {">=", "<=", "="})
        Me.opercombo.Location = New System.Drawing.Point(240, 41)
        Me.opercombo.Margin = New System.Windows.Forms.Padding(4)
        Me.opercombo.Name = "opercombo"
        Me.opercombo.Size = New System.Drawing.Size(52, 28)
        Me.opercombo.TabIndex = 35
        '
        'textcount
        '
        Me.textcount.Enabled = False
        Me.textcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.textcount.Location = New System.Drawing.Point(301, 86)
        Me.textcount.Margin = New System.Windows.Forms.Padding(4)
        Me.textcount.Name = "textcount"
        Me.textcount.Size = New System.Drawing.Size(55, 26)
        Me.textcount.TabIndex = 34
        '
        'wordcount
        '
        Me.wordcount.Enabled = False
        Me.wordcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.wordcount.Location = New System.Drawing.Point(301, 42)
        Me.wordcount.Margin = New System.Windows.Forms.Padding(4)
        Me.wordcount.Name = "wordcount"
        Me.wordcount.Size = New System.Drawing.Size(55, 26)
        Me.wordcount.TabIndex = 33
        '
        'Checktc
        '
        Me.Checktc.AutoSize = True
        Me.Checktc.Location = New System.Drawing.Point(21, 97)
        Me.Checktc.Margin = New System.Windows.Forms.Padding(4)
        Me.Checktc.Name = "Checktc"
        Me.Checktc.Size = New System.Drawing.Size(18, 17)
        Me.Checktc.TabIndex = 32
        Me.Checktc.UseVisualStyleBackColor = True
        '
        'Checkwc
        '
        Me.Checkwc.AutoSize = True
        Me.Checkwc.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Checkwc.Location = New System.Drawing.Point(21, 48)
        Me.Checkwc.Margin = New System.Windows.Forms.Padding(4)
        Me.Checkwc.Name = "Checkwc"
        Me.Checkwc.Size = New System.Drawing.Size(18, 17)
        Me.Checkwc.TabIndex = 31
        Me.Checkwc.UseVisualStyleBackColor = True
        '
        'settc
        '
        Me.settc.Location = New System.Drawing.Point(364, 87)
        Me.settc.Margin = New System.Windows.Forms.Padding(4)
        Me.settc.Name = "settc"
        Me.settc.Size = New System.Drawing.Size(44, 28)
        Me.settc.TabIndex = 30
        Me.settc.Text = "Set"
        Me.settc.UseVisualStyleBackColor = True
        Me.settc.Visible = False
        '
        'setwc
        '
        Me.setwc.Location = New System.Drawing.Point(364, 42)
        Me.setwc.Margin = New System.Windows.Forms.Padding(4)
        Me.setwc.Name = "setwc"
        Me.setwc.Size = New System.Drawing.Size(45, 28)
        Me.setwc.TabIndex = 29
        Me.setwc.Text = "Set"
        Me.setwc.UseVisualStyleBackColor = True
        Me.setwc.Visible = False
        '
        'icollbl
        '
        Me.icollbl.AutoSize = True
        Me.icollbl.Enabled = False
        Me.icollbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.icollbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.icollbl.Location = New System.Drawing.Point(435, 90)
        Me.icollbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.icollbl.Name = "icollbl"
        Me.icollbl.Size = New System.Drawing.Size(68, 17)
        Me.icollbl.TabIndex = 28
        Me.icollbl.Text = "columns :"
        Me.icollbl.Visible = False
        '
        'irowlbl
        '
        Me.irowlbl.AutoSize = True
        Me.irowlbl.Enabled = False
        Me.irowlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.irowlbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.irowlbl.Location = New System.Drawing.Point(436, 48)
        Me.irowlbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.irowlbl.Name = "irowlbl"
        Me.irowlbl.Size = New System.Drawing.Size(45, 17)
        Me.irowlbl.TabIndex = 27
        Me.irowlbl.Text = "rows :"
        Me.irowlbl.Visible = False
        '
        'textcountlbl
        '
        Me.textcountlbl.AutoSize = True
        Me.textcountlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.textcountlbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.textcountlbl.Location = New System.Drawing.Point(52, 95)
        Me.textcountlbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.textcountlbl.Name = "textcountlbl"
        Me.textcountlbl.Size = New System.Drawing.Size(122, 20)
        Me.textcountlbl.TabIndex = 25
        Me.textcountlbl.Text = "Text File Count"
        '
        'wordcountlbl
        '
        Me.wordcountlbl.AutoSize = True
        Me.wordcountlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.wordcountlbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.wordcountlbl.Location = New System.Drawing.Point(57, 46)
        Me.wordcountlbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.wordcountlbl.Name = "wordcountlbl"
        Me.wordcountlbl.Size = New System.Drawing.Size(124, 20)
        Me.wordcountlbl.TabIndex = 23
        Me.wordcountlbl.Text = "Words per Text"
        '
        'Combo3value
        '
        Me.Combo3value.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo3value.FormattingEnabled = True
        Me.Combo3value.Location = New System.Drawing.Point(289, 109)
        Me.Combo3value.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo3value.Name = "Combo3value"
        Me.Combo3value.Size = New System.Drawing.Size(160, 24)
        Me.Combo3value.TabIndex = 5
        '
        'Combo4value
        '
        Me.Combo4value.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo4value.FormattingEnabled = True
        Me.Combo4value.Location = New System.Drawing.Point(291, 158)
        Me.Combo4value.Margin = New System.Windows.Forms.Padding(4)
        Me.Combo4value.Name = "Combo4value"
        Me.Combo4value.Size = New System.Drawing.Size(160, 24)
        Me.Combo4value.TabIndex = 11
        '
        'createtbn
        '
        Me.createtbn.Location = New System.Drawing.Point(444, 471)
        Me.createtbn.Margin = New System.Windows.Forms.Padding(4)
        Me.createtbn.Name = "createtbn"
        Me.createtbn.Size = New System.Drawing.Size(101, 27)
        Me.createtbn.TabIndex = 25
        Me.createtbn.Text = "Create"
        Me.createtbn.UseVisualStyleBackColor = True
        '
        'Created1
        '
        Me.Created1.AutoSize = True
        Me.Created1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Created1.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Created1.Location = New System.Drawing.Point(120, 532)
        Me.Created1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Created1.Name = "Created1"
        Me.Created1.Size = New System.Drawing.Size(191, 20)
        Me.Created1.TabIndex = 27
        Me.Created1.Text = "Subcorpus created !!!"
        Me.Created1.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.header)
        Me.Panel1.Location = New System.Drawing.Point(12, 43)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(456, 38)
        Me.Panel1.TabIndex = 28
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.ShapeContainer2)
        Me.Panel2.Location = New System.Drawing.Point(471, 26)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(103, 69)
        Me.Panel2.TabIndex = 29
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.reset1})
        Me.ShapeContainer2.Size = New System.Drawing.Size(103, 69)
        Me.ShapeContainer2.TabIndex = 0
        Me.ShapeContainer2.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Combo4value)
        Me.Panel3.Controls.Add(Me.Combo4)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Combo2value)
        Me.Panel3.Controls.Add(Me.Combo2)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Combo3value)
        Me.Panel3.Controls.Add(Me.Combo3)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Combo1value)
        Me.Panel3.Controls.Add(Me.Combo1)
        Me.Panel3.Location = New System.Drawing.Point(22, 100)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(506, 200)
        Me.Panel3.TabIndex = 30
        '
        'form3
        '
        Me.AcceptButton = Me.acceptbtn
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(577, 569)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Created1)
        Me.Controls.Add(Me.createtbn)
        Me.Controls.Add(Me.GB1)
        Me.Controls.Add(Me.acceptbtn)
        Me.Controls.Add(Me.subname)
        Me.Controls.Add(Me.subnamelbl)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "form3"
        Me.Text = "New Sub corpus"
        Me.GB1.ResumeLayout(False)
        Me.GB1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents header As System.Windows.Forms.Label
    Friend WithEvents Combo1 As System.Windows.Forms.ComboBox
    Friend WithEvents Combo1value As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Combo3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Combo2value As System.Windows.Forms.ComboBox
    Friend WithEvents Combo2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Combo4 As System.Windows.Forms.ComboBox
    Friend WithEvents subnamelbl As System.Windows.Forms.Label
    Friend WithEvents subname As System.Windows.Forms.TextBox
    Friend WithEvents acceptbtn As System.Windows.Forms.Button
    Friend WithEvents reset1 As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents GB1 As System.Windows.Forms.GroupBox
    Friend WithEvents icollbl As System.Windows.Forms.Label
    Friend WithEvents irowlbl As System.Windows.Forms.Label
    Friend WithEvents textcountlbl As System.Windows.Forms.Label
    Friend WithEvents Combo3value As System.Windows.Forms.ComboBox
    Friend WithEvents Combo4value As System.Windows.Forms.ComboBox
    Friend WithEvents Checktc As System.Windows.Forms.CheckBox
    Friend WithEvents Checkwc As System.Windows.Forms.CheckBox
    Friend WithEvents settc As System.Windows.Forms.Button
    Friend WithEvents setwc As System.Windows.Forms.Button
    Friend WithEvents wordcountlbl As System.Windows.Forms.Label
    Friend WithEvents textcount As System.Windows.Forms.TextBox
    Friend WithEvents wordcount As System.Windows.Forms.TextBox
    Friend WithEvents createtbn As System.Windows.Forms.Button
    Friend WithEvents opercombo As System.Windows.Forms.ComboBox
    Friend WithEvents Created1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ShapeContainer2 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
End Class
