﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class columnselectionfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.combo = New System.Windows.Forms.ComboBox()
        Me.accept2 = New System.Windows.Forms.Button()
        Me.cancel2 = New System.Windows.Forms.Button()
        Me.prompt = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.acceptcancel = New System.Windows.Forms.Label()
        Me.icollbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'combo
        '
        Me.combo.FormattingEnabled = True
        Me.combo.Location = New System.Drawing.Point(95, 76)
        Me.combo.Margin = New System.Windows.Forms.Padding(4)
        Me.combo.Name = "combo"
        Me.combo.Size = New System.Drawing.Size(160, 24)
        Me.combo.TabIndex = 0
        '
        'accept2
        '
        Me.accept2.Location = New System.Drawing.Point(80, 159)
        Me.accept2.Margin = New System.Windows.Forms.Padding(4)
        Me.accept2.Name = "accept2"
        Me.accept2.Size = New System.Drawing.Size(96, 30)
        Me.accept2.TabIndex = 4
        Me.accept2.Text = "Accept"
        Me.accept2.UseVisualStyleBackColor = True
        '
        'cancel2
        '
        Me.cancel2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cancel2.Location = New System.Drawing.Point(184, 159)
        Me.cancel2.Margin = New System.Windows.Forms.Padding(4)
        Me.cancel2.Name = "cancel2"
        Me.cancel2.Size = New System.Drawing.Size(96, 30)
        Me.cancel2.TabIndex = 5
        Me.cancel2.Text = "Cancel"
        Me.cancel2.UseVisualStyleBackColor = True
        '
        'prompt
        '
        Me.prompt.AutoSize = True
        Me.prompt.Location = New System.Drawing.Point(16, 25)
        Me.prompt.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.prompt.Name = "prompt"
        Me.prompt.Size = New System.Drawing.Size(347, 17)
        Me.prompt.TabIndex = 6
        Me.prompt.Text = "Please select the column where the txt files are stored"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 202)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 17)
        Me.Label1.TabIndex = 7
        '
        'acceptcancel
        '
        Me.acceptcancel.AutoSize = True
        Me.acceptcancel.Location = New System.Drawing.Point(16, 197)
        Me.acceptcancel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.acceptcancel.Name = "acceptcancel"
        Me.acceptcancel.Size = New System.Drawing.Size(95, 17)
        Me.acceptcancel.TabIndex = 8
        Me.acceptcancel.Text = "accept/cancel"
        Me.acceptcancel.Visible = False
        '
        'icollbl
        '
        Me.icollbl.AutoSize = True
        Me.icollbl.Location = New System.Drawing.Point(277, 202)
        Me.icollbl.Name = "icollbl"
        Me.icollbl.Size = New System.Drawing.Size(29, 17)
        Me.icollbl.TabIndex = 9
        Me.icollbl.Text = "icol"
        '
        'columnselectionfrm
        '
        Me.AcceptButton = Me.accept2
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.cancel2
        Me.ClientSize = New System.Drawing.Size(379, 218)
        Me.Controls.Add(Me.icollbl)
        Me.Controls.Add(Me.acceptcancel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.prompt)
        Me.Controls.Add(Me.cancel2)
        Me.Controls.Add(Me.accept2)
        Me.Controls.Add(Me.combo)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "columnselectionfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Text Column selection"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents combo As System.Windows.Forms.ComboBox
    Friend WithEvents accept2 As System.Windows.Forms.Button
    Friend WithEvents cancel2 As System.Windows.Forms.Button
    Friend WithEvents prompt As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents acceptcancel As System.Windows.Forms.Label
    Friend WithEvents icollbl As System.Windows.Forms.Label
End Class
