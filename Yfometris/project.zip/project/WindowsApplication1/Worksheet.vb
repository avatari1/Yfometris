﻿
Namespace Excel
    Class Worksheet

        Private _cells As Object

        Property Cells(ByVal p1 As Integer, ByVal p2 As Integer) As Object
            Get
                Return _cells
            End Get
            Set(ByVal value As Object)
                _cells = value
            End Set
        End Property

    End Class
End Namespace
