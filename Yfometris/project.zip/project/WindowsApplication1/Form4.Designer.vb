﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.closebtn = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.buttonpanel = New System.Windows.Forms.Panel()
        Me.closebtnpanel = New System.Windows.Forms.Panel()
        Me.excelbtnpanel = New System.Windows.Forms.Panel()
        Me.prb = New System.Windows.Forms.ProgressBar()
        Me.excelbtn = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.buttonpanel.SuspendLayout()
        Me.closebtnpanel.SuspendLayout()
        Me.excelbtnpanel.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'closebtn
        '
        Me.closebtn.Dock = System.Windows.Forms.DockStyle.Fill
        Me.closebtn.Location = New System.Drawing.Point(0, 0)
        Me.closebtn.Name = "closebtn"
        Me.closebtn.Size = New System.Drawing.Size(509, 29)
        Me.closebtn.TabIndex = 1
        Me.closebtn.Text = "close"
        Me.closebtn.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(762, 417)
        Me.DataGridView1.TabIndex = 2
        '
        'buttonpanel
        '
        Me.buttonpanel.Controls.Add(Me.closebtnpanel)
        Me.buttonpanel.Controls.Add(Me.excelbtnpanel)
        Me.buttonpanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.buttonpanel.Location = New System.Drawing.Point(0, 417)
        Me.buttonpanel.Name = "buttonpanel"
        Me.buttonpanel.Size = New System.Drawing.Size(762, 29)
        Me.buttonpanel.TabIndex = 3
        '
        'closebtnpanel
        '
        Me.closebtnpanel.Controls.Add(Me.closebtn)
        Me.closebtnpanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.closebtnpanel.Location = New System.Drawing.Point(0, 0)
        Me.closebtnpanel.Name = "closebtnpanel"
        Me.closebtnpanel.Size = New System.Drawing.Size(509, 29)
        Me.closebtnpanel.TabIndex = 5
        '
        'excelbtnpanel
        '
        Me.excelbtnpanel.Controls.Add(Me.prb)
        Me.excelbtnpanel.Controls.Add(Me.excelbtn)
        Me.excelbtnpanel.Dock = System.Windows.Forms.DockStyle.Right
        Me.excelbtnpanel.Location = New System.Drawing.Point(509, 0)
        Me.excelbtnpanel.Name = "excelbtnpanel"
        Me.excelbtnpanel.Size = New System.Drawing.Size(253, 29)
        Me.excelbtnpanel.TabIndex = 4
        '
        'prb
        '
        Me.prb.Dock = System.Windows.Forms.DockStyle.Right
        Me.prb.Location = New System.Drawing.Point(59, 0)
        Me.prb.Name = "prb"
        Me.prb.Size = New System.Drawing.Size(194, 29)
        Me.prb.TabIndex = 3
        Me.prb.Visible = False
        '
        'excelbtn
        '
        Me.excelbtn.Dock = System.Windows.Forms.DockStyle.Fill
        Me.excelbtn.Image = CType(resources.GetObject("excelbtn.Image"), System.Drawing.Image)
        Me.excelbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.excelbtn.Location = New System.Drawing.Point(0, 0)
        Me.excelbtn.Name = "excelbtn"
        Me.excelbtn.Size = New System.Drawing.Size(253, 29)
        Me.excelbtn.TabIndex = 2
        Me.excelbtn.Text = "Save to excel"
        Me.excelbtn.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(762, 417)
        Me.Panel1.TabIndex = 4
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(762, 446)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.buttonpanel)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form4"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Corpus Overview"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.buttonpanel.ResumeLayout(False)
        Me.closebtnpanel.ResumeLayout(False)
        Me.excelbtnpanel.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents closebtn As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents buttonpanel As System.Windows.Forms.Panel
    Friend WithEvents excelbtn As System.Windows.Forms.Button
    Friend WithEvents prb As System.Windows.Forms.ProgressBar
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents closebtnpanel As System.Windows.Forms.Panel
    Friend WithEvents excelbtnpanel As System.Windows.Forms.Panel
End Class
