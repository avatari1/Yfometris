﻿Public Class columnselectionfrm
    Dim mf As New program
    Private Sub cancel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cancel2.Click, Me.FormClosing
        program.Enabled = True
        acceptcancel.Text = "notok"
        Me.Hide()
    End Sub

    Private Sub accept2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles accept2.Click
        program.statusindex.Text = combo.SelectedIndex + 1
        acceptcancel.Text = "ok"
        program.Enabled = True
        Me.Hide()
        program.opendir.Enabled = True
        Dim icol As Int32
        icol = icollbl.Text
        program.opendir.PerformClick()

    End Sub

 

    Private Sub closingsub(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.FormClosing
        program.Enabled = True
        acceptcancel.Text = "notok"

    End Sub

    Private Sub columnselectionfrm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class