# Yfometris — Original source code (2011)

Yfometris is a historical stylometric analysis application developed by Theodoros Doganis in Visual Basic .NET. The application's original interface and executable identify it as "Text Analysis"; **Yfometris** is the name used for this archival release.

## Contents
- `project.zip`: original Visual Studio solution/project, source code, and historical build artifacts for the main application.
- `Testform.zip`: original Visual Studio solution/project, source code, and historical build artifacts for the separate testing application.
- `LICENSE`: GNU General Public License version 3 (GPL-3.0-only).

Both ZIP files are preserved byte-for-byte as supplied for this archival package. No source code was changed or rebuilt for this release.

## Historical development environment
- Microsoft Windows XP / Vista / 7 (historical requirements; current compatibility untested)
- .NET Framework 4.0 Client Profile
- Microsoft Office 2003 / 2007 / 2010 for Excel integration (historical requirements)
- Main project references Microsoft Office/Excel Interop, ADODB and Microsoft.VisualBasic.PowerPacks.Vs.

The supplied archives include historical `.exe` files in Debug folders. These are **not** newly built or verified releases; buildability and runtime compatibility have not been tested as part of this archive.

## Academic reference
Doganis, T., Mentza, Z., & Kontovounisiou, P. (2011). *Ανάπτυξη λογισμικού για τη μέτρηση υφομετρικών χαρακτηριστικών σε Ηλεκτρονικά Σώματα Κειμένων*. Zenodo. https://doi.org/10.5281/zenodo.23893813

## Licensing
Copyright (c) 2011 Theodoros Doganis.

The original software authored by Theodoros Doganis is offered under the GNU General Public License, version 3. See `LICENSE`. Third-party components and proprietary runtime dependencies are **not** relicensed by this notice and retain their own terms. The accompanying academic thesis is a separate jointly authored work with separate rights.
